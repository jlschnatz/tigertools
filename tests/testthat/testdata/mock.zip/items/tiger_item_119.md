# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

119

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind Gesundheitspsycholog\*in und untersuchen den Alkoholkonsum von Jugendlichen. Aus diesem Grund haben Sie über drei Jahre hinweg eine längsschnittliche Untersuchung durchgeführt und dieselben Jugendlichen im Alter von 14, 15 und 16 Jahren zu ihrem Alkoholkonsum befragt. Laden Sie mit folgendem Befehl den Datensatz in R herunter: `load(url("https://pandar.netlify.app/daten/alc.rda"))`
Vor allem interessiert Sie, inwiefern es den Alkoholkonsum beeinflusst, wenn ein Elternteil Alkoholiker\*in ist. Sie denken, dass entweder die Kinder von Alkoholiker\*innen mehr Alkohol konsumieren, weil sie dieses Verhalten von den Eltern lernen (oder genetisch dafür prädestiniert sind) oder weniger, weil sie der krankhafte Konsum der Eltern abschreckt. Bevor Sie mit dem Test beginnen, wollen Sie zunächst die Voraussetzungen testen. Überprüfen Sie mit geeigneten Verfahren, ob die Normalverteilung und die Homoskedastizität angenommen werden können.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sowohl Homoskedastizität als auch Normalverteilung (in beiden Gruppen) sind gegeben.

# answeroption_02
Weder Homoskedastizität noch Normalverteilung (in beiden Gruppen) sind gegeben.

# answeroption_03
Die Normalverteilung kann für beide Gruppen angenommen werden, allerdings sind die Gruppen heteroskedastisch.

# answeroption_04
Die Normalverteilung ist nicht in beiden Gruppen gegeben, während die Homoskedastizität angenommen werden kann.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Prüfen Sie erneut die Voraussetzungen. Die Normalverteilung können Sie sowohl optisch mit dem QQ-Plot als auch empirisch mit dem Shapiro-Test prüfen (optimalerweise sollten Sie beide Methoden nutzen). Die Homoskedastizität können Sie mit dem Levene-Test überprüfen.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Prüfen Sie erneut die Voraussetzungen. Die Normalverteilung können Sie sowohl optisch mit dem QQ-Plot als auch empirisch mit dem Shapiro-Test prüfen (optimalerweise sollten Sie beide Methoden nutzen). Die Homoskedastizität können Sie mit dem Levene-Test überprüfen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Prüfen Sie erneut die Voraussetzungen. Die Normalverteilung können Sie sowohl optisch mit dem QQ-Plot als auch empirisch mit dem Shapiro-Test prüfen (optimalerweise sollten Sie beide Methoden nutzen). Die Homoskedastizität können Sie mit dem Levene-Test überprüfen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben vermutlich passende Tests gewählt und sind zu dem richtigen Ergebnis gekommen. Achten Sie darauf, dass auch wenn sowohl der QQ-Plot als auch der Shapiro-Test gegen die Normalverteilung sprechen, Sie häufig bei großen Stichproben trotzdem einen t-Test durchführen können ($\Rightarrow$ zentraler Grenzwertsatz).

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
