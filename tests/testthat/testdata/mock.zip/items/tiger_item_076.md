# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

76

# learning_area

Regression

# type_item

coding

# bloom_taxonomy

knowledge

# theo_diff

easy

# stimulus_text

Benutzen Sie für diese Aufgabe bitte den Datensatz ,,attitude‘‘, welcher schon in R integriert sein sollte. Der Datensatz beinhaltet 30 Beobachtungen auf 7 Variablen und beschäftigt sich mit der Bewertung der Organisation von Angestellten. Die Variable ,,rating‘‘ stellt hierbei die generelle Bewertung der Angestellten dar. Weitere Variablen sind zum Beispiel der Umgang mit Beschwerden oder das Erlauben von Privilegien. Für mehr Informationen können Sie sich die Dokumentation mit ?attitude aufrufen. Sie möchten nun untersuchen, inwiefern ,,rating‘‘ durch die anderen 6 erhobenen Teilindikatoren vorhergesagt werden kann. 

Untersuchen Sie in einem multiplen Regressionsmodell, welche der 6 Variablen statistisch signifikante Prädiktoren für die Gesamtbewertung sind. 


# stimulus_image


# answeroption_01

Nur die Variable ,,Umgang mit Beschwerden‘‘ ist ein signifikanter Prädiktor für die Gesamtbewertung. 

# answeroption_02

Die Variablen ,,Umgang mit Beschwerden‘‘ und ,,Lernmöglichkeiten‘‘ sind signifikante Prädiktoren für die Gesamtbewertung. 

# answeroption_03

Alle Variablen sind signifikante Prädiktoren für die Gesamtbewertung. 

# answeroption_04

Keine der Variablen ist ein signifikanter Prädiktor für die Gesamtbewertung. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Sehr gut, Sie haben das Regressionsmodell korrekt aufgestellt und auch richtig interpretiert. 

mod1<- lm(rating~ complaints + privileges + learning + raises + critical + advance, attitude)
(alternativ mit Kurschreibweise: lm(rating~., attitude))
summary(mod1)

Im Output erkennt man, dass nur der p-Wert für ,,complaints‘‘ unterhalb unseres Signifikanzniveaus von .05 liegt und somit ein signifikanter Prädiktor ist.

# if_answeroption_02

Überprüfen Sie nochmal, ob die p-Werte der beiden Variablen wirklich unterhalb des Signifikanzniveaus von 5% liegen und ob Sie bei der Regressionsaufstellung alle relevanten Variablen berücksichtigt haben. 

# if_answeroption_03

Überprüfen Sie, ob Sie Ihr Regressionsmodell richtig aufgestellt haben. Nur wenn der p-Wert des Regressionsgewichts unter 0.05 liegt, gilt der Prädiktor als signifikant.

# if_answeroption_04

Überprüfen Sie, ob Sie für Ihr Regressionsmodell alle Variablen berücksichtigt haben. Wenn der p-Wert des Regressionsgewichts unter 0.05 liegt, gilt der Prädiktor als signifikant.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
