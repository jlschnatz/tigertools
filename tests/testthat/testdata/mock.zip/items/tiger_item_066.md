# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

66

# learning_area

Deskriptivstatistik

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Es ist mal wieder passiert. Gerade wollten Sie sich auf Ihrer Lieblings Katzenbilder Website anmelden, als ein berühmt berüchtigtes Popup Sie an Ihrem Vorhaben hindert. Anscheinend haben Sie die Seite in letzter Zeit so häufig aufgesucht, dass die Website bestätigen möchte, dass Sie kein Bot oder Computerprogramm sind. Sie haben also eine dieser Verifizierungen Ihrer menschlichen Existenz vor sich. Konkret sollen Sie zuordnen, welche Verteilung diesen Boxplot erzeugt hat. 

Da Sie nicht auf Ihre tägliche Dosis Katzenbilder verzichten KÖNNEN!!! MÜSSEN Sie dieses lebenswichtige Rätsel unbedingt lösen. 

# stimulus_image

www/tiger_item066_stimulus.png

# answeroption_01

www/tiger_item066_answeropt_1.png

# answeroption_02

www/tiger_item066_answeropt_2.png

# answeroption_03

www/tiger_item066_answeropt_3.png

# answeroption_04

www/tiger_item066_answeropt_4.png

# answeroption_05

# answeroption_06

www/skip.png

# answer_correct

3


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
image

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
image

# if_answeroption_01

Anhand des Boxplots lässt sich erkennen, dass im zwischen dem ersten und zweiten Quartil (Fläche von unterem Ende der Box bis zur dicken Linie, dem Median) weniger Werte sind (geringere Fläche) als zwischen dem zweiten und dritten Quartil (Fläche von oberem Ende der Box bis zur dicken Linie, dem Median, mehr Fläche). Außerdem gibt es deutlich mehr Werte, welche stark nach oben hin abweichen, während es unterhalb vom Boxplot bei den niedrigen Werten zu keiner so starken Auffächerung kommt. Folglich haben wir viele Werte im unteren Bereich relativ nah beieinander (starke ,,Aufstauchung‘‘ an Werten hier, wer sich das grafisch vorstellen möchte) und mehr aufgefächerte/verteilte Werte im oberen Bereich. Das ist eine linkssteile und rechtsschiefe Verteilung. Wenn wir uns das hier dargestellte Histogramm anschauen, sehen wir eine starke Auffächerung im unteren Bereich und eine Häufung im oberen Bereich. Die dargestellte Verteilung ist demnach rechtssteil (es geht rechts steil nach oben) und linksschief. Genau das Gegenteil vom dargestellten Boxplot. 

# if_answeroption_02

Anhand des Boxplots lässt sich erkennen, dass zwischen dem ersten und zweiten Quartil (Fläche von unterem Ende der Box bis zur dicken Linie, dem Median) weniger Werte sind (geringere Fläche) als zwischen dem zweiten und dritten Quartil (Fläche von oberem Ende der Box bis zur dicken Linie, dem Median, mehr Fläche). Außerdem gibt es deutlich mehr Werte, welche stark nach oben hin abweichen, während es unterhalb vom Boxplot bei den niedrigen Werten zu keiner so starken Auffächerung kommt. Folglich haben wir viele Werte im unteren Bereich relativ nah beieinander (starke ,,Aufstauchung‘‘ an Werten hier, wer sich das grafisch vorstellen möchte) und mehr aufgefächerte/verteilte Werte im oberen Bereich. Das ist eine linkssteile und rechtsschiefe Verteilung. Wenn wir uns das hier dargestellte Histogramm anschauen, sehen wir eine starke Häufung im mittleren Bereich und relativ symmetrische Randbereiche. Die dargestellte Verteilung ist demnach weder links-, noch rechtssteil (--> symmetrisch) und durch die Symmetrie auch nicht sonderlich schief. Für Interessierte: Die Werte wurden hier aus einer Normalverteilung erstellt.

# if_answeroption_03

Bingo! Sie dürfen sich die Katzenbilder anschauen. Anhand des Boxplots lässt sich erkennen, dass im zwischen dem ersten und zweiten Quartil (Fläche von unterem Ende der Box bis zur dicken Linie, dem Median) weniger Werte sind (geringere Fläche) als zwischen dem zweiten und dritten Quartil (Fläche von oberem Ende der Box bis zur dicken Linie, dem Median, mehr Fläche). Außerdem gibt es deutlich mehr Werte, welche stark nach oben hin abweichen, während es unterhalb vom Boxplot bei den niedrigen Werten zu keiner so starken Auffächerung kommt. Folglich haben wir viele Werte im unteren Bereich relativ nah beieinander (starke ,,Aufstauchung‘‘ an Werten hier, wer sich das grafisch vorstellen möchte) und mehr aufgefächerte/verteilte Werte im oberen Bereich. Das ist eine linkssteile und rechtsschiefe Verteilung. Wenn wir uns das Histogramm anschauen, sehen wir genau das: Eine starke Häufung an Werten auf der linken Seite (es geht links steil nach oben --> linkssteil) und eine breite Auffächerung der Werte im oberen Bereich (rechtsschief). Das ist die gesuchte Verteilung! Ein Trick, um sich die Verteilung vielleicht etwas besser vom Boxplot her vorstellen zu können ist, den Boxplot um 90° nach rechts zu drehen und dann zu versuchen, sich die Verteilung der Werte vorzustellen. Für Interessierte: Die Werte wurden hier aus einer gamma Verteilung mit shape 2 erstellt. 

# if_answeroption_04

Anhand des Boxplots lässt sich erkennen, dass im zwischen dem ersten und zweiten Quartil (Fläche von unterem Ende der Box bis zur dicken Linie, dem Median) weniger Werte sind (geringere Fläche) als zwischen dem zweiten und dritten Quartil (Fläche von oberem Ende der Box bis zur dicken Linie, dem Median, mehr Fläche). Außerdem gibt es deutlich mehr Werte, welche stark nach oben hin abweichen, während es unterhalb vom Boxplot bei den niedrigen Werten zu keiner so starken Auffächerung kommt. Folglich haben wir viele Werte im unteren Bereich relativ nah beieinander (starke ,,Aufstauchung‘‘ an Werten hier, wer sich das grafisch vorstellen möchte) und mehr aufgefächerte/verteilte Werte im oberen Bereich. Das ist eine linkssteile und rechtsschiefe Verteilung. Wenn wir uns das hier dargestellte Histogramm anschauen, sehen wir eine starke, symmetrische Anhäufung in der Mitte mit Werten, welche stark in beide Richtungen abweichen. Solche Werte würden wir deutlich präsenter im Boxplot als Ausreißer (Punkte außerhalb der Whisker) erkennen. Außerdem würden wir sie in beide Richtungen erkennen. Die Wertebereiche liegen außerdem außerhalb derer im Boxplot. Für Interessierte: Die Werte wurden hier aus einer cauchy Verteilung erstellt.

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
