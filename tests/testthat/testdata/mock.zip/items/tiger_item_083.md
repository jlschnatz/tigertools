# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

83

# learning_area

Wahrscheinlichkeit

# type_item

coding

# bloom_taxonomy

application

# theo_diff

hard

# stimulus_text

Die negative Binomialverteilung wird verwendet, um die Anzahl von Fehlversuchen zu modellieren, die benötigt werden, bis eine gewisse Anzahl von Erfolgen erreicht wurde. 
Versuchen Sie folgendes Problem mit der negativen Binomialverteilung zu lösen: 
Sie suchen für Ihre Firma drei neue Mitarbeitende. Erfahrungsgemäß führen 20% der Bewerbungsgespräche zu einer Einstellung. Aufgrund Ihrer begrenzten Zeit wollen Sie maximal zehn Bewerbungsgespräche führen, also höchstens sieben erfolglose Bewerbungsgespräche. Sie berechnen nun die Wahrscheinlichkeit, dass Sie unter diesen Bedingungen drei gut geeignete, zukünftige Mitarbeitende finden. Was müssen Sie dafür in R eingeben?


# stimulus_image


# answeroption_01

dnbinom(x = 3, size = 7, prob = .2)

# answeroption_02

dnbinom(x = 7, size = 10, prob = .8)

# answeroption_03

pnbinom(q = 3, size = 10, prob = .2)

# answeroption_04

pnbinom(q = 7, size = 3, prob = .2)

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Überlegen Sie, welche Funktion der normalen Binomialverteilung Sie für ein Problem verwenden würden, bei der eine maximale Anzahl von Erfolgen (hier Misserfolgen) gegeben ist. Die Funktion dnbinom betrachtet nur eine Punktwahrscheinlichkeit einer bestimmten Anzahl von Misserfolgen. Bitte überdenken Sie zusätzlich noch die Reihenfolge Ihrer Argumente, da die negative Binomialverteilung die Anzahl der Misserfolge simuliert und das Argument size für die Erfolge verwendet wird.

# if_answeroption_02

Überlegen Sie, welche Funktion der normalen Binomialverteilung Sie für ein Problem verwenden würden, bei der eine maximale Anzahl von Erfolgen (hier Misserfolgen) gegeben ist. Die Funktion dnbinom betrachtet nur eine Punktwahrscheinlichkeit einer bestimmten Anzahl von Misserfolgen. Überdenken Sie außerdem noch, wofür die Argumente stehen, da die negative Binomialverteilung die Anzahl der Misserfolge simuliert und das Argument size die Anzahl der Erfolge entgegennimmt und leider nicht die Gesamtanzahl der Versuche, wie man intuitiv vermuten würde. Das Argument für die Wahrscheinlichkeit (prob) bezieht sich wiederum auf die Wahrscheinlichkeit für einen Erfolg. Ganz schön verwirrend! 


# if_answeroption_03

Intuitiv scheint diese Lösung die logischste zu sein, wenn man die normale Binomialverteilung bereits kennt. Jedoch simuliert die **negative** Binomialverteilung die Anzahl der Misserfolge, weswegen diese vom ersten Argument entgegengenommen werden. Das Argument size bezieht sich, anders als man erwarten würde, nicht auf die Gesamtanzahl der Versuche, sondern auf die Anzahl der Erfolge. 

# if_answeroption_04

Sehr gut! Das war keine leichte Aufgabe, weil die negative Binomialverteilung ganz anders funktioniert, als wir es anhand der normalen Binomialverteilung intuitiv erwarten würden. Da die negative Binomialverteilung die Anzahl der Fehlversuche modelliert, werden diese auch an das erste Argument weitergegeben. Besonders ungewöhnlich scheint, dass die Anzahl der Erfolge an das Argument size weitergegeben wird, weil wir von der Binomialverteilung eigentlich gewohnt sind, dass size für die Gesamtanzahl der Versuche steht. Das Argument prob beschreibt wie gewohnt die Erfolgswahrscheinlichkeit. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
