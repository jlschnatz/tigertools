# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

123

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie interessieren sich als angehende\*r Wissenschaftler\*in **brennend** dafür, was man als Professor\*in so verdient. Dazu haben Sie in dem R-Paket CarData einen Datensatz gefunden, in dem es ausgerechnet um das Gehalt von Professor\*innen geht.
```
install.packages("carData")
library(carData)
data(Salaries)
```
Sie haben nun den Datensatz in R geladen. Ernüchtert stellen Sie allerdings fest, dass die Daten aus den USA stammen und außerdem aus dem Jahr 2008 sind, also nicht mehr ganz aktuell. Die Übertragbarkeit auf die heutige Situation in Deutschland ist also mehr als fraglich. Trotzdem wollen Sie interessehalber der Frage nachgehen, ob zu dieser Zeit weibliche Professorinnen im Median signifikant weniger verdienen als ihre männlichen Kollegen, da sich Mediane für den Vergleich von Gehältern gut eignen. Überprüfen Sie mit einem geeigneten Test die Hypothese.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Professoren verdienen nicht signifikant mehr als Professorinnen (p = .996).

# answeroption_02
Professoren verdienen signifikant mehr als Professorinnen (p = .002).

# answeroption_03
Professoren verdienen signifikant mehr als Professorinnen (p = .004).

# answeroption_04
Professoren verdienen signifikant mehr als Professorinnen (p = .008). 

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf die Richtung der Testung. Lassen Sie sich dazu am besten explizit die Mediane der beiden Gruppen ausgeben.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben vermutlich einen Zweistichproben-t-Test durchgeführt, welcher dem Vergleich von Mittelwerten dient. Überlegen Sie, welcher Test dafür geeignet ist, Mediane zu vergleichen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig bedacht, dass Sie für einen Medianvergleich den Wilcoxon-Test heranziehen müssen. Auch die Richtung des Tests haben Sie korrekt gewählt.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben zwar den richtigen Test gewählt, achten Sie jedoch noch auf die Richtung des Tests.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
