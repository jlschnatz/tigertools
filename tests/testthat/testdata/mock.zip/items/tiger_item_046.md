# id_item
46

# learning_area
Poweranalyse

# type_item
coding

# bloom_taxonomy
application

# theo_diff
medium

# stimulus_text
Die erhobene Stichprobe war eine anfallende Stichprobe. Nun soll im Nachgang geschaut werden, für welche Effektstärken (Cohen's d für einen Zwei-Stichproben-t-Test und r für eine Korrelation) 90% Power bei einem Alpha-Niveau von 5% erreicht wurden.

# stimulus_image
NA

# answeroption_01
Cohen's d = 0.65 & r = 0.32

# answeroption_02
Cohen's d = 0.46 & r = 0.32

# answeroption_03
Cohen's d = 0.65 & r = 0.44

# answeroption_04
Cohen's d = 0.46 & r = 0.44

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01

Für den Zwei-Stichproben-t-Test wurde eine Stichprobengröße von n = 100 pro Gruppe verwendet, was einer Gesamtstichprobengröße von 200 entspricht. Für die Korrelation wurde eine Stichprobengröße von n = 50 verwendet, was einer Gesamtstichprobengröße von 50 entspricht. Mit diesen Angaben ergibt sich bei einem Alpha-Niveau von 5% und einer Power von 90% eine minimale Effektstärke von Cohen's d = 0.65 für den Zwei-Stichproben-t-Test und r = 0.32 für die Korrelation.


# if_answeroption_02
Hier wurde für den Zwei-Stichproben-t-Test ein n von 100 verwendet, dies würde jedoch einer Gesamtstichprobengröße von 200 entsprechen.

# if_answeroption_03
Hier wurde für die Korrelation ein n von 50 verwendet, dies würde jedoch einer Gesamtstichprobengröße von 50 entsprechen.

# if_answeroption_04
Hier wurde für den Zwei-Stichproben-t-Test ein n von 100 verwendet, dies würde jedoch einer Gesamtstichprobengröße von 200 entsprechen, wohingegen für die Korrelation ein n von 50 verwendet wurde, was einer Gesamtstichprobengröße von 50 entspricht.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

