# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

65

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

Über die Jahre haben sich viele Personen viele Gedanken darüber gemacht, wie man Menschen mit einer Posttraumatischen Belastungsstörung (PTBS) helfen könnte. Dabei haben sich eine Vielzahl an Verfahren und Anwendungen als wirksam erwiesen. Sie haben nun ein revolutionäres Konzept entwickelt, was besser sein soll als die bisherigen Behandlungsmethoden (aus Geheimhaltungsgründen wird das Konzept hier nicht näher erläutert, Ihnen könnte ja sonst jemand die Idee stehlen). Bevor Sie dieses Konzept nun der Weltbevölkerung zugänglich machen, wollen Sie aber erst bestätigen, dass es wirklich besser wirkt als der etablierte Ansatz. Dafür behandeln Sie 40 Traumapatient\*innen mit Ihrer neuen Methode und vergleichen diese mit 40 Kontrollproband\*innen, welche die etablierte Therapieform bekommen haben. Sie möchten nun nach den Therapien die beiden Gruppen miteinander hinsichtlich der Schwere ihrer PTBS Symptomatik vergleichen. Dabei soll der Unterschied zwischen den beiden Gruppen definitiv extremer sein als 7. Die mit Ihrer Methode behandelten Patient\*innen hatten eine mittlere Symptomschwere von 10, die Kontrollproband\*innen eine mittlere Symptomschwere von 20. Der geschätzte Standardfehler $\hat{\sigma}_{(\bar{X_1}-\bar{X_2})}$ beträgt 1.51. 

Berechnen Sie, ob die Differenz zwischen den beiden Gruppen signifikant extremer als die von Ihnen festgelegte Mindestschwelle von 7 ist. 

# stimulus_image

# answeroption_01

Die Differenz der Symptomschwere ist statistisch bedeutsam extremer als 7 mit t = +/-6.62 und p < .001. 

# answeroption_02

Die Differenz der Symptomschwere ist statistisch bedeutsam extremer als 7 mit t = +/-1.99 und p = .025.  

# answeroption_03

Die Differenz der Symptomschwere ist statistisch bedeutsam extremer als 7 mit t = +/-1.99 und p = .027.

# answeroption_04

Die Differenz der Symptomschwere ist nicht statistisch bedeutsam extremer als 7 mit t = +/-1.99 und p = .05.

# answeroption_05

# answeroption_06

Frage überspringen.
<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->

# answer_correct

2


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

Achten Sie nochmal darauf, dass unter der H0 nicht die Gleichheit der beiden Gruppen formuliert wird, sondern stattdessen eine Differenz schon vorher angenommen wird. Diese muss bei der Berechnung der Prüfgröße berücksichtigt werden.

# if_answeroption_02

Sie haben die vorgegebene Differenz von 7 richtig berücksichtigt und auch den p-Wert korrekt unter der Beachtung der Richtung der Hypothese berechnet. 

# if_answeroption_03

Achten Sie nochmal auf die Freiheitsgrade des Tests. Sie haben die Freiheitsgrade für abhängige Stichproben angegeben, jedoch betrachten wir zwei unabhängige Stichproben, auch wenn diese gleich groß sind.

# if_answeroption_04

Achten Sie nochmal auf die Richtung des Tests bei der p-Wert Berechnung.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
