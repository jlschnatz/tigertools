# id_item
53

# learning_area
Zusammenhangsmaße

# type_item
coding

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Welcher Zusammenhang beschreibt am besten die Beziehung zwischen den Variablen „sportlicheAktivitaet“ und „schlafqualitaet“?

# stimulus_image
NA

# answeroption_01
Positive Korrelation

# answeroption_02
Negative Korrelation

# answeroption_03
Keine Korrelation

# answeroption_04
U-förmige Beziehung

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01

Es besteht eine positive Korrelation zwischen sportlicher Aktivität und Schlafqualität, was bedeutet, dass mit zunehmender sportlicher Aktivität auch die Schlafqualität tendenziell steigt.

# if_answeroption_02

Schaue dir nochmal das Streudiagramm an. 


# if_answeroption_03

Schaue dir nochmal das Streudiagramm an. 



# if_answeroption_04

Schaue dir nochmal das Streudiagramm an. 



# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

