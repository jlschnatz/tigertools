# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

108

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind Schlafforscher\*in und haben die Vermutung, dass Jugendliche, die viel Zeit vor Bildschirmen (Smartphone, Computer, Fernsehen etc.) verbringen, gleichzeitig auch weniger schlafen. Zu diesem Zweck erheben Sie die Schlaf- und Bildschirmzeit-Daten von insgesamt 210 Jugendlichen aus 3 unterschiedlichen Schulen. Nun wollen Sie konkret herausfinden, wie viele Stunden die Jugendlichen, mit jeder zusätzlichen Stunde Bildschirmzeit, im Schnitt weniger schlafen. Mit Ihren Daten starten Sie also mit einer Regressionsanalyse. Unglücklicherweise zeigt der Akkuladestand Ihres Laptops 1% an und es ist weit und breit kein Ladekabel in Sicht. Allerdings hatten Sie versprochen, dass Sie heute noch die ersten aussagekräftigen Ergebnisse liefern. Also müssen Sie sich blitzschnell entscheiden, wie Sie weiter vorgehen: berechnen Sie die standardisierten oder unstandardisierten Regressionsgewichte und aus welchem Grund? Achten Sie dabei genau auf die Forschungsfrage.


# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie berechnen zunächst das unstandardisierte Regressionsgewicht, weil nur so die Werte direkt interpretierbar sind. 

# answeroption_02
Sie berechnen zunächst das unstandardisierte Regressionsgewicht, weil Sie verschiedene Gruppen (Schulen) miteinander vergleichen wollen und die unstandardisierten Regressionsgewichte dann besser interpretierbar sind.

# answeroption_03
Sie berechnen zunächst das standardisierte Regressionsgewicht, weil die verschiedenen Populationen (Schulen) mit unterschiedlichen Varianzen nur so verglichen werden können.

# answeroption_04
Sie berechnen zunächst das standardisierte Regressionsgewicht, weil man nur mit diesem generalisierte Aussagen über die Population treffen kann.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig erkannt, dass es darum geht, eine Vorhersage in Stunden bezogen auf die Schlafdauer zu machen. Zu diesem Zweck eignen sich unstandardisierte Regressionsgewichte besser, da deren Wert direkt interpretierbar und in die Anzahl der Stunden übersetzbar ist. Allerdings sollten Sie auch beachten, dass sich die Stichprobenkennwerte zwischen den Schulen unterscheiden könnten, weswegen es sowieso immer ratsam ist, auch die standardisierten Regressionsgewichte zu berechnen und die verschiedenen Gruppen auf Homogenität zu prüfen.  

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn Sie untersuchen wollen, inwiefern sich der Zusammenhang zwischen Bildschirmzeit und Schlafdauer an verschiedenen Schulen unterscheidet und dabei ein direkt interpretierbares Ergebnis erhalten wollen, dann wäre dies der richtige Ansatz. Allerdings geht es hier nicht um einen Vergleich zwischen Gruppen, sondern um eine möglichst präzise Vorhersage der Schlafdauer anhand der Bildschirmzeit über die Gesamtpopulation der Jugendlichen. 

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal genau auf die Forschungsfrage. Welches ist das Hauptproblem von standardisierten Regressionsgewichten? Und da Sie eine Aussage über das Schlafverhalten von Jugendlichen im Allgemeinen treffen wollen, stellt es kein wirkliches Problem dar, dass Jugendliche von verschiedenen Schulen befragt wurden.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Bei der standardisierten Regression wird das Regressionsgewicht an der jeweiligen Stichprobenvarianz relativiert. Allerdings ist das standardisierte Regressionsgewicht, auch wenn es intuitiv so erscheinen mag, deswegen nicht besser geeignet für eine generalisierte Aussage als das unstandardisierte. Zu einer gelungenen Regressionsanalyse gehören immer beide Regressionsgewichte. Überlegen Sie jedoch, welches zur Beantwortung dieser spezifischen Forschungsfrage besser geeignet ist.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
