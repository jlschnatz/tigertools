# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

124

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie untersuchen den Effekt von Koffeinkonsum auf die Reaktionszeit. Es hat sich bereits erwiesen, dass sich Koffein vor allem bei Schlafmangel positiv auf die Reaktionszeit auswirkt. Sie wollen nun der Frage auf den Grund gehen, ob Koffein die Reaktionszeit auch verbessert, wenn man ausgeschlafen ist und eigentlich nicht auf die Wirkung von Koffein angewiesen ist. Für Ihr Experiment konnten Sie 10 (halb)freiwillige Studierende rekrutieren. Dabei haben Sie die Reaktionszeit einmal vor der Einnahme von Koffein gemessen und einmal nach der Einnahme von 100mg Koffein in Form eines Spaßgetränks. Im Nachhinein denken Sie sich allerdings, dass Sie doch besser Kaffee hätten nehmen sollen, weil der Zucker im Spaßgetränk auch stimulierend oder, im Gegenteil, durch den schnellen Blutzuckerabfall ermüdend wirken könnte. Trotzdem starten Sie Ihre Analyse mit folgenden Daten:
```
nocaffeine <- c(402.5, 362.7, 308.0, 299.1, 259.9, 292.5, 331.1, 291.0, 431.9, 246.3)
caffeine <- c(401.3, 372.4, 307.6, 264.2, 253.6, 294.4, 336.0, 266.1, 432.9, 214.9)
```
Sie können davon ausgehen, dass Reaktionszeiten einer linksschiefen Verteilung folgen. Wählen Sie ein geeignetes Verfahren und prüfen Sie auf einem $\alpha$-Fehler-Niveau von 10% die Hypothese, ob Koffein die Reaktionszeit von ausgeschlafenen Personen verbessert.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das Koffein konnte die Reaktionszeit signifikant verbessern (p = .071).

# answeroption_02
Das Koffein konnte die Reaktionszeit nicht signifikant verbessern (p = .392).

# answeroption_03
Das Koffein konnte die Reaktionszeit nicht signifikant verbessern (p = .188).

# answeroption_04
Das Koffein konnte die Reaktionszeit nicht signifikant verbessern (p = .427).

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben vermutlich einen Zweistichproben-t-Test für abhängige Stichproben durchgeführt. Überlegen Sie, welche Voraussetzung des t-Tests verletzt ist, wenn eine linksschiefe Verteilung vorliegt und welches Verfahren man alternativ anwenden kann.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal darauf, um welche Art von Stichprobe es sich handelt, wenn jede Person beide Versuchsbedingungen durchläuft. Überlegen Sie außerdem, welche Voraussetzung des t-Tests verletzt ist, wenn eine linksschiefe Verteilung vorliegt und welches Verfahren man alternativ anwenden kann.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtigerweise einen Wilcoxon-Vorzeichen-Rang-Test für abhängige Stichproben durchgeführt und auch die Richtung der Testung beachtet.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überlegen Sie noch mal, um welche Art von Stichprobe es sich handelt, wenn jede Person beide Versuchsbedingungen durchläuft.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
