# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

104

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Deskriptivstatistik

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Ihre Arbeitgeberin verlangt schon wieder mal Unmögliches von Ihnen: Es wurde soeben ein neuer Mitarbeiter eingestellt und Ihre Chefin, die ein absoluter Kontrollfreak ist, verlangt eine Vorhersage, mit wie vielen Krankheitstagen im Jahr sie bei dem neuen Mitarbeiter rechnen muss. Die verzweifelte Aussage, dass Sie keine hellseherischen Fähigkeiten besitzen, konnte Ihre Chefin erst recht nicht zufriedenstellen. Nun gut, immerhin haben Sie eine anonymisierte Auflistung der Krankheitstage im letzten Jahr der Mitarbeitenden in Ihrem Team, die allerdings aufgrund der strengen Datenschutzauflagen keinerlei weitere Informationen über die Personen enthält. Auch wenn Sie vermutlich ziemlich daneben liegen werden, versuchen Sie anhand der Daten die bestmögliche Schätzung mit möglichst kleiner Abweichung vom wahren Wert zu ermitteln.

`krankheitstage <- c(3, 12, 17, 8, 8, 5, 21, 13, 7, 11, 8, 15, 4, 9, 14, 16, 5, 19, 8, 13, 2, 17, 20, 7, 9)`

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Die anhand der Daten bestmögliche Schätzung beträgt 8 Krankheitstage pro Jahr.

# answeroption_02
Die anhand der Daten bestmögliche Schätzung beträgt 21 Krankheitstage pro Jahr.

# answeroption_03
Die anhand der Daten bestmögliche Schätzung beträgt 9 Krankheitstage pro Jahr.

# answeroption_04
Die anhand der Daten bestmögliche Schätzung beträgt 10.84 Krankheitstage pro Jahr.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben den Modus berechnet, also die am häufigsten besetzte Kategorie. Das ist schon mal keine schlechte Schätzung, überlegen Sie allerdings noch mal, ob es noch einen anderen deskriptivstatistischen Wert gibt, der eine bessere Schätzung bezogen auf die Abweichung liefert.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Vielleicht haben Sie, bezogen auf den Ärger mit Ihrer Chefin, recht damit, auf Nummer sicher zu gehen und den Maximalwert als Schätzung zu benutzen, um möglichst wenig zu riskieren, dass der neue Mitarbeiter mehr fehlt als Sie vorhergesagt haben. Trotzdem üben wir hier Statistik und nicht People Pleasing, also überlegen Sie bitte noch mal, ob es nicht einen deskriptivstatistischen Wert gibt, der eine präzisere Schätzung liefert.


# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben den Median berechnet, der schon mal keine schlechte Schätzung ist, da die Summe der absoluten Abweichungen von diesem Wert minimal ist. Es gibt allerdings noch einen anderen deskriptivstatistischen Wert, dessen Abweichungssumme 0 ist und der sich deswegen noch besser als Schätzwert eignet.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Der Mittelwert liefert in so einem Fall die beste Schätzung für eine unbekannte Person, da der die Abweichungssumme der Messwerte vom Mittelwert 0 ist und die Summe der quadrierten Abweichungen minimal ist. Leider ist das Risiko, dass Sie den wahren Wert des neuen Mitarbeiters verfehlen und Ihre Chefin enttäuscht sein wird, trotzdem recht groß. Um eine präzisere Schätzung zu erzeugen, lernen Sie später im Semester und vertiefend im zweiten Semester die Regression kennen, also seien Sie gespannt!

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
