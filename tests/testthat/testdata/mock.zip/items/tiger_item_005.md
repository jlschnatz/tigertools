# id_item
5

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Welches der folgenden Intervalle enthält am ehesten den Mittelwert der folgenden Verteilung?

# stimulus_image
www/reali_item05_stimulus.png

# answeroption_01
4 bis 6

# answeroption_02
7 bis 9

# answeroption_03
10 bis 12

# answeroption_04
NA

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
2

# type_stimulus
image

# type_answer
text

# if_answeroption_01
Wir haben Werte auf einer Skala von 0 bis 12 vorliegen, der Mittelwert dieser Skala liegt bei 6. Dies bedeutet, wären alle Werte gleich (uniform) verteilt, läge der Mittelwert bei 6. Damit der Mittelwert zwischen 4 und 6 liegt, müsste die Verteilung linkssteil/rechtsschief sein, also mehr Daten in der unteren Hälfte. Das Gegenteil ist jedoch der Fall. Daher liegt der Mittelwert höher als 6.

# if_answeroption_02
Wir haben es mit einer rechtssteilen/linksschiefen Verteilung zu tun, bei der der Mittelwert unterhalb des Modus liegt. Den Modus können wir ablesen, mit ca. 9,5. Daher muss der Mittelwert richtigerweise darunter liegen.

# if_answeroption_03
Wir haben es mit einer rechtssteilen/linksschiefen Verteilung zu tun, bei der der Mittelwert unterhalb des Modus liegt. Den Modus können wir ablesen, mit ca. 9,5. Daher muss der Mittelwert darunter liegen und kann nicht darüber zwischen 10 und 12 liegen.

# if_answeroption_04
NA

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

