# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

73

# learning_area

Deskriptivstatistik

# type_item

coding

# bloom_taxonomy

application

# theo_diff

medium

# stimulus_text

Schreiben Sie mittels R die Zahl 3999 als römische Zahl. 

# stimulus_image


# answeroption_01

MMMCMXCIX

# answeroption_02

MMCCMXCIX

# answeroption_03

MMMCMCXIX

# answeroption_04

MMMCMCIX

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Der Code dazu ist as.roman(3999).

# if_answeroption_02

Suchen Sie vielleicht nach einem R-Befehl, welcher arabische Zahlen in römische umwandelt.

# if_answeroption_03

Suchen Sie vielleicht nach einem R-Befehl, welcher arabische Zahlen in römische umwandelt.

# if_answeroption_04

Suchen Sie vielleicht nach einem R-Befehl, welcher arabische Zahlen in römische umwandelt.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
