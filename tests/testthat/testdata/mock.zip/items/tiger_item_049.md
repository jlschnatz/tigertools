# id_item
49

# learning_area
Grundlagen der Inferenzstatistik

# type_item
coding

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Eine Wissenschaftlerin merkt an, dass die Stichprobe verzerrt sein könnte, wenn nur Personen mit sehr guten Noten erhoben wurden. Dies wäre der Fall, wenn die Stichprobe eine mittlere Durchschnittsnote von 1.8 und besser aufweist. Überprüfe, ob die mittlere Durchschnittsnote der Stichprobe signifikant schlechter als 1.8 ist. Welches ist das entsprechende Ergebnis?

# stimulus_image
NA

# answeroption_01
t = 37.61, df = 81, p < .001

# answeroption_02
t = 2.73, df = 81, p = .008

# answeroption_03
t = 2.73, df = 81, p = .004

# answeroption_04
t = 2.73, df = 81, p = .996

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
3

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dieser Test prüfte nicht die entsprechende Richtung der aufgestellten Hypothese.

# if_answeroption_02
Dieser Test beachtete nicht die Richtung der aufgestellten Hypothese.

# if_answeroption_03

Du hast richtig erkannt, dass es sich um einen einseitigen t-Test handelt, bei dem gegen einen Mittelwert von 1.8 getestet wird. 

# if_answeroption_04
Dieser Test prüfte in die falsche Richtung.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

