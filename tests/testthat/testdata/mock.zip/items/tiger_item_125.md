# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

125

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Poweranalyse

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie starten ein Experiment, um herauszufinden, ob man seine Reaktionszeit trainieren kann. Zu diesem Zweck lassen Sie Ihre Versuchspersonen fünf Mal an einem, jedes Mal etwas abgewandelten, Reaktionstest teilnehmen. Sie wissen bereits, dass in der Population untrainierte Personen im Test, bezogen auf Schnelligkeit und Genauigkeit, im Durchschnitt einen Normwert von 100 erreichen mit einer Standardabweichung von 10. Ihre Hypothese lautet, dass das fünfmalige Üben des Tests die Leistung um mindestens eine Standardabweichung verbessern wird. Wie viele Personen müssen Sie rekrutieren, um eine Power von 0.9 zu erhalten bei einem alpha-Fehler-Niveau von 5%? Führen Sie eine Poweranalyse durch.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie müssen mindestens 9 Personen rekrutieren.

# answeroption_02
Sie müssen mindestens 11 Personen rekrutieren.

# answeroption_03
Sie müssen mindestens 1 Person rekrutieren.

# answeroption_04
Sie müssen mindestens 857 Personen rekrutieren.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben die Analyse richtig durchgeführt und auch beachtet, dass Sie hier eine Poweranalyse für einen z-Test durchführen müssen.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben vermutlich eine Power-Analyse in R mit dem Befehl `wp.t()` durchgeführt. Da hier aber die Populationsstandardabweichung bereits gegeben ist, müssen Sie eine Poweranalyse für den z-Test durchführen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal genau auf die z-Werte in Ihrer Berechnung. In diesem Fall müssen Sie den z-Wert für $\alpha$ = .05 bestimmen und für 1-$\beta$ = .9.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal genau auf die Alternativhypothese. Der Effekt soll nicht eine Einheit, sondern mindestens eine **Standardabweichung** betragen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
