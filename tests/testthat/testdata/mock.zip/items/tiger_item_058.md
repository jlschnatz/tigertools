# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

58

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text
Ein mittelständisches Unternehmen möchte aufgrund einiger Beschwerden über das Arbeitsklima untersuchen, ob eine neue Schulung die Hilfsbereitschaft der Mitarbeitenden erhöht. Diese wurde vielfach beworben, und nach einigen nervenaufreibenden Vorstandssitzungen wurde mit einer Mehrheit von gerade mal einer Stimme entschieden, die Schulung anzubieten. 
Dazu wurden 5 Mitarbeitende ausgewählt, aus deren Personalakten hervorging, dass sie etwas mehr Hilfsbereitschaft besonders nötig hätten. Ihre Hilfsbereitschaft wurde mit einem geeigneten Messinstrument einmal vor und einmal nach der Schulung gemessen:
- **Vor** der Schulung: 15, 16, 14, 17, 15
- **Nach** der Schulung: 17, 18, 14, 19, 16
Die Vorstände, die gegen die Schulung gestimmt hatten, möchten den Befürworten nun ihren Fehler unter die Nase reiben und auf Grundlage der erhobenen Daten beweisen, dass die Schulung eine Geldverschwendung war, die man lieber in die Weihnachtsfeier hätte investieren sollen. 
Unterstützen Sie die Vorstände bei ihrem Projekt und führen Sie einen geeigneten Test mit α=0.05 durch, unter der Annahme, dass das Merkmal in der Population normalverteilt ist.

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Es gibt keinen signifikanten Unterschied in der Hilfsbereitschaft vor und nach der Schulung.  (**p = 0,2074**)
# answeroption_02
Es gibt einen signifikanten Unterschied in der Hilfsbereitschaft vor und nach der Schulung. (**p= 0,0249**)
# answeroption_03
Es gibt keinen signifikanten Unterschied in der Hilfsbereitschaft vor und nach der Schulung.  (**p = 0,04449**)
# answeroption_04
Es gibt einen signifikanten Unterschied in der Hilfsbereitschaft vor und nach der Schulung.  (**p = 0,01245**)
# answeroption_05

# answeroption_06
<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct
<!-- Numerisch (Integer) -->
4


# type_stimulus
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben wahrscheinlich einen regulären unabhängigen Zweistichproben-t-Test gerechnet. Schauen Sie sich noch einmal an, wie die Gruppen zueinander stehen. Außerdem sollten Sie die Richtung der Hypothese beachten.

# if_answeroption_02
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben den korrekten Test durchgeführt, aber einen Zusatz vergessen. Versuchen Sie nochmal, die H0 und die H1 zu formulieren und die Testrichtung in Ihre Rechnung mit aufzunehmen.

# if_answeroption_03
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben einen Wilcoxon-Vorzeichen-Rangtest durchgeführt, welcher verwendet wird, wenn die Differenzvariable nicht normalverteilt ist. Das ist zwar bei einer kleinen Stichprobe wie dieser ein sinnvoller Ansatz, achten Sie jedoch auf die Formulierung der Aufgabenstellung.

# if_answeroption_04
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtig erkannt, dass es sich um einen t-Test für abhängige Stichproben handelt und auch die Richtung der Hypothese beachtet.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
