# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

103

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Wahrscheinlichkeit

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text
<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie wollen in einer Studie die moralischen Einstellungen der Studierenden Ihres Jahrgangs untersuchen. Für Ihre Onlinebefragung verwenden Sie Vignettenfragen (eine Vignette ist ein hypothetisches Szenario, bei der die Versuchsperson beurteilen soll, wie sie die Situation einschätzt oder wie sie sich verhalten würde). Sie haben einen Katalog von 30 Vignettenfragen entwickelt. Da Sie jedoch wissen, dass die Aufmerksamkeitsspanne von Studierenden, die an der Studie nur für VPM teilnehmen, recht gering ist, Sie aber jede der 30 Vignetten ganz raffiniert finden und keine ausschließen wollen, werden jeder Versuchsperson 8 dieser Vignettenfragen zufällig zugewiesen. An Ihrer Studie haben, nach mehrmaligem Aufruf in der WhatsApp-Gruppe des Jahrgangs, immerhin 68 der 150 Personen in Ihrem Jahrgang teilgenommen. Zufällig bekommen Sie mit, wie sich zwei Ihrer Kommilitoninnen über Ihre Studie unterhalten und sind ganz erfreut, dass Ihr Fragebogen solch ein Interesse wecken konnte. Wie wahrscheinlich ist es, dass sich die beiden Kommilitoninnen über dieselben Vignettenfragen unterhalten haben? 

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Die Wahrscheinlichkeit beträgt 1.524158e-12.

# answeroption_02
Die Wahrscheinlichkeit beträgt 1.708547e-07.

# answeroption_03
Die Wahrscheinlichkeit beträgt 4.237469e-12.

# answeroption_04
Die Wahrscheinlichkeit beträgt 0.01470588.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überlegen Sie nochmal, ob die Reihenfolge bei der Auswahl der Vignetten eine Rolle spielt. Bedenken Sie zusätzlich, dass dieselbe Vignettenfrage nie mehr als ein Mal pro Fragebogen auftaucht.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtig beachtet, dass Sie die Formel für den Binomialkoeffizienten verwenden müssen, um die Anzahl der möglichen Kombinationen von 8 aus 30 Fragen zu ermitteln. Außerdem haben Sie erkannt, dass die Wahrscheinlichkeit genau 1 durch die Anzahl an möglichen Kombinationen beträgt, da dies der Wahrscheinlichkeit entspricht, dass eine zweite Person genau die eine Kombination aus allen möglichen Kombinationen bekommen hat, die die erste Person auch hat.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie sind auf dem richtigen Weg, aber überlegen Sie nochmal, ob die Reihenfolge der Auswahl der Vignetten eine Rolle spielt.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Beachten Sie, dass die Anzahl der möglichen Kombinationen nichts mit der Anzahl der Studienteilnehmenden zu tun hat. Überlegen Sie stattdessen, wie Sie die Anzahl der Möglichkeiten berechnen können, 8 Vignettenfragen aus insgesamt 30 auszuwählen und leiten Sie daraus die Wahrscheinlichkeit ab, dass eine Person zufällig eine weitere trifft, die genau die gleiche Fragenauswahl bearbeitet hat.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
