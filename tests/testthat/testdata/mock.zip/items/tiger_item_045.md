# id_item
45

# learning_area
Deskriptivstatistik

# type_item
coding

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Was ist die empirische Standardabweichung der Variable „durchschnittsnote“?

# stimulus_image
NA

# answeroption_01
0.46700000000000003

# answeroption_02
0.46200000000000002

# answeroption_03
0.46500000000000002

# answeroption_04
0.46400000000000002

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
4

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dies ist die geschätzte Populationsstandardabweichung.

# if_answeroption_02
Hier fehlt die Wurzel bei der Korrektur.

# if_answeroption_03
Bei der Korrektur darf nicht die Länge des gesamten Datensatzes verwendet werden, sondern die Länge nach Ausschluss fehlender Werte.

# if_answeroption_04

Die empirische Standardabweichung wird berechnet, indem die Wurzel aus der korrigierten Varianz gezogen wird. Die Korrektur erfolgt durch Division der Summe der quadrierten Abweichungen vom Mittelwert durch die Anzahl der Beobachtungen minus eins (n-1), um eine unverzerrte Schätzung der Populationsstandardabweichung zu erhalten.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

