# id_item
37

# learning_area
Zusammenhangsmaße

# type_item
content

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Studien zeigen, dass Frauen mit zunehmendem Alter eine geringere Knochendichte aufweisen. Welches der folgenden Diagramme veranschaulicht diesen Punkt?

# stimulus_image
NA

# answeroption_01
www/reali_item37_answeropt1.png

# answeroption_02
www/reali_item37_answeropt2.png

# answeroption_03
www/reali_item37_answeropt3.png

# answeroption_04
NA

# answeroption_05
NA

# answeroption_06
www/skip.png

# answer_correct
1

# type_stimulus
text

# type_answer
image

# if_answeroption_01
Die Daten in der Abbildung zeigen einen negativen Zusammenhang, sprich je höher das Alter, desto geringer die Knochendichte.

# if_answeroption_02
Die Daten in der Abbildung zeigen einen positiven Zusammenhang, sprich eine höhere Knochendichte mit höherem Alter.

# if_answeroption_03
Die Daten in der Abbildung zeigen keinen Zusammenhang zwischen Alter und Knochendichte.

# if_answeroption_04
NA

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

