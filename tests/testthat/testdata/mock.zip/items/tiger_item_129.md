# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

129

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Poweranalyse

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie geben Statistik-Nachhilfe und haben gerade eine simulationsbasierte Poweranalyse durchgeführt, um Ihrem Nachhilfeschüler zu beweisen, dass ein größeres n immer zu mehr Power führt... doch oh Schreck! Tatsächlich hat die Analyse ergeben, dass die Power für die kleinere Stichprobe sogar größer ist! Sie geraten in Erklärungsnot und auch Ihr Nachhilfeschüler fängt schon an, an Ihren Fähigkeiten als Nachhilfelehrer\*in zu zweifeln. Wie können Sie sich noch retten und dieses unerwartete Ergebnis erklären?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->
www/tiger_item129_stimulus.png

# answeroption_01
Die Effektstärke ist bei der zweiten Analyse geringer.

# answeroption_02
Bei der zweiten Analyse sind die Gruppen unterschiedlich groß.

# answeroption_03
Es wird nicht die Power ausgegeben, sondern der $\beta$-Fehler. Die Power ist also durchaus bei der zweiten Analyse größer.

# answeroption_04
Die Power ist zufällig kleiner aufgrund von Stichprobenschwankung.

# answeroption_05
Der `set.seed()` Befehl fehlt.

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
image

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Tatsächlich sind die Effektstärken gleich. Betrachten Sie dazu mal die Standardabweichungen: die Standardabweichung ist bei der ersten Analyse 1.5 mal so groß wie bei der zweiten, genau wie der Mittelwertsunterschied. Da für die Berechnung des Effekts der Mittelwertsunterschied an der Standardabweichung relativiert wird, bleibt der Effekt insgesamt gleich.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Es stimmt zwar, dass einheitliche Gruppengrößen für die Power am effizientesten sind und zu maximaler Power führen, solange die Stichprobe **insgesamt** gleich groß bleibt. Da hier allerdings bei der zweiten Analyse **beide** Gruppen größer sind als bei der ersten, sollte die Power trotzdem gestiegen sein.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Es handelt sich bei dem Wert tatsächlich um die Power, da der Anteil der Durchführungen ausgegeben wird, bei dem das Ergebnis signifikant ausfällt, gegeben dass es einen Mittelwertsunterschied gibt. 

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Puh, noch mal Glück gehabt, Sie können Ihren Job behalten! So banal die Erklärung auch klingt, aber der Zufall spielt leider eine häufig unterschätzte Rolle bei statistischen Ergebnissen. Deswegen sollten Sie bei Simulationsstudien wie diesen auch unbedingt mit mehr Wiederholungen arbeiten! Sie sehen hier sehr deutlich, dass 100 Wiederholungen einfach zu wenig sind.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben zwar recht damit, dass man als gute\*r Wissenschaftler\*in **auf jeden Fall** mit `set.seed()` arbeiten sollte (also nehmen Sie sich kein Beispiel an mir), weil nur so Ihre Ergebnisse replizierbar und nachvollziehbar sind. Leider löst das aber Ihr Problem nicht. Auch mit `set.seed()` kann dieses Problem auftreten.

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
