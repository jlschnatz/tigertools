# id_item
48

# learning_area
Zusammenhangsmaße

# type_item
coding

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Führe eine inferenzstatistische Überprüfung der Hypothese "Je kürzer jemand schläft, desto höher ist das Wohlbefinden." durch. Welches ist das korrekte Ergebnis?

# stimulus_image
NA

# answeroption_01
r = .52, df = 98, p < .05

# answeroption_02
r = .55, df = 98, p < .05

# answeroption_03
r = .55, df = 98, p > .05

# answeroption_04
r = .52, df = 98, p > .05

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
4

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dieser Test hat nicht die entsprechende Richtung der Hypothese geprüft.

# if_answeroption_02
Dieser Test prüfte eine Spearman-Rang-Korrelation, hier ist jedoch eine Pearson-Korrelation angemessen. Darüber hinaus hat der Test nicht die entsprechende Richtung der Hypothese geprüft.

# if_answeroption_03
Dieser Test prüfte eine Spearman-Rang-Korrelation, hier ist jedoch eine Pearson-Korrelation angemessen.

# if_answeroption_04

Das ist das korrekte Ergebnis eines Pearson-Korrelations-Tests, der die Hypothese testet, dass je kürzer jemand schläft, desto höher ist das Wohlbefinden. Da der p-Wert größer als .05 ist, kann die Nullhypothese nicht verworfen werden, was bedeutet, dass kein signifikanter Zusammenhang zwischen Schlafdauer und Wohlbefinden besteht.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

