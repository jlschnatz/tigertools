# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

95

# learning_area

Grundlagen der Inferenzstatistik

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Paula hat mal wieder in einem Anflug von akutem Statistikwahn mit Verteilungen und Mittelwerten simulationsbasiert rumprobiert. Dabei ist ihr was Erstaunliches aufgefallen: Egal, wie die zur Simulation genutzten Verteilungen zu Beginn aussehen, irgendwie scheinen die Stichprobenmittelwerte immer ab einer gewissen Stichprobengröße die gleiche Verteilungsform anzunehmen. Um diese Erkenntnis ihrem Freund Herbert zu präsentieren, schreibt sie ein Skript, welches 10.000 Mal eine Stichprobe der Größe n zieht. Ein konkreter Wert kann in ihrer Simulation entweder 0 oder 1 sein. Dann bildet sie den Mittelwert über die n Werte und wiederholt dies 10.000 Mal. Anschließend werden die Mittelwerte als Histogramm geplottet. Sie erhält die untenstehenden Abbildungen. 

Was hat Paula hier entdeckt?


# stimulus_image

www/tiger_item095_stimulus.png

# answeroption_01

Das Mittelwert-Paradoxon

# answeroption_02

Das Gesetz der großen Zahlen

# answeroption_03

Die Herleitung der Binomialverteilung

# answeroption_04

Den zentralen Grenzwertsatz

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Eine kurze Google Suche hat bei mir zu einem ungewollten deep dive in das Will-Rogers-Phänomen und das Wartezeitparadoxon geführt. Leider ist keins von beidem hier dargestellt. Versuchen Sie vielleicht sich anzuschauen, welche Art der Verteilung das Histogramm zunehmend darstellt. 

# if_answeroption_02

Das Gesetz der großen Zahlen bezieht sich darauf, dass die Häufigkeit, mit der ein Zufallsereignis eintritt, sich einer rechnerischen Wahrscheinlichkeit immer weiter annähert, je häufiger ein Zufallsexperiment durchgeführt wird. In diesem Fall: bei unendlicher Wiederholung eines Zufallsexperiments mit den beiden gleich wahrscheinlichen Ausgängen 0 und 1 beträgt die Wahrscheinlichkeit, eine 1 zu ziehen, genau 0,5. Allerdings beschreibt das Gesetz der großen Zahlen nicht das Phänomen, wodurch die dargestellte Verteilung zustande kommt. Überlegen Sie, welcher Verteilung sich die Verteilung der Mittelwerte annähert.

# if_answeroption_03

Zwar hat die Binomialverteilung eine Verbindung zur Normalverteilung, jedoch ist diese nicht der Grund für die Form der Verteilung. Das hier gesuchte Phänomen lässt sich nämlich auch auf ganz anders aussehende (stetige) Populationsverteilungen anwenden. 


# if_answeroption_04

Die Verteilung der Mittelwerte geht ab einer ausreichenden Stichprobengröße in die Normalverteilung über. Die notwendige Stichprobengröße kann je nach Schiefe der Verteilung unterschiedlich sein. Bekannt ist diese Tatsache als zentraler Grenzwertsatz. Das ist auch der Grund dafür, dass je größer die Stichprobe, desto weniger streng muss man bei Verletzung der Normalverteilung sein, da die Stichprobenkennwerteverteilung bei großem n trotzdem normalverteilt ist.

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
