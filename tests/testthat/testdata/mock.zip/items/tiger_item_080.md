# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

80

# learning_area

Wahrscheinlichkeit

# type_item

coding

# bloom_taxonomy

knowledge

# theo_diff

easy

# stimulus_text

Eine gute Deutschlehrerin an Ihrer alten Schule offenbarte Ihnen vor langer, langer Zeit in einer weit entfernen Galaxis ein Geheimnis. Sie benutzt für das Erstellen Ihrer Noten keine Glaskugel, keine Geisterbeschwörung und auch nicht die Gezeiten und Himmelskörper, sondern lediglich 3 Würfel. Zwei von 1 bis 6 und einen von 1 bis 3. So kommt immer maximal 15 und mindestens 3 raus und alle Schüler sind glücklich und zufrieden (dieses Stilmittel nennt sich btw ein Hendiadyoin (Und da soll mir mal jemand sagen, stumpf Stilmittel auswendig zu lernen würde nichts bringen!)).  Sie finden das hochinteressant und wollen nun weiter schauen, welche Eigenschaften das von Ihrer Lehrerin verwendete Verfahren noch so hat. Dazu schreiben Sie das untenstehende R-Skript. Allerdings beschäftigen Sie sich danach so stark mit deutscher Literatur, Stilmitteln und Hendiadyoins, dass Sie komplett vergessen, wofür das Skript gedacht war. 

Was wird mit dem Skript ermittelt?


# stimulus_image

www/tiger_item080_stimulus.png

# answeroption_01

Das Skript ermittelt simulationsbasiert die Varianz der Würfelwurfsummen Ihrer Lehrerin. 

# answeroption_02

Das Skript ermittelt simulationsbasiert die Standardabweichung der Würfelwurfsummen Ihrer Lehrerin. 

# answeroption_03

Das Skript ermittelt simulationsbasiert den Median der Würfelwurfsummen Ihrer Lehrerin. 

# answeroption_04

Das Skript ermittelt simulationsbasiert den Erwartungswert der Würfelwurfsummen Ihrer Lehrerin. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Hier wird ein anderer Verteilungsparameter simulationsbasiert ermittelt. Welche Funktion hat der Befehl mean()?

# if_answeroption_02

Hier wird ein anderer Verteilungsparameter simulationsbasiert ermittelt. Welche Funktion hat der Befehl mean()? 

# if_answeroption_03

Schon nah dran. Hier wird zwar ein Maß der zentralen Tendenz ermittelt, jedoch ein anderes als der Median.  

# if_answeroption_04

Das Skript ermittelt zuerst simulationsbasiert in 1 Million Simulationen die einzelnen Summen, welche Ihre Lehrerin erhalten kann, und bildet dann aus diesen 1 Million Einzelergebnissen den Durchschnitt, welcher dem Erwartungswert entspricht. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
