# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

78

# learning_area

Regression

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Ihnen liegt es sehr am Herzen, dass der Straßenverkehr sicherer wird. Dafür möchten Sie sich mit dem durchschnittlichen Bremsweg eines Autos befassen. Damit Sie das untersuchen können, stellen Sie sich an zufällig ausgewählte Landstraßen, warten bis ein Auto kommt, machen eine wohlbedachte Zuckung in Richtung Fahrbahn und messen anschließend präzise, wie lange die Autos zum Anhalten brauchen (bitte nicht nachmachen). Kurz bevor Sie das tun, messen Sie die Geschwindigkeit der Autos. Um Ihre Hypothese zu prüfen, stellen Sie folgende einfache lineare Regressionsgleichung auf und prüfen gewissenhaft die Voraussetzungen. Dabei fällt Ihnen auf, dass Sie einen Fehler gemacht haben. 

Was haben Sie bei Ihrer Datenanalyse nicht einbezogen? 


# stimulus_image

www/tiger_item078_stimulus.png

# answeroption_01

Die Werte müssen vorher noch alle standardisiert werden, damit die Voraussetzungen erfüllt sind und die Beta-Gewichte interpretierbar sind.

# answeroption_02

Die Werte der abhängigen Variable müssen noch log-transformiert werden, damit sie normalverteilt sind. 

# answeroption_03

Nichts, die aufgestellten Analysen stimmen so. 

# answeroption_04

Es muss noch ein quadratischer Effekt von der Geschwindigkeit aufgenommen werden, da der Effekt nicht rein linear ist. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Die Beta-Gewichte sind auch so interpretierbar und die Voraussetzungen sowie deren Prüfung ändern sich dadurch auch nicht. Sie wären weiterhin unerfüllt. Betrachten Sie vor allem erneut den Plot oben links und überlegen Sie, was mit diesem überprüft werden soll.

# if_answeroption_02

Die Voraussetzungen der Regression (darunter auch Normalverteilung) beziehen sich auf die Residuen, nicht auf die abhängige Variable. Bei den Residuen lässt sich, wie man am rechten oberen Graphen erkennen kann, keine klare Abweichung von der Normalverteilung feststellen. Eine log-Transformation der Werte ist demnach kein geeignetes Mittel, um die Voraussetzungen zu erfüllen. Betrachten Sie vor allem erneut den Plot oben links und überlegen Sie, was mit diesem überprüft werden soll.

# if_answeroption_03

Überprüfen sie nochmal anhand der Voraussetzungsprüfungen und des Sachzusammenhangs, ob die dargestellte Analyse stimmig und vollständig ist. Betrachten Sie vor allem erneut den Plot oben links und überlegen Sie, was mit diesem überprüft werden soll.

# if_answeroption_04

Wie aus der Fahrschule bekannt, steigt der Bremsweg nämlich quadratisch zur Geschwindigkeit an. Das heißt, wenn sich die Geschwindigkeit verdoppelt, vervierfacht sich der Bremsweg. Für Personen, die sich nicht mehr an die Theorie ihres Führerscheins erinnern oder diese nie gehabt haben gibt es aber noch die zweite Art, dies zu erkennen. In den Voraussetzungsprüfungen sieht man im Plot links oben, dass die Residuen bei niedrigen vorhergesagten Werten tendenziell hoch, in der Mitte tendenziell tief und bei sehr hohen Werten wieder hoch sind. Es ergibt sich ein quadratischer Verlauf, welcher ebenfalls auf den nicht berücksichtigten quadratischen Effekt hinweist. Die komplette Formel herzuleiten dauert an dieser Stelle etwas zu lang. Trotzdem ist mir noch wichtig zu betonen, dass es nach der physikalischen Formel durchaus sinnvoll ist, **mindestens** einen halben Tacho Abstand zu halten, wie man es in der Fahrschule als Faustregel beigebracht bekommt. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
