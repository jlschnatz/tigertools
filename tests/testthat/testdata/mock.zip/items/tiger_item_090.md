# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

90

# learning_area

Deskriptivstatistik

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Nutzen Sie für diese Aufgabe den in R bereitgestellten Datensatz ,,mtcars‘‘. Unter all den Autos, welche genau 6 Zylinder oder weniger (Variable ,,cyl‘‘) haben, welches hat am meisten PS (Variable: ,,hp‘‘ (horsepower))?

# stimulus_image


# answeroption_01

Der Maserati Bora mit 335 PS. 

# answeroption_02

Der Ferrari Dino mit 175 PS. 

# answeroption_03

Der Duster 360 mit 245 PS. 

# answeroption_04

Der Lotus Europa mit 113 PS. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Überprüfen Sie nochmal, ob Sie die richtigen Autos rausgefiltert haben, als Sie alle Autos mit weniger oder gleich 6 Zylindern filtern wollten. 

# if_answeroption_02

Sie haben den Datensatz korrekt gefiltert und konnten anschließend mit which.max() herausfinden, welches Auto die meisten PS hat.

# if_answeroption_03

Überprüfen Sie nochmal, ob Sie die richtigen Autos rausgefiltert haben, als Sie alle Autos mit weniger oder gleich 6 Zylindern filtern wollten und ob Sie die richtige Variable ausgewählt haben zum Filtern. 

# if_answeroption_04

Überprüfen Sie nochmal, ob Sie die richtigen Autos rausgefiltert haben, als Sie alle Autos mit weniger oder gleich 6 Zylindern filtern wollten. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
