# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

74

# learning_area

Deskriptivstatistik

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Die Levenshtein-Distanz beschreibt die minimale Anzahl an Änderungsschritten, die nötig sind, um eine Zeichenkette in eine andere zu transformieren.

Finden Sie mittels des adist-Befehls in R die höchste Levenshtein-Distanz zwischen den Wörtern des folgenden Vektors: 

Themengebiete <- c("Deskriptivstatistik","Wahrscheinlichkeit","Grundlagen Inferenzstatistik","Gruppenvergleiche","Poweranalyse","Zusammenhangsmaße","Regression")

# stimulus_image


# answeroption_01

Die höchste Levenshtein-Distanz ist zwischen "Deskriptivstatistik" und "Wahrscheinlichkeit" mit 18 zu finden. 

# answeroption_02

Die höchste Levenshtein-Distanz ist zwischen "Grundlagen Inferenzstatistik" und "Wahrscheinlichkeit" mit 24 zu finden. 

# answeroption_03

Die höchste Levenshtein-Distanz ist zwischen "Grundlagen Inferenzstatistik" und "Zusammenhangsmaße" mit 27 zu finden.

# answeroption_04

Alle Levenshtein-Distanzen sind 0.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Es gibt eine höhere Levenshtein-Distanz. 

# if_answeroption_02

Die höchste Levenshtein-Distanz ist mit 24 zwischen "Grundlagen Inferenzstatistik" und "Wahrscheinlichkeit". 
Befehl in R: adist(Themengebiete)

# if_answeroption_03

Die Levenshtein-Distanz zwischen "Grundlagen Inferenzstatistik" und "Zusammenhangsmaße" ist nicht 27. 

# if_answeroption_04

Nur die Levenshtein-Distanz zwischen einem Wort mit sich selbst (siehe Hauptdiagonale) ist 0. Dies kommt daher, dass ein Wort 0 Modifikationen braucht, um wieder sich selbst zu ergeben. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
