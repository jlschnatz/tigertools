# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

63

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Zusammenhangsmaße

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
hard

# stimulus_text


Eine Studentin kommt ganz aufgeregt zu Ihnen. Sie hat in Ihrer Studie rausgefunden, dass ihr Regressionsgewicht $\beta_1$ eine Signifikanz aufweist. Ihnen ist die Studentin schon vorher unangenehm aufgefallen, weswegen Sie ihr doch so schönes Erfolgserlebnis zunichtemachen wollen. Also fragen Sie nach den Parametern sowie der Signifikanzberechnung, welche Ihre Kommilitonin erfasst und durchgeführt hat. Stolz berichtet diese, dass bei einer Stichprobengröße von 44 Leuten ein unstandardisiertes $\beta_1$ von 0.69 vorlag, wobei $s_x=0.3$ und $s_y=0.7$ waren. Für die Berechnung der Signifikanz habe Sie einfach $\beta_1$ genommen und in diese Formel für r eingesetzt. 

$t=\frac{r*\sqrt{n-2}}{\sqrt{1-r^2}}$
 
Als Ergebnis bekam Sie einen p-Wert von 2.202001e-07 (sie testet ungerichtet), was deutlich unter Ihrem 5% Signifikanzniveau lag. Sie fangen an zu grinsen, da Sie schon einen Fehler bei Ihrer Kommilitonin entdeckt haben. Statt Sie aber nur auf Ihren Fehler hinzuweisen, wollen Sie es besser machen und den korrekten Schluss aus den Daten ziehen. 

Sie machen sich also daran, den t-Wert und die Signifikanz des Regressionsgewichts korrekt zu bestimmen. Was ist Ihr Ergebnis?

# stimulus_image


# answeroption_01
Das Regressionsgewicht ist signifikant (p = 1.006943e-07).

# answeroption_02
Das Regressionsgewicht ist nicht signifikant (p = .051).

# answeroption_03
Das Regressionsgewicht ist signifikant (p = .026).

# answeroption_04
Die Signifikanz des Regressionsgewichts lässt sich mit der Formel für die Korrelation nicht berechnen.

# answeroption_05

# answeroption_06

Frage überspringen.
<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

text
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->

# if_answeroption_01

Sie haben die Prüfgröße wie Ihre Kommilitonin berechnet, jedoch gerichtet statt ungerichtet getestet. Der Fehler Ihrer Kommilitonin liegt jedoch nicht in der Richtung des Tests, sondern sie hat die Prüfgröße falsch berechnet. Überlegen Sie, wieso in der Aufgabenstellung die Standardabweichungen angegeben sind und in welchem Fall die Korrelation dem Regressionsgewicht entspricht.

# if_answeroption_02

Sie haben bei der Berechnung richtig erkannt, dass Sie das Regressionsgewicht erst standardisieren müssen um die Korrelation zu erhalten ($B_1=b1*\frac{s_{x1}}{s_y}$). Auch haben Sie richtig erkannt, dass das standardisierte Regressionsgewicht **bei der einfachen Regression** gleich der Korrelation ist und Sie folglich das standardisierte Regressionsgewicht/die Korrelation in die Formel Ihrer Kommilitonin für r einsetzen können. Aus dem resultierenden t-Wert konnten Sie nun den p-Wert berechnen, den Sie aufgrund der ungerichteten Hypothese verdoppeln müssen.

# if_answeroption_03

Ihre Berechnung war soweit richtig, jedoch müssen Sie noch beachten, dass es sich hierbei um eine **ungerichtete** Hypothese handelt.

# if_answeroption_04

Es handelt sich zwar um die Formel für die Signifikanztestung der Korrelation, jedoch kann diese bei der **einfachen** Regression auch zur Signifikanztestung des Regressionsgewichts verwendet werden. Überlegen Sie, wie Sie das unstandardisierte Regressionsgewicht verändern müssen, damit es der Korrelation entspricht.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
