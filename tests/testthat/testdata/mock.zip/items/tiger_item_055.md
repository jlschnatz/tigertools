# id_item

55

# learning_area

Gruppenvergleiche

# type_item

content

# bloom_taxonomy

application

# theo_diff

hard

# stimulus_text

Ein Aspekt, der bei der Borderline-Persönlichkeitsstörung (BPS) zu erheblichem Leidensdruck führt, ist eine gestörte Affektregulation, die oft mit starken Schwankungen in den Affektzuständen der Patient*innen einhergeht.

Im Rahmen eines klinischen Trials zur Wirksamkeit der dialektisch-behavioralen Therapie (DBT) bei BPS wurde unter anderem untersucht, ob diese  in der Lage ist, diese Schwankungen im Affekt zu reduzieren. Dafür wurden die Patient*innen randomisiert entweder der Kontrollgruppe ($$n_{TAU}$$ = 101), die Treatment as Usual erhielt, oder der Treatmentgruppe ($$n_{DBT}$$ = 46) zugewiesen. Nach Abschluss der Therapie wurde in beiden Gruppen ein Instrument zur Messung des Affekts eingesetzt. Die Ergebnisse einer vorher durchgeführten Pilotstudie ergaben bereits, dass die Schwankungen in den Affektzuständen in der DBT-Gruppe im Vergleich zur TAU-Gruppe um 30 Prozent verringert werden konnten. Nach der Pilotierungsstudie wurde die Intervention weiter optimiert. Man geht davon aus, dass der Effekt dieser neuen, verbesserten Intervention in der aktuellen Studie stärker sein wird als der in der Pilotstudie gefundene Effekt.

Die deskriptiven Kennwerte der Studie sind in folgender Tabelle dargestellt:

<table>
  <tr>
    <th>Gruppe</th>
    <th>M</th>
    <th>S<sup>2</sup></th>
  </tr>
  <tr>
    <td>DBT</td>
    <td>10.8</td>
    <td>4.9</td>
  </tr>
  <tr>
    <td>TAU</td>
    <td>15.1</td>
    <td>14.3</td>
  </tr>
</table>

Berechnen Sie eine geeignete Prüfgröße, um die Hypothese zu testen und runden Sie das Ergebnis auf zwei Nachkommastellen.

# stimulus_image


# answeroption_01

2.02

# answeroption_02

2.88

# answeroption_03

2.04

# answeroption_04

2.92

# answeroption_05

7.12

# answeroption_06

<!---
String (eines von):
    - Frage überspringen.
    - www/skip.png
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png
--->

Frage überspringen.

# answer_correct

1

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->

text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->

text

# if_answeroption_01

Sehr gut! Sie haben erkannt, dass es sich um einen F-Test handelt. Die Stichprobenvarianzen haben Sie richtigerweise  in geschätzte Populationsvarianzen umgerechnet und dann bei der Teststatistik darauf geachtet, dass die H0 nicht $$\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=1$$, sondern $$\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=0.7$$ lautet.

# if_answeroption_02

Sie haben zwar erkannt, dass es sich um einen F-Test handelt und korrekterweise die Stichprobenvarianzen in geschätzten Populationsvarianzen umgerechnet. Allerdings haben Sie nicht berücksichtigt, dass die H0 nicht $$\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=1$$, sondern $$\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=0.7$$ lautet. Dies war in der Aufgabe durch die Reduktion der Variabilität der DBT-Gruppe um 30% im Vergleich zur TAU-Gruppe impliziert. 

# if_answeroption_03

Sie haben zwar erkannt, dass es sich um einen F-Test handelt und korrekterweise nicht die Nullhypothese $\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=1$, sondern $\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=0.7$ getestet. Allerdings haben Sie nicht berücksichtigt, dass die Stichprobenvarianzen für die Teststatistik noch in geschätzte Populationsvarianzen umgerechnet werden müssen. 

# if_answeroption_04

Sie haben zwar erkannt, dass es sich um einen F-Test handelt, jedoch an zwei Stellen einen Fehler gemacht: Erstens müssen Sie die angegebenen Stichprobenvarianzen in geschätzte Populationsvarianzen umrechnen. Zweitens war nicht nach der Nullhypothese  $\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=1$, sondern $\sigma^2_{\text{DBT}}/\sigma^2_{\text{TAU}}=0.7$ in der Aufgabenstellung gefragt. Dies war in der Aufgabe durch die Reduktion der Variabilität der DBT-Gruppe um 30% im Vergleich zur TAU-Gruppe impliziert.

# if_answeroption_05

Sie haben fälschlicherweise einen t-Test durchgeführt. Allerdings müssen hier nicht die Mittelwerte getestet werden, sondern die Varianzen, da es um die Schwankungen der Affektzustände geht, die sich aber nur in der Varianz und nicht im Mittelwert widerspiegeln. Diese Aufgabe war ganz schön schwer, da Sie den F-Test im ersten Semester kaum anwenden, aber wenn Sie sich die Formel im Foliensatz "Tests für unabhängige Stichproben" anschauen, dann können Sie die Aufgabe bestimmt lösen!

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
