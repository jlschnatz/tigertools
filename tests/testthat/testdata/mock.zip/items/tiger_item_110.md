# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

110

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie haben vor langer Zeit einmal untersucht, inwiefern sich Klimaangst durch umweltbewusstes Verhalten vorhersagen lässt. Heute haben Sie erneut einen Bericht über die Ernsthaftigkeit des Klimawandels gelesen und sind nun motiviert, das Thema noch mal aufzugreifen. Leider finden Sie nur noch das standardisierte Regressionsgewicht von 0.35. Zusätzlich interessieren Sie sich aber auch noch für das unstandardisierte Regressionsgewicht. Da Sie den Datensatz nicht mehr finden können, kramen Sie ganz tief in Ihrem Gedächtnis und erinnern sich, dass die Varianz des umweltbewussten Verhaltens etwa 2.5 mal so groß war wie die der Klimaangst. Nun wollen Sie daraus schätzungsweise das unstandardisierte Regressionsgewicht berechnen (nur aus Eigeninteresse).

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das unstandardisierte Regressionsgewicht beträgt etwa 0.22.

# answeroption_02
Das unstandardisierte Regressionsgewicht beträgt etwa 0.55.

# answeroption_03
Das unstandardisierte Regressionsgewicht beträgt etwa 0.14.

# answeroption_04
Man kann das unstandardisierte Regressionsgewicht nicht berechnen, da die genauen Werte der Varianzen unbekannt sind.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig erkannt, dass Sie das Verhältnis der Standardabweichungen (dazu mussten Sie die Wurzel aus dem Verhältnis der Varianzen ziehen) einfach in die Formel zur Berechnung des unstandardisierten Regressionsgewichts aus dem standardisierten Regressionsgewicht einsetzen können.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Schauen Sie sich noch mal die Formel an und überlegen, welche Variable hier den Prädiktor (x) und welche das Kriterium (y) darstellt.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben das Verhältnis der Varianzen in die Formel eingesetzt, jedoch müssen Sie noch beachten, dass Sie die Standardabweichungen benötigen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Schauen Sie sich noch mal die Formel an. Zur Berechnung des unstandardisierten Regressionsgewichts benötigen Sie das standardisierte Regressionsgewicht sowie den Quotienten der Standardabweichungen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
