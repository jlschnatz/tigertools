# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

98

# learning_area

Deskriptivstatistik

# type_item

coding

# bloom_taxonomy

application

# theo_diff

easy

# stimulus_text

Lesen Sie sich in die Funktion ,,intersect‘‘ ein. Welche Aussage bezüglich des Befehls stimmt, wenn man 2 unterschiedliche Vektoren als Argumente in den Befehl hineingibt? 

# stimulus_image


# answeroption_01

Der Befehl gibt aus, welche Elemente gleich sind bei 2 Vektoren.

# answeroption_02

Der Befehl gibt aus, wie viele Elemente gleich sind bei 2 Vektoren.

# answeroption_03

Der Befehl gibt aus, ob Elemente gleich sind bei 2 Vektoren.

# answeroption_04

Der Befehl gibt aus, welche Elemente ungleich sind bei 2 Vektoren.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Bei zwei Vektoren a und b gibt der Befehl heraus, welche Elemente zwischen den Vektoren gleich sind. Das funktioniert auch für andere Arten von Vektoren, wie z.B. Charakter-Strings. Sie können gerne weiter mit dem Befehl rumexperimentieren. Beispielsweise kann man mit dem Befehl auch ganz leicht Elemente eines Vektors entfernen, welche sich wiederholen. 

# if_answeroption_02

Experimentieren Sie etwas mit dem Befehl und gehen Sie die verschiedenen Möglichkeiten durch, indem Sie sich selbst zwei Vektoren erstellen und diese auf die Funktion anwenden. Schauen Sie auch gerne in die Dokumentation zum Befehl. 

# if_answeroption_03

Experimentieren Sie etwas mit dem Befehl und gehen Sie die verschiedenen Möglichkeiten durch, indem Sie sich selbst zwei Vektoren erstellen und diese auf die Funktion anwenden. Schauen Sie auch gerne in die Dokumentation zum Befehl. 

# if_answeroption_04

Experimentieren Sie etwas mit dem Befehl und gehen Sie die verschiedenen Möglichkeiten durch, indem Sie sich selbst zwei Vektoren erstellen und diese auf die Funktion anwenden. Schauen Sie auch gerne in die Dokumentation zum Befehl.

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
