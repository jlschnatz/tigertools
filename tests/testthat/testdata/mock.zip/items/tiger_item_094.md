# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

94

# learning_area

Poweranalyse

# type_item

content

# bloom_taxonomy

knowledge

# theo_diff

easy

# stimulus_text

In einer Studie untersuchen Sie, ob sich die Stärke des kritischen Denkens bei Menschen, die an Verschwörungstheorien glauben, unterscheidet von Menschen, die nicht an Verschwörungstheorien glauben. In einer A-priori Poweranalyse haben Sie unter der Annahme der gleichmäßigen Rekrutierung eine Stichprobengröße von mindestens 120 Personen pro Gruppe ermittelt. 

Während der Datenerhebung fällt Ihnen aber auf, dass deutlich weniger Verschwörungstheoretiker\*innen Ihre Umfrage ausfüllen. Die finale Stichprobenzusammensetzung besteht aus 40 Verschwörungstheoretiker\*innen und 200 Nicht-Verschwörungstheoretiker\*innen. Welche Auswirkungen hat das ungleichmäßige Rekrutieren an Versuchspersonen auf die Power?


# stimulus_image

# answeroption_01

Die Power steigt, da die geringe Anzahl an Verschwörungstheoretikern die Varianz der Messwerte senkt. 

# answeroption_02

Die Power sinkt, da die maximale Power bei gleich großen Stichproben erreicht wird. 

# answeroption_03

Die Power verändert sich nicht, da immer noch insgesamt 240 Personen erhoben wurden. 

# answeroption_04

Mal so, mal so. Ohne eine Neuberechnung der Power lässt sich über deren Veränderung keine Aussage treffen. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Zum einen sinkt die Varianz nicht systematisch durch kleinere Stichproben (die Populationsvarianz der Verteilung, aus der die Messungen gezogen werden, bleibt ja gleich, unabhängig davon wie viele Personen gezogen werden). Außerdem wird der Standardfehler durch die kleine Stichprobe stärker erhöht, als durch die entsprechend größere Stichprobe (bei gleichbleibender Gesamtzahl von Proband\*innen) kompensiert werden kann. Überlegen Sie nochmal, welche Verteilung von Personen auf die Stichproben sich am günstigsten auf die Power auswirkt.

# if_answeroption_02

Je ungleicher die Stichprobengrößen sind (bei gleichem gesamten n), desto niedriger ist die Power. Maximale Power wird bei gleich großen Stichproben erreicht. 

# if_answeroption_03

Die Power verändert sich, je nachdem wie die Gesamtanzahl von 240 Personen sich auf die beiden Gruppen aufteilen. Das liegt daran, dass der Standardfehler durch die verkleinerte Stichprobe stärker beeinflusst wird, als durch die entsprechend größere Stichprobe kompensiert werden kann. Überlegen Sie nochmal, bei welcher Verteilung an Personen in den beiden Gruppen die Power maximal ist.

# if_answeroption_04

Die Power verändert sich, ohne dass man dies erneut testen müsste, in eine bestimmte Richtung, wenn man die Gesamtzahl von 240 Personen ungleichmäßig aufteilt. Das liegt daran, dass der Standardfehler durch die verkleinerte Stichprobe stärker beeinflusst wird, als durch die entsprechend größere Stichprobe kompensiert werden kann. Überlegen Sie nochmal, bei welcher Verteilung an Personen in den beiden Gruppen die Power maximal ist.

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
