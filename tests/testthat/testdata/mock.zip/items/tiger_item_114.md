# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

114

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie haben in der Vorlesung fünf verschiedene Voraussetzungen für die Regression kennengelernt. Eine davon ist die korrekte Spezifikation des Modells, welche verschiedene Probleme bei der Aufstellung eines adäquaten Regressionsmodells einschließt. In welchem der folgenden Fälle ist die korrekte Spezifikation des Modells **nicht** verletzt?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie wollen untersuchen, welche Persönlichkeitsmerkmale mit Narzissmus zusammenhängen und erheben dazu mittels eines Fragebogens viele verschiedene Variablen. Diese lassen Sie alle in Ihr finales Regressionsmodell einfließen, denn viel hilft bekanntlich viel, obwohl einige der Variablen gar keinen signifikanten Beitrag zur Varianzaufklärung leisten.

# answeroption_02
Sie untersuchen, inwiefern sich der Koffeinkonsum auf die Konzentrationsfähigkeit auswirkt. Neben Koffeinmenge (UV) und Leistung im Konzentrationstest (AV) nehmen Sie außerdem mehrere potentielle Störvariablen wie die Schlafdauer in Ihr Modell auf.

# answeroption_03
Sie untersuchen, inwiefern der empfundene Leistungsdruck mit der Leistung in einem Aufmerksamkeitstest zusammenhängt und stellen dafür wie selbstverständlich ein lineares Regressionsmodell auf, obwohl der Leistungsdruck eigentlich einen quadratischen Zusammenhang mit der Testleistung aufweist.

# answeroption_04
Sie wollen in Ihrem Forschungsprojekt beleuchten, inwiefern sich Eigenschaften der Eltern auf die Schulleistungen von Grundschulkindern auswirken. Dabei lassen Sie in Ihr Regressionsmodell einfließen, wie viel die Eltern der Kinder arbeiten und wie viel Zeit sie in die schulische Förderung der Kinder investieren. Wichtige sozioökonomische Faktoren, wie das Haushaltseinkommen oder der Bildungsgrad der Eltern, berücksichtigen Sie in Ihrem Modell allerdings nicht.

# answeroption_05

# answeroption_06


<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn Sie irrelevante Variablen in das Modell aufnehmen, verkompliziert das zum einen das Modell und zum anderen kann es zu einer verzerrten Schätzung der Regressionsgewichte der anderen Variablen kommen. Das Einbeziehen von nicht signifikanten Prädiktoren nennt man auch Overfitting, was definitiv eine Verletzung der korrekten Modellspezifikation darstellt.


# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Man könnte zunächst denken, dass es etwas Negatives sei, Störvariablen in das Modell aufzunehmen. Für die Erforschung von kausalen Zusammenhängen ist es jedoch extrem wichtig, sich über potentielle Störvariablen im Klaren zu sein und diese zu kontrollieren, da sonst sehr leicht das Regressionsgewicht der eigentlichen UV fehlinterpretiert wird, wenn andere Variablen ebenfalls systematische Unterschiede in der AV bewirken. Deswegen stellt dieser Schritt keine Verletzung der korrekten Modellspezifikation dar, sondern ist, im Gegenteil, ein essentieller Bestandteil davon.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Ein lineares Modell anzunehmen, obwohl eigentlich ein kurvilinearer Zusammenhang vorliegt, führt dazu, dass ein signifikanter Zusammenhang gar nicht erst erkannt wird. Dies zählt zum Underfitting und ist somit definitiv eine Verletzung der korrekten Spezifikation des Modells.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn für die Varianzerklärung relevante Variablen ausgelassen werden, nennt man das Underfitting. Das kann zu einer verzerrten Schätzung der Regressionsgewichte führen und schränkt die Varianzaufklärung massiv ein. Die korrekte Spezifikation des Modells ist somit verletzt.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
