# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

121

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie wissen bereits, dass für verschiedene Testverfahren gewisse Voraussetzungen gegeben sein müssen. Beispielsweise sollten für einen Zweistichproben-t-Test für unabhängige Stichproben, neben der Unabhängigkeit der Stichproben und der Beobachtungen, die Normalverteilung und die Homoskedastizität gegeben sein. Dabei haben Sie Voraussetzungstests wie den Levene-Test (Homoskedastizität) und den Shapiro-Wilk-Test (Normalverteilung) kennengelernt. Was ist das große Problem von klassischen Voraussetzungstests wie diesen?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das $\alpha$-Fehler-Niveau von Signifikanztests ist grundsätzlich zu groß, weswegen die Voraussetzung häufig fälschlicherweise verworfen wird.

# answeroption_02
Das $\alpha$-Fehler-Niveau von Signifikanztests ist grundsätzlich zu klein, weswegen die Voraussetzung häufig fälschlicherweise angenommen wird.

# answeroption_03
Voraussetzungstests funktionieren nur bei unabhängigen Stichproben und liefern daher für abhängige Stichproben keine verlässlichen Ergebnisse.

# answeroption_04
Ihr Ergebnis hängt stark vom Stichprobenumfang ab und es kann daher leicht zu irreführenden Signifikanzentscheidungen kommen.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Das ist nicht ganz richtig, da zwar normalerweise ein Signifikanzniveau von 5% gewählt wird, dieses aber nicht vorgeschrieben ist, sondern (wie bei anderen statistischen Tests auch) flexibel gewählt werden kann. Man sollte lediglich vorher festlegen, welches Signifikanzniveau man verwendet und begründen, wieso man von den 5% abweicht.
Außerdem kann man nicht grundsätzlich sagen, dass die Voraussetzung zu häufig verworfen wird.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Das ist nicht ganz richtig, da zwar normalerweise ein Signifikanzniveau von 5% gewählt wird, dieses aber nicht vorgeschrieben ist, sondern (wie bei anderen statistischen Tests auch) flexibel gewählt werden kann. Man sollte lediglich vorher festlegen, welches Signifikanzniveau man verwendet und begründen, wieso man von den 5% abweicht.
Außerdem kann man nicht grundsätzlich sagen, dass die Voraussetzung zu häufig angenommen wird.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Voraussetzungstests funktionieren ebenso bei abhängigen Stichproben, nur eventuell etwas anders. Bei abhängigen Stichproben wird lediglich die Differenzvariable auf Normalverteilung geprüft statt beide Gruppen einzeln zu prüfen. Auf Homoskedastizität muss man bei abhängigen Stichproben nicht testen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Das ist tatsächlich ein grundlegendes Problem von klassischen Voraussetzungstests. Wie bei anderen statistischen Tests auch, ist die Power bei kleinen Stichproben ebenfalls entsprechend klein. Da die Voraussetzung nur verworfen wird, wenn der Test signifikant ist, passiert es bei kleinen Stichproben und geringer Power sehr leicht, dass ein $\beta$-Fehler begangen wird, die Voraussetzung also angenommen wird, obwohl sie eigentlich verletzt ist. Auf der anderen Seite passiert es bei großen Stichproben leicht, dass der Test schon auf kleine Verletzungen der Voraussetzung reagiert und diese verworfen wird, obwohl das Testverfahren eigentlich robust genug wäre. Deswegen sollte man die Normalverteilung auf jeden Fall auch optisch prüfen!

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
