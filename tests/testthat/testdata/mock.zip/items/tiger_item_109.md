# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

109

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
knowledge

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie rechnen eine Regressionsanalyse mit zwei Prädiktoren und bestimmen die standardisierten Regressionsgewichte. Was bedeutet der y-Achsenabschnitt inhaltlich?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Der y-AAS in der standardisierten Regression entspricht der durchschnittlichen Person, sowohl auf beiden Prädiktoren als auch auf dem Kriterium.

# answeroption_02
Der y-AAS in der standardisierten Regression entspricht der Steigung, also wie stark sich das Kriterium voraussichtlich verändert, wenn die beiden Prädiktoren um eine Einheit steigen.

# answeroption_03
Der y-AAS in der standardisierten Regression entspricht der Standardabweichung und beträgt somit immer 1.

# answeroption_04
Der y-AAS in der standardisierten Regression entspricht dem Interzept, also dem vorausgesagten Wert, wenn alle Prädiktoren den Wert null annehmen.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Da in der standardisierten Regression alle Mittelwerte auf 0 genormt werden, entspricht der y-Achsenabschnitt genau der durchschnittlichen Person. Die Regressionsgerade geht somit durch den Ursprung und es gibt kein Interzept ($b_{0s}$ = 0).

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Nicht der y-AAS entspricht der Steigung, sondern die jeweiligen Regressionsgewichte $b_{1s}$ und $b_{2s}$ der Prädiktoren. Überlegen Sie, wie sich die Standardisierung auf den y-AAS im Vergleich zur unstandardisierten Regresssion auswirkt.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
In der standardisierten Regression nimmt der y-Achsenabschnitt zwar einen konstanten Wert an, aber er entspricht nicht der Standardabweichung. Überlegen Sie stattdessen, was bei der standardisierten Regression mit den Mittelwerten passiert.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überlegen Sie, was durch die Standardisierung mit dem Interzept passiert.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
