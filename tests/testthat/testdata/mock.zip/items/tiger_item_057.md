# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

57

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
Grundlagen der Inferenzstatistik

# type_item
 
<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy 

# stimulus_text
Im Studiengang Psychologie befinden sich aufgrund des hohen NCs bekannterweise hauptsächlich Studierende mit einer überdurchschnittlichen Abiturnote. Im Wintersemester 23/24 wurde nun erstmals der BaPsy Studieneignungstest eingesetzt, weil man auch Abiturient*innen mit einem schlechteren Abiturschnitt die Chance geben wollte, Psychologie zu studieren und weil man die Abiturnote allein nicht mehr als ausreichendes Beurteilungskriterium zur Eignung für den Studiengang empfand.
Vor der Einführung des BaPsy hatten Psychologiestudierende an der Goethe Universität (fiktiv) im Schnitt 803 Punkte im Abitur.
Sie interessieren sich nun dafür, ob der BaPsy tatsächlich den Abiturdurchschnitt in Ihrem Jahrgang verschlechtert hat oder nur ein weiteres Instrument darstellt, um soziale Ungerechtigkeit zu fördern, da vielleicht nur Abiturient*innen mit einem sowieso schon sehr guten Notenschnitt am BaPsy teilnehmen. 
Zu diesem Zweck fragen Sie einige Kommiliton*innen nach ihren Abiturpunkten und erhalten folgende Werte: 743, 845, 707, 686, 811, 599, 711.
Sie sind zunächst positiv überrascht über die große Schwankung der Noten. Sie wissen jedoch auch, dass eine hohe Schwankung die Wahrscheinlichkeit verringert, dass Ihr inferenzstatistischer Test signifikant ausfällt.
Testen Sie auf Grundlage dieser Daten, ob unter dem Einsatz des BaPsy die Abiturpunkte an Ihrer Uni im Schnitt geringer ausfallen als früher, verwenden Sie ein Alpha Niveau von 5%. 
Welcher ist der korrekte p-Wert? 
<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
0.026
# answeroption_02
0.053
# answeroption_03
< 0.001
# answeroption_04
0.199
# answeroption_05

# answeroption_06

Frage überspringen.

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->

# answer_correct
1
<!-- Numerisch (Integer) -->


# type_stimulus
text
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->

# type_answer
text
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->

# if_answeroption_01
Sehr gut, Sie haben erkannt, dass es sich um einen Einstichproben-t-Test handelt und diesen korrekt umgesetzt!
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_02
Sie haben zwar den richtigen Test ausgewählt, jedoch müssen Sie beachten, ob es sich um eine gerichtete oder ungerichtete Hypothese handelt.  
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_03
Überlegen Sie noch einmal, welchen inferenzstatistischen Test Sie anwenden müssen, wenn die Standardabweichung der Population unbekannt ist.
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_04
Schauen Sie sich noch einmal die Formel für den Einstichproben-t-Test an und überlegen Sie, ob Sie den Standardfehler korrekt bestimmt haben.  
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
