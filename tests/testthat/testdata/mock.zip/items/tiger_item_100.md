# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

100

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
knowledge

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text
<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind als Sozialpädagog\*in tätig und untersuchen, welche Eigenschaften der Eltern das Ausmaß an Kindesvernachlässigung vorhersagen können. Sie betrachten in Ihrer Regressionsanalyse Skalenwerte von drei verschiedenen unabhängigen Variablen: emotionale Erschöpfung, Entfremdung in der Partnerschaft und Partnerschaftskonflikte. Vor allem interessiert Sie aber, ob die Entfremdung in der Partnerschaft und das Ausmaß an Partnerschaftskonflikten das $R^2$ signifikant in Ihrem Modell mit den drei genannten Variablen erhöhen, um vielleicht mal ein paar Eltern eine Paartherapie ans Herz zu legen. Dabei erinnern Sie sich daran, dass Sie dies ganz einfach mit der anova-Funktion in R herausfinden können. Beim Betrachten Ihres Ergebnisses haben Sie jedoch das Gefühl, dass Sie etwas falsch gemacht haben. Ist hier etwas schiefgelaufen und wenn ja, was?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->
www/tiger_item100_stimulus.png

# answeroption_01
Das Modell wurde nicht korrekt aufgestellt. Hier wurden Partnerschaftskonflike und Entfremdung als zusätzliche Variablen aufgenommen, aber eigentlich hätte die Erschöpfung als zusätzliche Variable aufgenommen werden sollen.

# answeroption_02
Die Modelle wurden in der falschen Reihenfolge aufgenommen. Im anova-Befehl muss zuerst das eingeschränkte und dann das uneingeschränkte Modell stehen.

# answeroption_03
Es gibt nichts ungewöhnliches zu sehen, der Befehl wurde also korrekt ausgeführt.

# answeroption_04
Der p-Wert ist verdächtig klein. Hier wurde nicht das Varianzinkrement, sondern das $R^2$ insgesamt auf Signifikanz getestet.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
image

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Da Sie das Varianzinkrement der beiden Variablen Entfremdung in der Partnerschaft und Partnerschaftskonflikte testen möchten, benötigen Sie zwei Modelle, die sich nur darin unterscheiden, dass die beiden Variablen einmal berücksichtigt werden und einmal nicht, um den konkreten Einfluss dieser beiden Variablen zu ermitteln. Die Modelle wurden demnach korrekt aufgestellt. Überlegen Sie stattdessen, auf welchen Fehler die negativen Freiheitsgrade in der dritten Spalte der Tabelle hinweisen.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr vorbildlich, wenn Sie auswendig wissen, in welcher Reihenfolge Sie die beiden Modelle eingeben müssen. Die gute Nachricht ist: selbst wenn Sie es nicht auswendig wissen, erkennen Sie ganz leicht, dass Sie die Reihenfolge vertauscht haben, wenn Sie in der dritten Spalte einen negativen Wert für die Freiheitsgrade erhalten.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Auf den ersten Blick scheint das Ergebnis zwar solide zu sein, betrachten Sie jedoch die Tabelle genauer, sollte Ihnen auffallen, dass die Freiheitsgrade in der dritten Spalte negativ sind. Überlegen Sie, auf welchen kleinen Fehler das hindeutet.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Der anova-Befehl ist zum Testen eines Varianzinkrements genau der richtige und auch die Modelle wurden korrekt aufgestellt. Ein so kleiner p-Wert ist für ein Varianzinkrement durchaus möglich. Betrachten Sie stattdessen die Tabelle genauer. Die Freiheitsgrade in der dritten Spalte sind negativ, was eigentlich nicht so sein sollte. Welcher kleine Fehler ist hier passiert?

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
