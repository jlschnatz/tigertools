# id_item
8

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
comprehension

# theo_diff
medium

# stimulus_text
In einer Studie wurde die Länge einer bestimmten Fischart aus einem See untersucht. Eine Zufallsstichprobe von 1000 Fischen verzeichnete einen Mittelwert von 52,2 mm und einen Median von 57,4 mm. Welches der folgenden Histogramme repräsentiert am ehesten die Daten aus dieser Studie?

# stimulus_image
NA

# answeroption_01
www/reali_item08_answeropt1.png

# answeroption_02
www/reali_item08_answeropt2.png

# answeroption_03
www/reali_item08_answeropt3.png

# answeroption_04
NA

# answeroption_05
NA

# answeroption_06
www/skip.png

# answer_correct
3

# type_stimulus
text

# type_answer
image

# if_answeroption_01
Der Mittelwert ist kleiner als der Median, was auf eine linksschiefe/rechtssteile Verteilung hindeutet. In dieser Abbildung ist es umgekehrt, der Mittelwert ist größer als der Median.

# if_answeroption_02
Der Mittelwert ist kleiner als der Median, was auf eine linksschiefe/rechtssteile Verteilung hindeutet. Hier sind die Daten ansatzweise normalverteilt, wodurch Mittelwert und Median vergleichbar sind.

# if_answeroption_03
Der Mittelwert ist kleiner als der Median, was auf eine linkssteile/rechtsschiefe Verteilung hindeutet, wie sie auch in dieser Abbildung zu finden ist.

# if_answeroption_04
NA

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

