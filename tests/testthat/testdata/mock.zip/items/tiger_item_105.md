# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

105

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
knowledge

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie lernen für die Statistik Klausur und versuchen dabei vor allem Bezüge zwischen verschiedenen Themen herzustellen, um sich das Lernen zu vereinfachen. Zum Beispiel können Sie sich absolut nicht die Eigenschaften der Regressionsresiduen merken, aber Sie meinen sich zu erinnern, dass zwei der Eigenschaften einem anderen statistischen Maß gleichen. Worum handelt es sich hierbei?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Der Mittelwert besitzt die gleichen Eigenschaften wie die Residuen.

# answeroption_02
Der Median besitzt die gleichen Eigenschaften wie die Residuen.

# answeroption_03
Der Modus besitzt die gleichen Eigenschaften wie die Residuen.

# answeroption_04
Die Varianz besitzt die gleichen Eigenschaften wie die Residuen.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Tatsächlich sind die ersten beiden Eigenschaften der Residuen die gleichen wie die des Mittelwerts. Die Summe aller Regressionsresiduen ist null und die Summe aller quadrierten Residuen ist minimal. Ebenso ist die Summe aller Abweichungen vom Mittelwert null und die Summe aller quadrierten Abweichungen vom Mittelwert minimal. Diese beiden Eigenschaften der Residuen resultieren aus dem Kleinste-Quadrate-Kriterium, welches besagt, dass die Regressionsgleichung so aufgestellt wird, dass die Fehlerquadratsumme, also die Quadratsumme der Residuen, minimal wird.


# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Der Median hat die Eigenschaft, dass die Summe der **absoluten** Abweichungen vom Median minimal ist. Die ersten beiden Eigenschaften der Residuen lauten, dass ihre Summe 0 beträgt und die Summe der quadrierten Residuen minimal ist. Das ist ein kleiner, aber feiner Unterschied. Welches deskriptivstatistische Maß suchen wir also?

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Beim Modus handelt es sich um die häufigste Ausprägung im Datensatz. Der Modus ergibt generell nur bei kategorialen bzw. diskreten Variablen Sinn, bei der Regression betrachten wir allerdings häufiger stetige Variablen.
Überlegen Sie, welches andere deskriptivstatistische Maß Sie kennen, das folgende ähnliche Eigenschaften wie die Residuen besitzt: Die Summe der Residuen ist 0 und die Summe der quadrierten Residuen ist minimal.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Die Varianz ist ein Maß für die Streuung, genauso wie die Residuen abbilden, wie stark die wahren Messwerte von der Regressionsgeraden abweichen. Aus diesem Grund kann man auch leicht annehmen, dass die beiden geteilte Eigenschaften aufweisen. Allerdings ist die Varianz ein Maß für die mittlere quadratische Abweichung der Messwerte vom Mittelwert und wird dementsprechend durch die Anzahl an Personen geteilt. Die Residuen allerdings sind die Abweichungswerte selber, weswegen Varianz und Residuen mathematisch gesehen unterschiedlich sind, aber die Richtung Ihres Ansatzes ist schon mal sehr gut! Überlegen Sie noch mal, die Abweichungen welches anderen deskriptivstatistischen Maßes die gleichen Eigenschaften besitzen wie die Regressionsresiduen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
