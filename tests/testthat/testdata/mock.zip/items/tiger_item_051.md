# id_item
51

# learning_area
Wahrscheinlichkeit

# type_item
coding

# bloom_taxonomy
knowledge

# theo_diff
medium

# stimulus_text
Wie hoch ist die Wahrscheinlichkeit in Prozent, dass eine zufällig ausgewählte Person im Datensatz eine Schlafqualität von 4 oder 5 hat?

# stimulus_image
NA

# answeroption_01
7

# answeroption_02
15

# answeroption_03
22

# answeroption_04
42

# answeroption_05
NA

# answeroption_06

# answer_correct
3

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dies ist die Wahrscheinlichkeit für Personen mit einer Schlafqualität von ausschließlich 5.

# if_answeroption_02
Dies ist die Wahrscheinlichkeit für Personen mit einer Schlafqualität von ausschließlich 4.

# if_answeroption_03

Die Wahrscheinlichkeit, dass eine zufällig ausgewählte Person im Datensatz eine Schlafqualität von 4 oder 5 hat, beträgt 22%. Dies ergibt sich aus der Summe der Personen mit Schlafqualität 4 und Schlafqualität 5, geteilt durch die Gesamtanzahl der Personen im Datensatz, multipliziert mit 100%.


# if_answeroption_04
Dies ist die Wahrscheinlichkeit für Personen mit einer Schlafqualität von ausschließlich 3.

# if_answeroption_05
NA

# if_answeroption_06

