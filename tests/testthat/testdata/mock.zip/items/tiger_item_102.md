# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

102

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Grundlagen der Inferenzstatistik

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie befinden sich im ersten Semester des Psychologiestudiums und sind fasziniert von statistischen Tests. Sie haben recherchiert, dass ein Gummibärchen Ihrer Lieblingsmarke etwa zwei Gramm wiegt und wollen nun empirisch anhand von 85 Gummibärchen untersuchen, ob sich ihr Gewicht im Mittel signifikant von den Angaben des Herstellers unterscheidet und Sie Beschwerde einreichen sollten. Mühevoll haben Sie alle Gewichtsangaben mit der genauesten Waage, die Sie auftreiben konnten, ermittelt und protokolliert. Die Normalverteilungsannahme haben Sie ebenfalls überprüft und die Populationsstandardabweichung aus Ihrer Stichprobe geschätzt. Tatkräftig starten Sie mit der Berechnung für den Einstichproben-z-Test. Können Sie mit einem validen Ergebnis rechnen?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01

Sie erhalten kein valides Ergebnis, weil Sie bei geschätzter Standardabweichung einen t-Test durchführen müssen.

# answeroption_02

Der z-Test führt hier zu einem validen Ergebnis, allerdings ist der t-Test zu bevorzugen.

# answeroption_03

Sie erhalten kein valides Ergebnis, weil sich die t-Verteilung für eine hohe Anzahl von Freiheitsgraden stark von der Normalverteilung unterscheidet.

# answeroption_04

Der z-Test führt hier zu einem validen Ergebnis und liefert sogar ein genaueres Ergebnis als der t-Test.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
An sich haben Sie vollkommen recht damit, dass Sie bei unbekannter Populationsstandardabweichung einen t-Test durchführen sollten. Überlegen Sie allerdings, wie sich die t-Verteilung verändert, je größer die Anzahl der Freiheitsgrade ist, und welcher Verteilung sie sich annähert. 

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Für aureichend große Stichproben und einer entsprechend hohen Anzahl von Freiheitsgraden geht die t-Verteilung in die Normalverteilung über (Daumenregel: n > 30). Deswegen kann in diesem Fall approximativ auch der Einstichproben-z-Test angewendet werden. Trotzdem sollten Sie, wenn möglich, immer den exakten t-Test bevorzugen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
An sich stimmt es, dass Sie bei unbekannter Populationsstandardabweichung einen t-Test durchführen sollten. Überlegen Sie jedoch noch mal, was mit der t-Verteilung passiert, je größer die Anzahl der Freiheitsgrade ist. Haben Sie hier vielleicht etwas verwechselt?

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie können in diesem Fall approximativ auch einen z-Test verwenden, weil eine ausreichend große Stichprobe vorliegt und die t-Verteilung bei ausreichender Anzahl von Freiheitsgraden (Daumenregel: n > 30) in die Standardnormalverteilung übergeht. Allerdings ändert diese Tatsache nichts daran, dass für den Fall, dass die Populationsstandardabweichung aus der Stichprobe geschätzt werden muss, der t-Test formal der richtige Test ist und dieser auch bevorzugt werden sollte.

# if_answeroption_05
<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
