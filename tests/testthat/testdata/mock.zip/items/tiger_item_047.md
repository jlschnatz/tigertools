# id_item
47

# learning_area
Gruppenvergleiche

# type_item
coding

# bloom_taxonomy
application

# theo_diff
medium

# stimulus_text
Teste die Hypothese, ob Menschen mit Schlafstörung einen kürzeren Schlaf haben als Menschen ohne Schlafstörung. Welches ist das korrekte Testergebnis?

# stimulus_image
NA

# answeroption_01
t = 3.02, df = 98, p = .002

# answeroption_02
t = 3.13, df = 80.75, p = .001

# answeroption_03
t = 3.13, df = 80.75, p = .002

# answeroption_04
t = 3.02, df = 98, p = .003

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01

Das ist das korrekte Ergebnis eines einseitigen t-Tests, der die Hypothese testet, dass Menschen mit Schlafstörung einen kürzeren Schlaf haben als Menschen ohne Schlafstörung. Die Varianzhomogenität wurde angenommen, somit wurde der standard t-Test verwendet.


# if_answeroption_02
Dies ist das Ergebnis eines Welch t-Tests, der eingesetzt wird, wenn Varianzhomogenität nicht gegeben ist.

# if_answeroption_03
Dies ist das Ergebnis eines Welch t-Tests, der eingesetzt wird, wenn Varianzhomogenität nicht gegeben ist. Außerdem ist der Test zweiseitig, der nicht die gestellte Hypothese testet.

# if_answeroption_04
Dies ist das Ergebnis einer zweiseitigen Testung und testet somit nicht die gestellte Hypothese.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

