# id_item
44

# learning_area
Deskriptivstatistik

# type_item
coding

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Was ist der Modus der Variable „alleineSchlafen“?

# stimulus_image
NA

# answeroption_01
Alleine

# answeroption_02
Mit Partner

# answeroption_03
Mit Kind

# answeroption_04
Mit Kind+Partner

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01

Der Modus ist die Kategorie, die am häufigsten vorkommt. In diesem Fall ist das "Alleine".

# if_answeroption_02

Überlege nochmal wie der Modus definiert ist.


# if_answeroption_03

Überlege nochmal wie der Modus definiert ist.



# if_answeroption_04

Überlege nochmal wie der Modus definiert ist.



# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

