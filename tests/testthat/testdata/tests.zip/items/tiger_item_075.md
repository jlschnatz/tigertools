# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

75

# learning_area

Deskriptivstatistik

# type_item

coding

# bloom_taxonomy

application

# theo_diff

easy

# stimulus_text

Benutzen Sie für diese Aufgabe bitte den Datensatz ,,airquality‘‘, welcher schon in R integriert sein sollte. Untersuchen Sie erstmal den Datensatz und schauen Sie, ob und wenn ja auf welchen Variablen es fehlende Werte gibt. 

# stimulus_image

# answeroption_01

Es gibt keine fehlenden Werte auf sämtlichen Variablen. 

# answeroption_02

Es gibt insgesamt 44 fehlende Werte, welche ausschließlich auf den Variablen Ozone und Solar.R vorkommen

# answeroption_03

Es gibt insgesamt 37 fehlende Werte, welche nur auf der Variable Ozone vorkommen.


# answeroption_04

Die Variablen Wind, Temperatur, Monat und Tag enthalten zusammen 44 fehlende Werte. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Wie man mit anyNA(airquality) und einer visuellen Inspektion feststellen kann, existieren fehlende Werte im Datensatz. 

# if_answeroption_02

Insgesamt gibt es nur auf den ersten beiden Variablen insgesamt 44 fehlende Werte. Dies kann man mit dem Code 

nas<-is.na(airquality)
colSums(nas)

rausfinden. Zuerst wird kodiert, ob ein Wert NA ist oder nicht und anschließend werden die NAs Spaltenweise aufsummiert. Was resultiert ist eine Übersicht über die Anzahl an NAs pro Spalte. 


# if_answeroption_03

Überprüfen Sie nochmal, ob es noch weitere fehlende Werte gibt. 

# if_answeroption_04

Überprüfen Sie nochmal, auf welchen Variablen die fehlenden Werte vorkommen.  

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
