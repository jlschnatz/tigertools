# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

88

# learning_area

Deskriptivstatistik

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Sie haben eine neue Stelle als Mitarbeiter\*in in einem Unternehmen angenommen. Einer Ihrer Aufgaben ist es, die Effizienz von Abläufen zu kontrollieren. Ihr neuer Chef ist allerdings etwas zu sehr hinterher, sicherzustellen, dass Sie Ihre Arbeit auch erledigen. Um dies zu tun, sendet er Ihnen gefühlt tausende an E-Mails jeden Tag, in denen er sich über den Stand der Arbeit erkundigt. Wenn Sie diese nicht innerhalb von 10 Minuten beantworten, kommt er persönlich vorbei, um Sie daran zu erinnern. Ihnen geht das Ganze auf den Senkel und Sie fangen an zu dokumentieren, wie viel Arbeitszeit täglich für das Beantworten der unnötigen Mails draufgeht. Dafür haben Sie nach einer Woche folgende Daten: 


||Montag|Dienstag|Mittwoch|Donnerstag|Freitag|
|---|:---:|:---:|:---:|:---:|:---:|
|Unnötige Mails|21|16|25|21|15|
|Benötigte Zeit (in Minuten)|92|50|104|82|69|


Sie möchten nun in einem Effizienzbericht an Ihrem Beispiel berichten, wie lange das Beantworten einer unnötigen E-Mail im Durchschnitt dauert. Welche Antwort ist korrekt?


# stimulus_image


# answeroption_01

Im Durchschnitt dauert das Beantworten einer E-Mail 79.40 Minuten, also 79 Minuten und 24 Sekunden. 

# answeroption_02

Im Durchschnitt dauert das Beantworten einer E-Mail 4.03 Minuten, also grob 4 Minuten und 2 Sekunden. 

# answeroption_03

Im Durchschnitt dauert das Beantworten einer E-Mail 20.17 Minuten, also grob 20 Minuten und 10 Sekunden.

# answeroption_04

Im Durchschnitt dauert das Beantworten einer E-Mail 4.05 Minuten, also grob 4 Minuten und 3 Sekunden. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Sie haben die durchschnittliche Beantwortungszeit **pro Tag**, jedoch soll hier die durchschnittliche Zeit **pro Mail** berechnet werden.

# if_answeroption_02

Sie haben in Ihrer Rechnung jeden Tag gleich gewichtet. Jedoch müssen Sie beachten, dass an unterschiedlichen Tagen unterschiedlich viele Mails beantwortet wurden und die Tage somit unterschiedlich gewichtet werden müssen.

# if_answeroption_03

Schauen Sie nochmal in die Formel für den Mittelwert und prüfen Sie anhand derer Ihre Berechnung. Sie müssen zunächst die Summe der Mails bilden und die Gesamtzeit berechnen und anschließend die beiden Werte durcheinander teilen.

# if_answeroption_04

Sie haben den Mittelwert richtig berechnet. Dafür haben Sie die Mails aufsummiert und die Gesamtzeit berechnet und anschließend die Gesamtzeit durch die Gesamtanzahl der Mails geteilt.

# if_answeroption_05



# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
