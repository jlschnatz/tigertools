# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

115

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Grundlagen der Inferenzstatistik

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding


# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind begeisterte\*r Zuschauer\*in von "Die Höhle der Löwen" und beschäftigen sich daher in Ihrer Freizeit sehr gerne mit Startups. Sie haben dazu einen Datensatz gefunden, der ihnen ganz interessant vorkommt, worin es um Einstellungsentscheidungen in Startups geht. Tatkräftig laden Sie sich den Datensatz in R herunter mit folgendem Befehl: `load(url("https://pandar.netlify.app/daten/Assessment.rda"))`. Sie kennen in Ihrem Umfeld viele junge Menschen, die Schwierigkeiten haben, einen passenden Job zu finden, weil die Unternehmen Personen mit mehr Berufserfahrung bevorzugen. Deswegen wollen Sie untersuchen, in welchem Alter Start Ups neue Mitarbeitende bevorzugt einstellen und berechnen dazu ein Konfidenzintervall um den Stichprobenmittelwert. Bitte berechnen Sie das 95%-Konfidenzintervall um den Mittelwert und interpretieren Sie dieses inhaltlich.
Tipp: Sie müssen den Datensatz nach den Personen filtern, die tatsächlich eingestellt wurden (Hired == 1).
 
# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das Konfidenzintervall beträgt: [46.47; 47.54] Richtige Interpretation: Wenn man sehr viele Stichproben gleicher Größe aus derselben Grundgesamtheit ziehen und für jede ein 95%-Konfidenzintervall berechnen würde, dann würden 95% der Stichprobenmittelwerte innerhalb des Intervalls liegen.

# answeroption_02
Das Konfidenzintervall beträgt: [46.47; 47.54]. Richtige Interpretation: Wenn man sehr viele Stichproben gleicher Größe aus derselben Grundgesamtheit ziehen und für jede ein 95%-Konfidenzintervall berechnen würde, dann würden 95% dieser Intervalle den wahren Mittelwert der Grundgesamtheit einschließen.

# answeroption_03
Das Konfidenzintervall beträgt: [44.57; 45.14]. Richtige Interpretation: Wenn man sehr viele Stichproben gleicher Größe aus derselben Grundgesamtheit ziehen und für jede ein 95%-Konfidenzintervall berechnen würde, dann würden 95% der Stichprobenmittelwerte innerhalb des Intervalls liegen.

# answeroption_04
Das Konfidenzintervall beträgt: [44.57; 45.14]. Richtige Interpretation: Wenn man sehr viele Stichproben gleicher Größe aus derselben Grundgesamtheit ziehen und für jede ein 95%-Konfidenzintervall berechnen würde, dann würden 95% dieser Intervalle den wahren Mittelwert der Grundgesamtheit einschließen.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben zwar das Konfidenzintervall richtig berechnet, allerdings stimmt die Interpretation noch nicht ganz. Überlegen Sie, ob das Konfidenzintervall wirklich dazu da ist, etwas über Stichprobenparameter auszusagen.
Tipp: Falls Sie zur Berechnung den umständlichen Weg gewählt haben, lässt sich das Konfidenzintervall bei Datensätzen auch ganz unkompliziert über die Funktion `t.test()` berechnen.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben das Konfidenzintervall richtig berechnet und auch die Interpretation stimmt. 
Kleiner Tipp: Falls Sie zur Berechnung den umständlichen Weg gewählt haben, lässt sich das Konfidenzintervall bei Datensätzen auch ganz unkompliziert über die Funktion `t.test()` berechnen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal darauf, dass Sie den Datensatz zunächst filtern müssen, da nicht das Konfidenzintervall um den Mittelwert für alle Personen aus dem Datensatz gefragt ist. Überlegen Sie außerdem bezüglich der Interpretation, ob das Konfidenzintervall wirklich dazu da ist, etwas über Stichprobenparameter auszusagen.
Tipp: Falls Sie zur Berechnung den umständlichen Weg gewählt haben, lässt sich das Konfidenzintervall bei Datensätzen auch ganz unkompliziert über die Funktion `t.test()` berechnen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal darauf, dass Sie den Datensatz zunächst filtern müssen, da nicht das Konfidenzintervall um den Mittelwert für alle Personen aus dem Datensatz gefragt ist.
Tipp: Falls Sie zur Berechnung den umständlichen Weg gewählt haben, lässt sich das Konfidenzintervall bei Datensätzen auch ganz unkompliziert über die Funktion `t.test()` berechnen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
