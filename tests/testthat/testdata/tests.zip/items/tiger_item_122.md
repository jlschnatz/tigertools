# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

122

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind Gesundheitspsycholog\*in und untersuchen den Alkoholkonsum von Jugendlichen. Aus diesem Grund haben Sie über drei Jahre hinweg eine längsschnittliche Untersuchung durchgeführt und dieselben Jugendlichen im Alter von 14, 15 und 16 Jahren zu ihrem Alkoholkonsum befragt. Laden Sie sich mit folgendem Befehl den Datensatz in R herunter: `load(url("https://pandar.netlify.app/daten/alc.rda"))`
Vor allem interessiert Sie, inwiefern es den Alkoholkonsum beeinflusst, wenn ein Elternteil Alkoholiker\*in ist. Sie denken, dass entweder die Kinder von Alkoholiker\*innen mehr Alkohol konsumieren, weil sie dieses Verhalten von den Eltern lernen (oder genetisch dafür prädestiniert sind) oder weniger, weil sie der krankhafte Konsum der Eltern abschreckt. Dazu wollen Sie zunächst eine zusätzliche Variable erstellen, die abbildet, wie häufig die Jugendlichen durchschnittlich im Alter von 14 (alcuse.14), 15 (alcuse.15) und 16 Jahren (alcuse.16) Alkohol konsumiert haben. Anschließend berechnen Sie in einem Zweistichproben-t-Test, ob sich Kinder von Alkoholiker\*innen (coa == 1) signifikant in ihrem Alkoholkonsum unterscheiden im Vergleich zu Jugendlichen ohne alkoholkrankes Elternteil (coa == 0). 

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Kinder von Alkoholiker\*innen unterscheiden sich signifikant von Kindern von Nicht-Alkoholiker\*innen (t = -3.82, p < .001). Dabei konsumieren die Kinder von Alkoholiker\*innen signifikant mehr Alkohol.

# answeroption_02
Kinder von Alkoholiker\*innen unterscheiden sich signifikant von Kindern von Nicht-Alkoholiker\*innen (t = -3.82, p < .001). Dabei konsumieren die Kinder von Alkoholiker\*innen signifikant weniger Alkohol.

# answeroption_03
Kinder von Alkoholiker\*innen unterscheiden sich signifikant von Kindern von Nicht-Alkoholiker\*innen (t = -3.88, p < .001). Dabei konsumieren die Kinder von Alkoholiker\*innen signifikant mehr Alkohol.

# answeroption_04
Kinder von Alkoholiker\*innen unterscheiden sich signifikant von Kindern von Nicht-Alkoholiker\*innen (t = -3.88, p < .001). Dabei konsumieren die Kinder von Alkoholiker\*innen signifikant weniger Alkohol.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überprüfen Sie noch mal die Homoskedastizität.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überprüfen Sie noch mal die Homoskedastizität. Achten Sie auch auf die Mittelwerte der beiden Gruppen.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig erkannt, dass die Gruppen homoskedastisch sind und deswegen keine Welch-Korrektur durchgeführt werden muss. Auch die Mittelwerte der Gruppen haben Sie richtig interpretiert.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf die Mittelwerte der beiden Gruppen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
