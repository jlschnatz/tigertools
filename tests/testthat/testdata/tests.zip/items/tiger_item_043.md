# id_item
43

# learning_area
Deskriptivstatistik

# type_item
coding

# bloom_taxonomy
comprehension

# theo_diff
easy

# stimulus_text
50% der Teilnehmenden betreiben pro Woche mindestens ... Minuten Sport.

# stimulus_image
NA

# answeroption_01
76.5

# answeroption_02
77

# answeroption_03
105.12

# answeroption_04
106

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dies ist der Median und somit die korrekte Antwort.

# if_answeroption_02
77 Minuten beinhaltet weniger als 50% der Teilnehmenden.

# if_answeroption_03
Dies ist der Mittelwert, nach dem nicht gefragt wurde.

# if_answeroption_04
Dies ist der gerundete Mittelwert, nach dem nicht gefragt wurde.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

