# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

70

# learning_area

Regression

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Sie und Ihre Kommilitonin schreiben zur Übung Skripte zur Erstellung von Regressionen. Dabei wollen Sie nun eine Regression mit einem Beta-Gewicht von 0.4 und 0.2 erstellen. Folgende 2 Skripte schreiben Sie jeweils (siehe unten). 

Überrascht stellen Sie fest, dass Ihre Outputs sich stark ähneln, aber nicht identisch sind. Welche Unterschiede werden Ihnen auffallen?

# stimulus_image

www/tiger_item070_stimulus.png

# answeroption_01

Die Signifikanz von den Regressionsgewichten und des R2 sind unterschiedlich, die Beta-Gewichte sind aber gleich.

# answeroption_02

Die Signifikanz der Regressionsgewichte und des R2 sind identisch, die Beta-Gewichte unterscheiden sich aber.

# answeroption_03

Die Signifikanz der Regressionsgewichte und des R2 sind verschieden und die Beta-Gewichte unterscheiden sich auch.

# answeroption_04

Bis auf die Residuen hat sich nichts geändert, da die Regression invariant gegenüber den zulässigen Transformationen ist. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Überlegen Sie noch mal, wofür der Befehl scale() verwendet wird und ob dieser wirklich die Signifikanz verändert.

# if_answeroption_02

Da Ihre Kommiltonin vor Ihrer Regression standardisiert hat (siehe Zeilen 26-28), verwendet sie die standardisierte Regressionsgewichte statt den unstandardisierten. Folglich unterscheiden sich die Regressionsgewichte. Allerdings ist die Signifikanz des Regressionsgewichts immer noch identisch, da sich auch der Standardfehler im gleichen Maße wie das Regressionsgewicht ändert, sodass immer der gleiche t-Wert und der gleiche p-Wert trotz verschiedener (zulässigen positiv linearen) Transformationen und Regressionsgewichte resultiert. Auch das $R^2$ bleibt als Varianzaufklärung unverändert. Unsere Vorhersage verbessert/verschlechtert sich ja durch die Transformation der Werte nicht. Wir können uns dem auch logisch nähern: Nehmen wir mal an, Signifikanz und $R^2$ würden sich bei Transformation ändern. Dann könnte man ja seine Daten solange rumtransformieren, bis einem $R^2$ und Signifikanz passen. Das wäre für den wissenschaftlichen Prozess der Erkenntnisgewinnung höchst problematisch.

# if_answeroption_03

Überlegen Sie noch mal, wofür der Befehl scale() verwendet wird und welche Auswirkungen das auf Ihre Regressionsparameter hat.

# if_answeroption_04

Regressionsgewichte sind nicht invariant gegenüber Transformationen. Überlegen Sie, welche Transformation der Befehl scale() bewirkt und wie sich das auf die Regressionsparameter auswirkt.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
