# id_item

1

# learning_area

Deskriptivstatistik

# type_item

content

# bloom_taxonomy

application

# theo_diff

easy

# stimulus_text

Eine Gymnasiallehrerin ist besorgt darüber, ob ihre Schüler\*innen genug Schlaf bekommen. Sie bat deswegen alle Schüler\*innen, die Anzahl der in der letzten Nacht geschlafenen Stunden anzugeben. Die Ergebnisse sind im Folgenden grafisch dargestellt.

# stimulus_image

www/reali_item01_stimulus.png

# answeroption_01

Die Werte gehen von 3 bis 10, wobei sie bis 7 ansteigen und dann bis 10 abfallen. Die meisten Werte liegen bei 7. Zwischen den Werten 3 und 5 gibt es eine Lücke.

# answeroption_02

Die Verteilung ist normal, mit einem Mittelwert von etwa 7 und einer Standardabweichung von etwa 1.

# answeroption_03

Viele Schüler scheinen nachts 7 Stunden Schlaf zu bekommen, einige Schüler haben jedoch mehr und andere weniger geschlafen. Ein Schüler muss jedoch sehr lange aufgeblieben sein und hat nur sehr wenige Stunden Schlaf bekommen.

# answeroption_04

Die Verteilung der Schlafstunden ist einigermaßen normal, mit einem Ausreißer bei 3. Die typische Schlafdauer beträgt etwa 7 Stunden und die Standardabweichung liegt bei 1 Stunde.

# answeroption_05

NA

# answeroption_06

Frage überspringen.

# answer_correct

4

# type_stimulus

image

# type_answer

text

# if_answeroption_01

Auch wenn die Beschreibung als solches richtig ist, verwendet sie rein umgangssprachliche Beschreibungen und nicht die gewünschte "angemessene statistische Terminologie". Auch fehlt die Einordnung in den Kontext.

# if_answeroption_02

Während diese Beschreibung zwar die gewünschte "angemessene statistische Terminologie" beinhaltet, fehlt leider die Einordnung in den Kontext. Hier hören wir alle Mathelehrer*innen im Chor: "Sieben was? Sieben Fußballfelder? Sieben Wassermelonen?".

# if_answeroption_03

Korrekte Beschreibung und Interpretation, aber es fehlt die gewünschte "angemessene statistische Terminologie".

# if_answeroption_04

Die Daten werden in den eigentlichen Kontext der Erhebung gerückt und statistisch beschrieben, wie gewünscht.

# if_answeroption_05

NA

# if_answeroption_06

Alles klar! Du hast die Aufgabe übersprungen.

