# id_item
42

# learning_area
Wahrscheinlichkeit

# type_item
coding

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Welche der folgenden Aussagen beschreibt am besten die Verteilung der Variable „durchschnittsnote“?

# stimulus_image
NA

# answeroption_01
Eine linkssteile Verteilung.

# answeroption_02
Eine linksschiefe Verteilung.

# answeroption_03
Eine Normalverteilung.

# answeroption_04
Eine bimodale Verteilung.

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Die Verteilung ist linkssteil und rechtsschief.

# if_answeroption_02
Die Verteilung ist nicht linksschief, sondern rechtsschief.

# if_answeroption_03
Dafür ist die Verteilung zu schief.

# if_answeroption_04
Einen Hinweis auf Bimodalität gibt es nicht.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

