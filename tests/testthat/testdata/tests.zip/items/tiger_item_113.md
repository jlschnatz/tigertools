# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

113

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie untersuchen Zusammenhänge zwischen verschiedenen Persönlichkeitsmerkmalen und Depressionen. Die bisherige Forschung ergab beispielsweise, dass das standardisierte Regressionsgewicht von Neurotizismus in der Vorhersage von Depressivität 0.7 beträgt. Sie haben allerdings das Gefühl, dass der Zusammenhang bisher unterschätzt wurde. Also führen Sie selbst eine Analyse mit Ihren eigens erhobenen Daten durch. Laden Sie sich in R den Datensatz herunter `load(url("https://pandar.netlify.app/daten/Depression.rda"))`, berechnen Sie das standardisierte Regressionsgewicht von Neurotizismus (ohne Einbezug weiterer Variablen) und testen Sie, ob Sie mit Ihrer Vermutung richtig lagen. Achten Sie noch darauf, dass die Variable Neurotizismus erst noch invertiert werden muss, da diese im ursprünglichen Datensatz die emotionale Stabilität abbildet (also je niedriger, desto höher der Neurotizismus).

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie gehen davon aus, dass Ihre Vermutung richtig war mit p = 0.039.

# answeroption_02
Sie gehen davon aus, dass Ihre Vermutung nicht richtig war mit p = 0.079.

# answeroption_03
Sie gehen davon aus, dass Ihre Vermutung richtig war mit p < 0.001.

# answeroption_04
Sie gehen davon aus, dass Ihre Vermutung nicht richtig war mit p = 0.073.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie darauf, dass hier das standardisierte Regressionsgewicht getestet werden soll.


# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie darauf, dass hier das standardisierte Regressionsgewicht getestet werden soll. Überlegen Sie noch mal, was das für die Berechnung des Standardfehlers bedeutet.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Schauen Sie sich noch mal den Aufgabentext an und überlegen Sie, was in diesem Fall die $H_{0}$ ist.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtig erkannt, dass Sie das standardisierte Regressionsgewicht gegen $\beta_{0}$ = 0.7 testen müssen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
