# id_item
4

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Eine Dozentin gab den Studierenden eine Umfrage zur Einführung in die Statistik. Eine der Fragen lautete: "Bewerten Sie Ihre Zuversicht, dass Sie in diesem Kurs erfolgreich sein werden, auf einer Skala von 1 bis 10", wobei 1 = geringste Zuversicht und 10 = höchste Zuversicht. Nach der Auswertung der Antworten der Studierenden interpretierte die Dozentin die Daten wie folgt: "Die Mehrheit der Studierenden in der Vorlesung glaubt nicht, dass sie in Statistik erfolgreich sein werden, obwohl einige wenige zuversichtlich sind, es zu schaffen." Die Dozentin bat zwei ihrer Studierenden, eine grafische Darstellung der Daten auf der Grundlage ihrer obigen Interpretation zu erstellen. Beth erstellte einen Dotplot und Allan einen Boxplot. Welches Dotplot/Boxplot-Paar entspricht am ehesten der Beschreibung der Dozentin?

# stimulus_image
NA

# answeroption_01
www/reali_item04_answeropt1.png

# answeroption_02
www/reali_item04_answeropt2.png

# answeroption_03
www/reali_item04_answeropt3.png

# answeroption_04
www/reali_item04_answeropt4.png

# answeroption_05
NA

# answeroption_06
www/skip.png

# answer_correct
4

# type_stimulus
text

# type_answer
image

# if_answeroption_01
Hier haben sowohl Beth als auch Allen fälschlicherweise Daten dargestellt, in denen die Studierenden eine hohe Zuversicht haben, in Statistik erfolgreich zu sein.

# if_answeroption_02
Während Beth Daten dargestellt hat, in denen die Studierenden wenig Zuversicht haben, hat Allen fälschlicherweise Daten dargestellt, in denen die Studierenden viel Zuversicht haben.

# if_answeroption_03
Während Beth flälchlicherweise Daten dargestellt hat, in denen die Studierenden viel Zuversicht haben, hat Allen Daten dargestellt, in denen die Studierenden wenig Zuversicht haben.

# if_answeroption_04
Sowohl Beth als auch Allen haben Daten dargestellt, in denen die Studierenden wenig Zuversicht haben.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

