# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

101

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Deskriptivstatistik

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
knowledge

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie haben mithilfe eines Online-Fragebogens die Ausprägungen Ihrer Mitstudierenden auf den Big-5-Persönlichkeitsmerkmalen untersucht und die Daten in einem Datensatz (bigfive) abgelegt. Zusätzlich haben Sie die Zeit erhoben, die Ihre Kommiliton\*innen zur Bearbeitung des gesamten Fragebogens benötigt haben. Nun wollen Sie die Stichprobenvarianz der Variable Zeit (time) berechnen, um feststellen zu können, wie unterschiedlich die Studierenden in ihrem Bearbeitungstempo sind. Sie führen dazu in R folgenden Code durch:
```
x <- bigfive$time
n <- length(x)
x_bar <- mean(x)
varianz <- sum(x-x_bar)^2/n 
```
Als Sie sich allerdings das Ergebnis ausgeben lassen, erscheint Ihnen dieses sonderbar. Was ist hier schiefgelaufen?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01

Sie müssen noch die Wurzel ziehen.

# answeroption_02

Sie müssen durch n-1 teilen.

# answeroption_03

Sie haben eine Klammer vergessen.

# answeroption_04

An der Formel ist alles richtig. Sie haben die Varianz einfach nur schlecht eingeschätzt, wenn Ihnen das Ergebnis sonderbar vorkommt.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen

# answer_correct

<!-- Numerisch (Integer) -->
3


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Die Wurzel ziehen müssen Sie nur, wenn Sie die Standardabweichung berechnen wollen. Gehen Sie stattdessen gedanklich die letzte Zeile des Codes durch. Was ist das Ergebnis der Summe, die hier gebildet wird? Kleiner Tipp: Es handelt sich um eine Eigenschaft des Mittelwerts, die in der Vorlesung behandelt wurde. Wie können Sie dieses kleine Problem beheben?

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie teilen durch n-1, wenn Sie die geschätzte Populationsvarianz aus den Stichprobendaten berechnen wollen. Da hier allerdings die exakte Stichprobenvarianz gefragt ist, müssen Sie nur durch n teilen. Gehen Sie stattdessen gedanklich die letzte Zeile des Codes durch. Was ist das Ergebnis der Summe, die hier gebildet wird? Kleiner Tipp: Es handelt sich um eine Eigenschaft des Mittelwerts, die in der Vorlesung behandelt wurde. Wie können Sie dieses kleine Problem beheben?

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Auf den ersten Blick sieht die Formel eigentlich ziemlich korrekt aus. Wenn Sie allerdings die letzte Zeile des Codes gedanklich durchgehen, würden Sie zunächst die Summe von dem Inhalt der Klammer bilden. Das bedeutet, dass Sie die Abweichungen vom Mittelwert aufsummieren und wenn Sie in der Vorlesung aufgepasst haben, sollten Sie wissen, dass es zu den Eigenschaften des Mittelwerts gehört, dass die Abweichungssumme null beträgt. Um dem entgegenzuwirken, müssen Sie das ^2 ebenfalls in die Klammer der Summe schreiben, damit die Quadratsumme berechnet wird. Sie benötigen also eine zusätzliche Klammer. Lange Rede, kurzer Sinn, hier noch mal die richtige Formel: `varianz <- sum((x - x_bar)^2)/n`

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Ihr mulmiges Gefühl hat Sie nicht getrügt. Wenn Sie die Varianz mit diesem Code berechnen, wird Ihr Ergebnis null betragen. In der Tat ist hier also etwas schiefgelaufen, mit der Voraussetzung, dass es sich bei der Variable nicht um eine Konstante handelt (denn dann wäre die Varianz tatsächlich 0). Gehen Sie gedanklich die letzte Zeile des Codes durch. Was ist das Ergebnis der Summe, die hier gebildet wird? Kleiner Tipp: Es handelt sich um eine Eigenschaft des Mittelwerts, die in der Vorlesung behandelt wurde. Wie können Sie dieses kleine Problem beheben?

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
