# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

85

# learning_area

Regression

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

medium
 
# stimulus_text

Um sich auf die Klausur vorzubereiten, rechnet Hans eine Regression. Dazu simuliert er sich zunächst die Daten. Er möchte in seinem fiktiven Szenario untersuchen, inwiefern die Anzahl an der Wohnung nahestehenden Bäume und der Grad der Luftverschmutzung mit der Lebenszufriedenheit zusammenhängen. Er simuliert dementsprechend mit dem folgenden Code die Daten: 

```
set.seed(2)
Bäume_in_umgebung<- runif(218,5,100) |> round()
Bäume_in_umgebung_skaliert<- scale(Bäume_in_umgebung)
Luftverschmutzung<- runif(218,5,100)

Lebenszufriedenheit<- 0.2*Bäume_in_umgebung+0.4*Bäume_in_umgebung_skaliert+ 0.9*Luftverschmutzung+rnorm(218,0,100)
```
Nachdem das Simulieren der Daten geklappt hat, möchte er nun händisch die Regressionsgewichte bestimmen. Dafür schreibt er folgenden Code: 
```
#Matrix X erstellen
einsenvektor<- rep(1,218)
matX<- matrix(c(einsenvektor,Bäume_in_umgebung,Bäume_in_umgebung_skaliert,Luftverschmutzung),ncol=4)

#Formel umsetzen (X’X)^(-1)*X’y
solve(t(matX)%*%matX)%*%t(matX)%*%Lebenszufriedenheit
```
Aber oh Schreck: R gibt ihm einen Fehler aus! Hans überprüft seine Datensimulation und seine Rechnung doppelt und dreifach, findet aber nichts, was falsch ist. Alles ist genau so wie in der Formel und wie in der Vorlesung besprochen. Völlig verzweifelt sitzt er vor der immergleichen Fehlermeldung: 
```
Fehler in solve.default(t(matX) %*% matX) : 
  System ist für den Rechner singulär: reziproke Konditionszahl = 5.09387e-20
```

Am Ende seiner Fähigkeiten angelangt bittet er Sie nun um Hilfe. Was ist der Grund für die Fehlermeldung?



# stimulus_image


# answeroption_01

Statt der transponierten Matrix von X hätte Hans stattdessen die untransponierte Matrix verwenden müssen.

# answeroption_02

Zwei Spalten der Matrix stehen in linearer Abhängigkeit. 

# answeroption_03

Er hätte die Lebenszufriedenheit vorher als Matrix abspeichern müssen. 

# answeroption_04

Er hätte keinen Einsenvektor bei der Erstellung von Matrix X hinzufügen dürfen. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Die Formel ist korrekt umgesetzt und an den Stellen, wo Hans mit einer transponierten Matrix gearbeitet hat, gehört auch eine hin. Achten Sie eher auf die Auswahl der Vektoren, die in der Matrix zusammengeführt wurden und überlegen Sie, ob die Matrix invertierbar ist.

# if_answeroption_02

Hans hat nicht bedacht, dass er sowohl die Variable Bäume_in_umgebung als auch die Variable Bäume_in_umgebung_skaliert in seine Regressionsgleichung als unabhängige Variablen aufgenommen hat. Da aber beide Variablen die exakt gleiche Information erhalten (da die skalierte Variable ja nur eine Transformation der nicht skalierten Variable darstellt), wird die Matrix X’X singulär (wie R uns auch in der Fehlermeldung sagt). Aus einer singulären Matrix (Determinante = 0) lässt sich keine Inverse bilden. Darauf weist uns R in der Fehlermeldung auch hin: Fehler in solve(). Entsprechend darf Hans nur eine der beiden Variablen in die Regression aufnehmen, damit die Berechnung der Beta-Gewichte funktioniert. 

Aber: Der lm-Befehl kommt in diesem Fall trotzdem zu einem Ergebnis, allerdings nur, weil schlaue Menschen für so einen Fall mit identischen Informationen einprogrammiert haben, dass ein Regressionsgewicht nicht geschätzt wird. Dieses erscheint dann als NA. 


# if_answeroption_03

R kommt bei der Matrixmultiplikation auch mit Vektoren klar, die dann wie Matrizen mit einer Spalte behandelt werden. Mit dem Befehl is.matrix(Lebenszufriedenheit) wird R Ihnen sogar ausgeben, dass es sich um eine Matrix handelt.
Achten Sie eher auf die Auswahl der Vektoren, die in der Matrix (matX) zusammengeführt wurden und überlegen Sie, ob die Matrix invertierbar ist.

# if_answeroption_04

Der Einsenvektor ist wichtig dafür, dass ein b_0 geschätzt wird und führt nicht zu dieser Fehlermeldung. Der Fehler liegt bei einer anderen Spalte der Matrix. Überlegen Sie, ob diese Matrix invertierbar ist. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
