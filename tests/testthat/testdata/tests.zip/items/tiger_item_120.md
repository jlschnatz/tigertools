# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

120

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind leidenschaftliche\*r Zuschauer\*in von "Die Höhle der Löwen", weswegen Sie sich für alles begeistern, was mit Start Ups zu tun hat. Sie haben neulich einen Datensatz gefunden, worin es um Einstellungsentscheidungen in Startups geht. Tatkräftig laden Sie sich  mit folgendem Befehl den Datensatz in R herunter: `load(url("https://pandar.netlify.app/daten/Assessment.rda"))`. Sie kennen in Ihrem Umfeld außerdem viele junge Menschen, die Schwierigkeiten haben, einen passenden Job zu finden, weil die Unternehmen Personen mit mehr Berufserfahrung bevorzugen. Deswegen interessiert Sie besonders, ob selbst junge Unternehmen wie Start Ups bevorzugt ältere Personen einstellen. Bevor Sie allerdings mit der Testung beginnen, wollen Sie zunächst die Voraussetzungen prüfen. Entscheiden Sie auf dieser Grundlage, welcher Test für Ihre Forschungsfrage am besten geeignet ist.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie testen Ihre Hypothese mit einem Zweistichproben-t-Test für abhängige Stichproben.

# answeroption_02
Sie testen Ihre Hypothese mit einem Wilcoxon-Rangsummentest für unabhängige Stichproben.

# answeroption_03
Sie testen Ihre Hypothese mit einem Zweistichproben-t-Test für unabhängige Stichproben ohne Welch-Korrektur.

# answeroption_04
Sie testen Ihre Hypothese mit einem Zweistichproben-t-Test für unabhängige Stichproben mit Welch-Korrektur.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Eine abhängige Stichprobe besteht nur, wenn entweder dieselbe Person beide Bedingungen durchläuft oder jede Person aus der einen Gruppe mit einer Person aus der anderen Gruppe aufgrund bestimmter Eigenschaften gepaart ist.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Vermutlich wollen Sie den Wilcoxon-Test verwenden, weil die Normalverteilungsannahme laut dem Shapiro-Test verworfen werden muss. Wenn man sich allerdings den QQ-Plot anschaut, bemerkt man einerseits, dass der Plot kaum von der Normalverteilung abweicht und dass diese kleine Abweichung eher zustande kommt, weil das Alter durch die Angabe in ganzen Jahren nicht ganz stetig ist. Dadurch entsteht die Zickzack-Linie im QQ-Plot. Andererseits ist die Stichprobe so groß, dass auch bei Verletzung der Normalverteilung der zentrale Grenzwertsatz greift und trotzdem ein t-Test zulässig ist. Da die Forschungsfrage sich auf den Vergleich von Mittelwerten und nicht von Medianen bezieht, ist der t-Test auch die bessere Wahl.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überprüfen Sie noch mal die Homoskedastizität mit einem geeigneten Verfahren.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig erkannt, dass Sie trotz leichter Verletzung der Normalverteilung einen Zweichstichproben-t-Test durchführen können, da die Stichprobe sehr groß ist (für Begründung siehe zentraler Grenzwertsatz). Die Homoskedastizität haben Sie richtigerweise angenommen (Prüfung mittels beispielsweise Levene-Test), weswegen keine Welch-Korrektur nötig ist.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
