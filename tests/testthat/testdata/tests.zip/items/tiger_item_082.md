# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

82

# learning_area

Zusammenhangsmaße

# type_item

content

# bloom_taxonomy

application

# theo_diff

medium

# stimulus_text

In einer Studie untersuchen Sie den Zusammenhang zwischen Psychopathie und Körpergröße. Dabei gehen Sie davon aus, dass kleinere Personen höhere Psychopathiewerte haben als größere. Allerdings sind Studien, welche von äußeren Merkmalen auf die Persönlichkeit schließen, ethisch diskutabel und die Ergebnisse möglicherweise verzerrt. Aus diesem Grund möchten Sie nur Korrelationen testen, die signifikant über $\rho=-0.3$ liegen. Sie erheben für Ihre Studie insgesamt 212 Personen und finden eine Korrelation von -0.4. 

Geben Sie die geeignete Prüfgröße an. 



# stimulus_image


# answeroption_01

Die geeignete Prüfgröße ist -1.64 und somit nicht statistisch bedeutsam.

# answeroption_02

Die geeignete Prüfgröße ist -0.42 und somit nicht statistisch bedeutsam.

# answeroption_03

Die geeignete Prüfgröße ist -1.46 und somit nicht statistisch bedeutsam.

# answeroption_04

Die geeignete Prüfgröße ist -6.32 und somit statistisch bedeutsam.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Sie haben richtig beachtet, dass es sich hier um einen Test gegen eine andere Korrelation als 0 handelt. Dafür müssen Sie die gefundene Korrelation Fisher-Z-transformieren, sodass die Stichprobenkennwerteverteilung sich der Normalverteilung annähert. Zusätzlich benötigen Sie noch Erwartungswert und Standardfehler. Mit diesen drei Werten können Sie die Prüfgröße mit einem Einstichproben-z-Test berechnen (statt wie bei dem Test gegen 0 mit einem t-Test).


# if_answeroption_02

Sie haben richtig erkannt, dass Sie die Stichprobenkorrelation Fisher-Z-transformieren müssen, da wir gegen einen anderen Wert als 0 testen. Nur leider ist das noch nicht unsere Prüfgröße. Sie benötigen zusätzlich noch den Erwartungswert und den Standardfehler, um die Prüfgröße berechnen zu können.

# if_answeroption_03

Sie haben zwar richtig erkannt, dass wir gegen einen anderen Wert als 0 testen, jedoch haben Sie den falschen Test angewandt. Bei einem Korrelationstest gegen einen Wert ungleich 0 müssen Sie Ihre Stichprobenkorrelation Fisher-Z-transformieren, um die Stichprobenkennwerterteilung der Standardnormalverteilung anzunähern. Sie benötigen zusätzlich den Erwartungswert und Standardfehler der Verteilung, um anschließend die Prüfgröße zu ermitteln.

# if_answeroption_04

Es handelt sich hier um einen Test gegen eine Korrelation, die ungleich 0 ist. Aus diesem Grund funktioniert die inferenzstatistische Prüfung mit dem t-Test gegen 0 nicht. Überlegen Sie, welchen Test Sie stattdessen verwenden können und welche Transformation Sie dafür durchführen müssen.

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
