# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

67

# learning_area

Gruppenvergleiche

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Es soll da draußen tatsächlich Menschen geben, die regelmäßig Sport treiben. Sie möchten sich der Erforschung dieser außergewöhnlichen Individuen widmen. Sie beobachten, dass viele Jogger\*innen Musik beim Joggen hören. Sie kombinieren dieses Wissen mit ihrem Wissen zur klassischen Konditionierung und erstellen daraus folgende Forschungshypothese: Jogger\*innen haben selbst im Ruhezustand einen höheren Puls, wenn sie Lieder hören, die sie sonst ausschließlich beim Joggen hören im Vergleich zum Puls bei Liedern, die sie sonst nicht beim Joggen hören. Um dieser Hypothese auf den Grund zu gehen, rekrutieren Sie 200 Jogger\*innen und messen ihren Puls ein Mal beim Anhören von Liedern, die beim Joggen gehört werden und ein Mal beim Anhören von Liedern, die sonst nicht beim Joggen gehört werden. Der Ruhepuls der Proband\*innen bei neutralen Liedern liegt im Mittel bei 64. Bei den Liedern fürs Joggen liegt er im Mittel bei 69. Die Differenzwerte haben eine geschätzte Standardabweichung von 15. 

Berechnen Sie zur Prüfung der Hypothese das 99% Konfidenzintervall.  


# stimulus_image

# answeroption_01

Das Konfidenzintervall um die mittlere Differenz von 5 beträgt -∞ bis 7.49.

# answeroption_02

Das Konfidenzintervall um die mittlere Differenz von 5 beträgt 2.51 bis ∞.

# answeroption_03

Das Konfidenzintervall um die mittlere Differenz von 5 beträgt 2.24 bis 7.76.

# answeroption_04

Das Konfidenzintervall um die mittlere Differenz von 5 beträgt 2.51 bis 7.49.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Sie haben zwar das korrekte Signifikanzniveau berücksichtigt und richtigerweise erkannt, dass es eine gerichtete Testung ist. Allerdings ist bei der Berücksichtigung der Richtung ein Fehler unterlaufen.

# if_answeroption_02

Sie haben sowohl die Richtung des Tests als auch das korrekte Signifikanzniveau berücksichtigt. 

# if_answeroption_03

Beachten Sie, dass es sich um eine gerichtete Hypothese handelt.

# if_answeroption_04

Beachten Sie, dass es sich um eine gerichtete Hypothese handelt. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
