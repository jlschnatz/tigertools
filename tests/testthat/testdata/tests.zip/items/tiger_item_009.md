# id_item
9

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Dreißig Studierende im Fach Statistik nahmen an einem Quiz mit insgesamt 30 Punkten teil. Die Standardabweichung der Quizergebnisse betrug 1 Punkt. Welche der folgenden Aussagen ist die geeignetste Interpretation dieser Standardabweichung?

# stimulus_image
NA

# answeroption_01
Alle Einzelwertungen liegen einen Punkt auseinander.

# answeroption_02
Die Differenz zwischen der höchsten und der niedrigsten Punktzahl beträgt 1 Punkt.

# answeroption_03
Die Differenz zwischen dem oberen und dem unteren Quartil beträgt 1 Punkt.

# answeroption_04
Ein typischer Abstand einer Punktzahl vom Mittelwert ist 1 Punkt.

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
4

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Diese Information lässt sich aus der Standardabweichung nicht direkt ablesen.

# if_answeroption_02
Dies ist der Bereich, in dem die Daten aufgetreten sind.

# if_answeroption_03
Dies wäre der Interquartilsbereich.

# if_answeroption_04


# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

