# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

56

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->

comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->

medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie interessieren sich dafür, ob Psychologiestudierende Ihrer Uni klüger sind als die allgemeine Studierendenschaft. Um ihr Ego entsprechend hochtreiben zu können, ignorieren Sie alle praktischen und theoretischen Diskussionen zum IQ und konzentrieren sich rein auf die Zahlen. Nach kurzer Internet-Recherche und dem Lesen von Forumsbeiträgen einiger Personen, welche definitiv zu 100% akkurat wissen, wovon sie schreiben, entscheiden Sie sich von einer Vielzahl genannter IQ-Durchschnittswerte von Studierenden für den Wert 106, welchen Sie als durchschnittlichen IQ eines Studierenden ansehen. Nun erheben Sie den IQ der Psychologiestudierenden an Ihrer Uni mit einer Reliabilität von 100%. 
Da sie ein social butterfly sind, können Sie alle 169 Psychologiestudierenden an Ihrer Uni zur Teilnahme bewegen. Bei diesen ergibt sich ein durchschnittlicher IQ-Wert von 108. IQ-Werte sind mit einem Mittelwert von 100 und einer Standardabweichung von σ=15 genormt. 
Sie möchten Ihre Hypothese nun überprüfen. Kreuzen Sie bitte die richtige Antwort an. 



# stimulus_image

# answeroption_01
Psychologiestudierende Ihres Studiengangs sind signifikant intelligenter als die allgemeine Studierendenschaft (z = 1.73, p =. 042).

# answeroption_02
Psychologiestudierende Ihres Studiengangs sind nicht signifikant intelligenter als die allgemeine Studierendenschaft (z = 1.73, p = .083).

# answeroption_03
Es ist keine Inferenzstatistik nötig, ein einfacher Vergleich des Mittelwertes mit dem IQ-Durchschnittswert von Studierenden genügt.

# answeroption_04
Psychologiestudierende Ihres Studiengangs sind signifikant intelligenter als die allgemeine Studierendenschaft (z = 6.93, p < .001).

# answeroption_05
# answeroption_06

<!---
String (eines von):
    - Frage überspringen
    - www/skip.png
  
Wenn type_answer: text, dann "Frage überspringen"
Wenn type_answer: image, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

text
<!---
String (eines von):
    - text
    - image
Muss text sein, wenn als Stimulus ein Textformat genutzt wurde, und image, wenn als Stimulus ein Bild verwendet wurde.
--->

# type_answer

text
<!---
String (eines von):
    - text
    - image
Muss text sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und image, wenn als Antwortoptionen Bilder verwendet wurden.
--->

# if_answeroption_01

<!---
Die if_answeroption_XX Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben allerdings den Einstichproben-z-Test korrekt durchgeführt und auch die Richtung der Testung berücksichtigt (Prüfgröße und p-Wert stimmen). Überlegen Sie jedoch noch mal, ob es sich hierbei überhaupt um eine Stichprobe handelt.

# if_answeroption_02

<!---
Die if_answeroption_XX Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben allerdings den Einstichproben-z-Test korrekt durchgeführt, jedoch die Richtung des Tests nicht berücksichtigt. Überlegen Sie zusätzlich noch mal, ob es sich hierbei überhaupt um eine Stichprobe handelt.

# if_answeroption_03

<!---
Die if_answeroption_XX Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Da schon die gesamte Zielpopulation (die Studierenden Ihres Studiengangs) erhoben wurde, müssen Sie keine Inferenzstatistik mehr durchführen. Sie haben keine Stichprobe erhoben, sondern eine Vollerhebung durchgeführt, und müssen folglich nicht mehr von der Stichprobe auf die Population schließen, da Sie den Populationsmittelwert schon kennen.

# if_answeroption_04

<!---
Die if_answeroption_XX Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben für den Einstichproben-z-Test fälschlicherweise nicht den Mittelwert der allgemeinen Studierendenschaft (106) verwendet, sondern den des IQ-Testes insgesamt (100). Folglich sind die Prüfgröße und der p-Wert inkorrekt. Überlegen Sie jedoch zusätzlich, ob es sich hierbei überhaupt um eine Stichprobe handelt.

# if_answeroption_05
# if_answeroption_06

Alles klar! Du hast die Aufgabe übersprungen.