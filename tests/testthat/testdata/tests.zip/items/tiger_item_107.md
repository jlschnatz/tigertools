# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

107

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind Bildungsforscher\*in und wollen den Zusammenhang zwischen schulischen Leistungen und dem IQ untersuchen. Dazu erheben Sie von 100 Schüler\*innen die Daten, die einen allgemeinen Intelligenztest, einen Lesetest und einen Mathematiktest umfassen. In einer standardisierten Regression ermitteln Sie, wie gut die Vorhersage des IQs anhand der Leistungen im Lese- und Mathematiktest gelingt. Für die Leistung im Lesetest (Lesekompetenz) erhalten Sie ein Regressionsgewicht von 0.36. Was bedeutet dieses inhaltlich?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Wenn sich zwei Personen in der Lesekompetenz um eine Einheit unterscheiden und im Mathematiktest die gleiche Leistung erbringen, unterscheiden sie sich laut Vorhersage um 0.36 Einheiten im Intelligenztest.

# answeroption_02
Wenn die Lesekompetenz um eine Einheit erhöht wird, während die Mathematikfähigkeit gleich bleibt, steigt die Leistung im Intelligenztest um 0.36 Einheiten.

# answeroption_03
Zwei Personen, die sich um eine Standardabweichung in der Lesekompetenz unterscheiden und sich gleichzeitig nicht in der Leistung im Mathetest unterscheiden, unterscheiden sich voraussichtlich um 0.36 Standardabweichungen im Intelligenztest.

# answeroption_04
Zwei Personen, die sich um eine Standardabweichung im Intelligenztest unterscheiden und im Mathetest gleiche Leistungen erbringen, unterscheiden sich durchschnittlich um 0.36 Standardabweichungen in der Lesekompetenz.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Ihre Interpretation wäre richtig, wenn es sich um ein unstandardisiertes Regressionsgewicht handeln würde. Achten Sie noch mal genau auf den Aufgabentext. 

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie zum einen darauf, ob hier die Interpretation eines unstandardisierten oder standardisierten Regressionsgewichts gefragt ist. Zum anderen sollten Regressionsgewichte nicht dahingehend interpretiert werden, dass sich der Wert **erhöht**, weil in einer Regression die Daten von verschiedenen Personen zu einem bestimmten Zeitpunkt analysiert werden. Es werden also keine Aussagen über die **Veränderung** von Werten getroffen, sondern über die **Unterschiede** zwischen Personen auf verschiedenen Variablen und wie man mit diesen Unterschiede auf dem Kriterium vorhersagen kann.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben das Regressionsgewicht richtig interpretiert und auch erkannt, dass das Regressionsgewicht in Standardeinheiten interpretiert werden muss, da hier eine standardisierte Regression berechnet wurde. Achten Sie in Zukunft auch darauf, dass es hier immer um Unterschiede zwischen Personen geht und nicht um Veränderungen. Die Formulierung "erhöht sich um 0.36 Standardabweichungen" wäre also nicht ganz korrekt.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
In der Regression geht es immer darum, Werte auf einer abhängigen Variable vorherzusagen und mit dieser in Zusammenhang stehende Variablen zu identifizieren. Demnach stimmt hier die Richtung der Interpretation nicht. Das Regressionsgewicht der Lesekompetenz dient nicht dem Zweck, die Lesekompetenz selbst vorherzusagen, sondern soll die AV, also die Leistung im Intelligenztest vorhersagen.


# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
