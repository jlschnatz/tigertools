# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

118

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
hard

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind Gesundheitspsycholog\*in und untersuchen den Alkoholkonsum von Jugendlichen. Aus diesem Grund haben Sie über drei Jahre hinweg eine längsschnittliche Untersuchung durchgeführt und dieselben Jugendlichen im Alter von 14, 15 und 16 Jahren zu ihrem Alkoholkonsum befragt. Laden Sie mit folgendem Befehl den Datensatz in R herunter: `load(url("https://pandar.netlify.app/daten/alc.rda"))`
Vor allem interessiert Sie, inwiefern es den Alkoholkonsum beeinflusst, wenn ein Elternteil Alkoholiker\*in ist. Sie denken, dass entweder die Kinder von Alkoholiker\*innen mehr Alkohol konsumieren, weil sie dieses Verhalten von den Eltern lernen (oder genetisch dafür prädestiniert sind) oder weniger, weil sie der krankhafte Konsum der Eltern abschreckt. Um dieser Frage auf den Grund zu gehen, wollen Sie als ersten Schritt den Standardfehler berechnen, um abzuschätzen, mit wie viel Unsicherheit Ihre Testung behaftet ist. Dazu wollen Sie zunächst eine zusätzliche Variable erstellen, die abbildet, wie häufig die Jugendlichen durchschnittlich im Alter von 14 (alcuse.14), 15 (alcuse.15) und 16 Jahren (alcuse.16) Alkohol konsumiert haben. Anschließend berechnen Sie mit der gepoolten Varianz den Standardfehler für den Zweistichproben-t-Test, ob Kinder von Alkoholiker\*innen sich signifikant in der Häufigkeit des Konsums von Alkohol unterscheiden im Vergleich zu Jugendlichen ohne ein alkoholkrankes Elternteil. 


# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Der Standardfehler beträgt 0.18.

# answeroption_02
Der Standardfehler beträgt 0.65.

# answeroption_03
Der Standardfehler beträgt 0.10.

# answeroption_04
Der Standarfehler beträgt 0.54.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtig den Mittelwert der drei Variablen für jede Person bestimmt und anschließend mit der gepoolten Varianz den Standardfehler korrekt berechnet.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie sind schon weit gekommen! Hierbei handelt es sich um die gepoolte Varianz, das ist allerdings noch nicht ganz der Standardfehler.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Leider ist es nicht ganz so einfach. Sie haben wahrscheinlich einfach die Standardabweichung der Variable für den mittleren Alkoholkonsum berechnet und dann durch die Wurzel von n geteilt, wie bei einem Einstichprobentest. Sie müssen hierbei allerdings zunächst die gepoolte Varianz berechnen und die verschiedenen Gruppengrößen müssen ebenfalls berücksichtigt werden. Vielleicht finden Sie die Formel dafür in den Vorlesungsfolien.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben wahrscheinlich, statt eine weitere Variable mit den Mittelwerten der drei Variablen zu erstellen, die Summe für jede Person gebildet. Dieses Vorgehen wird auch häufig praktiziert, jedoch sollten Sie hier mit dem Mittelwert rechnen. Wenn Sie auf dieses Ergebnis gekommen sind, war Ihre Berechnung ansonsten allerdings richtig.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
