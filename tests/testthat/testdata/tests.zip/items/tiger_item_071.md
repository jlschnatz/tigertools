# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

71

# learning_area

Regression

# type_item

content

# bloom_taxonomy

application

# theo_diff

medium

# stimulus_text

In einer Studie untersuchen Sie, ob Spaß am Studium mit der selbsteingeschätzten Lehrqualität zusammenhängt. Dabei haben Sie an einer Stichprobe mit 2000 Teilnehmenden zuerst das $R^2$ mit selbsteingeschätzter Lehrqualität und generellem Spaß an Aktivitäten als Prädiktoren ermittelt und als Ergebnis 0.1 erhalten. Nun nehmen Sie zusätzlich noch Teilnehmervariablen in das Modell auf, nämlich Geschlecht, Alter, Wissen über Katzen und Liebe zur Statistik. Das $R^2$ verändert sich daraufhin um 0.0069. 
Sie möchten nun wissen, ob dieser Varianzzuwachs bedeutsam ist. 

Berechnen Sie bitte den entsprechenden Test und interpretieren Sie das Varianzinkrement inhaltlich. 


# stimulus_image

# answeroption_01

Das Varianzinkrement ist statistisch bedeutsam. Demnach ist die Erhöhung des $R^2$ auch für die Praxis relevant. 

# answeroption_02

Das Varianzinkrement ist nicht statistisch bedeutsam. Trotzdem ist die Erhöhung des $R^2$ für die Praxis relevant. 

# answeroption_03

Das Varianzinkrement ist nicht statistisch bedeutsam. Demnach ist die Erhöhung des $R^2$ auch für die Praxis nicht relevant. 

# answeroption_04

Das Varianzinkrement ist statistisch bedeutsam. Trotzdem ist die Erhöhung des $R^2$ für die Praxis nicht relevant. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

4


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Das Varianzinkrement ist durchaus statistisch bedeutsam, aber bedeutet das unbedingt, dass das Inkrement für die Praxis auch relevant ist? Sie sollten sich klarmachen, dass Signifikanz nicht gleichzusetzen ist mit praktischer Relevanz. Mit unendlich großen Stichproben kann man noch so kleine Effekte sichtbar machen, die aber praktisch gar keine ersichtliche Auswirkung haben. Betrachten Sie dazu auch die Interpretation von $R^2$ nach Cohen.

# if_answeroption_02

Überprüfen Sie Ihre Rechnung bezüglich der statistischen Bedeutsamkeit. Welchen Test müssen Sie anwenden und wie wird dieser berechnet? Haben Sie vielleicht die falsche Seite der Verteilung betrachtet? Überlegen Sie zusätzlich, inwiefern die Höhe des Varianzinkrements die Interpretation als praktisch relevant oder irrelevant beeinflusst. Machen Sie sich klar, dass Signifikanz nicht gleichzusetzen ist mit praktischer Relevanz und orientieren Sie sich an den Konventionen von Cohen.  

# if_answeroption_03

Überprüfen Sie Ihre Rechnung bezüglich der statistischen Bedeutsamkeit. Welchen Test müssen Sie anwenden und wie wird dieser berechnet? Haben Sie vielleicht die falsche Seite der Verteilung betrachtet?

# if_answeroption_04

Sie haben korrekt den F-Test für ein Varianzinkrement erkannt und durchgeführt. Auch die Interpretation des p-Wertes als signifikant ist geglückt. Zusätzlich haben Sie richtigerweise die sehr kleine Erhöhung der Varianzaufklärung als praktisch vernachlässigbar interpretiert. In großen Stichproben können selbst kleine Effekte signifikant werden, was aber nicht bedeutet, dass dieser Effekt auch für die Praxis relevant ist. Für eine grobe Einordnung können Sie dabei die Konventionen nach Cohen betrachten. Dabei gilt ein $R^2$ von .02 als Richtwert für eine schwache Varianzaufklärung. Da das Varianzinkrement aber noch deutlich darunter liegt, kann man dieses als vernachlässigbar einschätzen.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
