# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

111

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie rechnen zunächst eine einfache Regression mit einem Prädiktor ($x_{1}$). Anschließend nehmen Sie in einer multiplen Regression noch eine weitere Variable ($x_{2}$) als zusätzlichen Prädiktor auf. Was bedeutet es inhaltlich, wenn das Regressionsgewicht von $x_{1}$ in der einfachen Regression genauso groß ist wie in der multiplen Regression?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Die beiden Prädiktorvariablen sind unkorreliert. 

# answeroption_02
Der zweite Prädiktor ($x_{2}$) leistet keinen zusätzlichen Beitrag zur Varianzaufklärung.

# answeroption_03
Die beiden Prädiktorvariablen korrelieren perfekt.

# answeroption_04
Das gleichbleibende Regressionsgewicht ist der Beweis dafür, dass es sich um eine echte Korrelation und nicht um eine Scheinkorrelation handelt. Demnach würde das Regressionsgewicht auch gleich bleiben, wenn man beliebige weitere Prädiktoren hinzufügt.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Die Regressionsgewichte von $x_{1}$ sind gleichbleibend, weil der Anteil der Varianz von y, der von $x_{1}$ aufgeklärt wird unabhängig von $x_{2}$ aufgeklärt wird und die Varianzen der beiden Prädiktoren demnach nicht überlappen. Somit sind die Prädiktorvariablen unkorreliert.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Das lässt sich nicht eindeutig so sagen. Das gleichbleibende Regressionsgewicht zeigt nur, dass $x_{2}$ keine Varianz aufklärt, die bereits von $x_{1}$ aufgeklärt wird.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Eine perfekte Korrelation würde bedeuten, dass $r_{x_{1}x_{2}} = 1$. Überlegen Sie noch mal, was das für die Varianzaufklärung bedeuten würde, wenn man einen zweiten Prädiktor hinzunimmt, der perfekt mit dem ersten korreliert und was dann mit dem Regressionsgewicht passiert, da man in der multiplen Regression die gemeinsam aufgeklärte Varianz auf die Prädiktoren aufteilt, um diese nicht doppelt einzuberechnen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Durch das gleichbleibende Regressionsgewicht ergibt sich eine Implikation, aus der man schließen kann, dass es sich **nicht** um eine Scheinkorrelation zwischen $x_{1}$ und y handelt. Allerdings ist das Regressionsgewicht dadurch nicht "immun" gegen Veränderungen, wenn man noch andere Prädiktoren hinzufügt, sondern man kann lediglich eine Aussage über die Beziehung dieser beiden spezifischen Prädiktoren treffen.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06
<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
