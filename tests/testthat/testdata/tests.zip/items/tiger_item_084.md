
# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

84

# learning_area

Zusammenhangsmaße

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

In einer Studie untersuchen Sie, ob Menschen, welche an Verschwörungsmythen glauben, auch eher einer gewaltbereiten Gruppe angehören. Dabei erheben Sie folgende Daten:


|            |In Gruppe|Nicht in Gruppe|
| ---        |  :---:    |:---:            |
|Verschw.Ja  |69       |42             |
|Verschw.nein|187      |420            |

Berechnen Sie den Odds-Ratio, um Ihre Hypothese zu bestätigen. 

# stimulus_image

# answeroption_01

Der Odds-Ratio beträgt 3.69. 

# answeroption_02

Der Odds-Ratio beträgt 0.27. 

# answeroption_03

Der Odds-Ratio beträgt 27.10. 

# answeroption_04

Der Odds-Ratio beträgt 0.04. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Sie haben die Zahlen in der korrekten Reihenfolge berücksichtigt und auch die Richtung der Aussage einbezogen.

# if_answeroption_02

Schauen Sie nochmal auf die Richtung der Aussage. 

# if_answeroption_03

Schauen Sie nochmal genau auf die Formel für den Odds-Ratio sowie auf die Richtung der Hypothese.

# if_answeroption_04

Schauen Sie nochmal genau auf die Formel für den Odds-Ratio sowie auf die Richtung der Hypothese. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
