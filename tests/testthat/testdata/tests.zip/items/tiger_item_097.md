# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

97

# learning_area

Gruppenvergleiche

# type_item

coding

# bloom_taxonomy

knowledge

# theo_diff

medium

# stimulus_text

In einer Studie möchten Sie untersuchen, ob augenscheinliche Geschlechterunterschiede in der Bezahlung eventuell durch andere Faktoren erklärbar sind. Dazu erheben Sie Daten, die sie durch folgenden Code einlesen können: 
```
income<- carData::Salaries
``` 
Als erste Grundlage möchten Sie nun erstmal einen einfachen t-Test rechnen, wo Sie noch nicht auf die anderen Variablen im Datensatz kontrollieren. Nach dem Durchführen der Vorraussetzungstests von Varianzgleichheit und Normalverteilung, welche beide nicht signifikant ausfielen und deshalb angenommen wurden, machen Sie sich nun an die Berechnung des t-Tests. Dazu schreiben Sie folgenden Code: 
```
t.test(income$salary,income$sex,var.equal=TRUE)
```
Doch oh Schreck, eine wilde Fehlermeldung erscheint. 
```
> t.test(income$salary,income$sex,var.equal=TRUE)
Fehler in var(y) : Calling var(x) on a factor x is defunct.
  Use something like 'all(duplicated(x)[-1L])' to test for a constant vector.
Zusätzlich: Warnmeldung:
In mean.default(y) :
  Argument ist weder numerisch noch boolesch: gebe NA zurück
```
Nachdem sich Ihre anfängliche, sehr verständliche Panik gelegt hat, wollen Sie nun schauen, was schiefgelaufen ist. 

Woran hat es gelegen? 


# stimulus_image

# answeroption_01

Man hätte nicht mit $ arbeiten dürfen, sondern stattdessen am Ende des Befehls `data = income` einfügen müssen. 

# answeroption_02

Das `var.equal = TRUE` ergibt bei einem Faktor als zweites Argument keinen Sinn und erzeugt demnach diesen Fehler. 

# answeroption_03

Die Argumente `income$salary` und `income$sex` hätten mit einer Tilde statt mit einem Komma getrennt werden müssen.

# answeroption_04

Die Variablen `income$salary` und `income$sex` sind in der falschen Reihenfolge eingegeben worden. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

3


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Der Fehler ändert sich nun allerdings. 
```
t.test(salary,sex,var.equal=TRUE,data=income)
```
Nun findet er nicht das Objekt salary, was dafür spricht, dass er die Werte nicht korrekt in die Funktion einlesen kann.
Schauen Sie nochmal, ob sich die beiden Variablen in ihrer Funktion unterscheiden und wie der Code für den t-Test in einem solchen Fall aussehen muss. 


# if_answeroption_02

Es kommt schon vorher im Code zu Problemen bei der Berechnung des Tests. Wegen der Annahme der Varianzgleichheit ist es zudem korrekt, `var.equal=TRUE` zu setzen, das heißt eine Korrektur der Freiheitsgrade findet gar nicht statt.

Schauen Sie nochmal, ob sich die beiden Variablen in ihrer Funktion unterscheiden und wie der Code für den t-Test in einem solchen Fall aussehen muss.  

# if_answeroption_03

Da es sich bei der Variable "salary" um die abhängige Variable handelt, die von der unabhängigen Variable "sex" gruppiert werden soll, muss mit der Tilde statt mit dem Komma gearbeitet werden. Das Komma würde man benutzen, wenn man zwei bereits gruppierte Vektoren mit den Werten der **einzelnen** Gruppen hat und nicht einen Vektor mit den Werten **beider** Gruppen. 

# if_answeroption_04

Die Reihenfolge der Argumente stimmt. Jedoch kommt den beiden Variablen eine unterschiedliche Funktion zu. Überlegen Sie, durch welche Formulierung Sie dies in Ihrem Code wiedergeben können.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
