# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

116

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Grundlagen der Inferenzstatistik

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Nehmen wir an, Sie wollten prüfen, ob die Berufsgruppe der Pflegekräfte, bedingt durch den Schichtdienst sowie die psychische Belastung, zu wenig schläft. Dazu haben Sie eine Stichprobe aus der Population der Pflegekräfte gezogen und über 7 Tage am Stück die Schlafdauer der Proband\*innen registriert. Für jede\*n Proband\*in haben Sie daraus einen Durchschnittswert pro Nacht ermittelt. Um eine ausreichende Repräsentativität zu gewährleisten, haben Sie Daten von Pflegepersonal verschiedener Einrichtungen erhoben. Deswegen haben Sie als Einzelperson letztendlich nur 15 Pflegekräfte rekrutiert, da sonst der Aufwand zu groß gewesen wäre. Folgende Daten haben sich aus Ihrer Untersuchung ergeben (durchschnittliche Schlafdauer in Minuten pro Nacht):
`schlafdauer <- c(354, 398, 423, 320, 403, 405, 373, 374, 373, 363, 376, 360, 367, 392, 419)`
Zusätzlich ist noch die Populationsstandardabweichung von $\sigma$ = 30 bekannt. Bitte berechnen Sie das 95%-Konfidenzintervall um den Mittelwert.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das Konfidenzintervall für den Mittelwert liegt zwischen 6 Std. 7 Min. und 6 Std. 33 Min..

# answeroption_02
Das Konfidenzintervall für den Mittelwert liegt zwischen 6 Std. 6 Min. und 6 Std. 34 Min..

# answeroption_03
Das Konfidenzintervall für den Mittelwert liegt zwischen 6 Std. 5 Min. und 6 Std. 35 Min..

# answeroption_04
Das Konfidenzintervall für den Mittelwert liegt zwischen 6 Std. 3 Min. und 6 Std. 37 Min..

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Bitte beachten Sie, dass standardmäßig, wenn nicht anders angegeben, ein **zweiseitiges** Konfidenzintervall um den Mittelwert berechnet wird. Das bedeutet, dass Sie die 5%-Irrtumswahrscheinlicheit auf beide Seiten des Intervalls verteilen müssen.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Da hier die Populationsstandardabweichung bereits gegeben ist, müssen Sie diese nicht mehr aus den Daten schätzen und können zur Berechnung des Konfidenzintervalls den entsprechenden Wert der Standardnormalverteilung verwenden.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben richtig beachtet, dass zur Berechnung der z-Wert verwendet wird, da die Populationsstandardabweichung bereits gegeben ist. Außerdem haben Sie bedacht, dass Sie die Irrtumswahrscheinlichkeit auf beide Seiten des Intervalls aufteilen müssen.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Beachten Sie, dass die Populationsstandardabweichung bereits gegeben ist. Aus welcher Verteilung nehmen Sie dann den Quantilwert?

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
