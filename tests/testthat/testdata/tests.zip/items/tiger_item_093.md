# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

93

# learning_area

Zusammenhangsmaße

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Sie und ein Kommilitone lesen sich zusammen zum Zeitvertreib Studienergebnisse durch. In einem Artikel lesen Sie den Satz: ,,Aus der Kovarianz von 0.9 lässt sich ein positiver Zusammenhang zwischen Hyperaktivität und Kaffeekonsum ableiten.“ Ihr Kommilitone sagt überrascht: So hoch hätte ich den Zusammenhang zwischen Kaffeekonsum und Hyperaktivität nicht eingeschätzt. Verwundert ziehen Sie die Augenbrauen hoch. Was fällt Ihnen bei der Interpretation Ihres Kommilitonen auf?

# stimulus_image


# answeroption_01

Sie sind überrascht über den hohen Zusammenhang, den Ihr Kommilitone richtigerweise als hoch interpretiert hat, da er über 0.5 liegt.

# answeroption_02

Ihr Kommilitone kann gar nicht wissen wie hoch der Zusammenhang ist, da man anhand der Kovarianz das Ausmaß des Zusammenhangs gar nicht einschätzen kann.

# answeroption_03

Sie können gar nicht wissen, ob es sich wirklich um einen positiven Zusammenhang handelt, da Kovarianzen (wie Varianzen auch) keinen negativen Wert annehmen können und somit genauso gut ein negativer Zusammenhang vorliegen könnte.

# answeroption_04

In dem Artikel war die Rede vom Zusammenhang zwischen Hyperaktivität und Kaffeekonsum, während Ihr Kommilitone dazu entgegengesetzt vom Zusammenhang zwischen Kaffeekonsum und Hyperaktivität sprach. Sie bedenken, dass es sich bei der Kovarianz um ein gerichtetes Zusammenhangsmaß handelt, sodass der Zusammenhang zwischen Kaffeekonsum und Hyperaktivität genau im Gegenteil negativ ausfallen sollte.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2

# type_stimulus

text

# type_answer

text

# if_answeroption_01

Denken Sie noch einmal über den Unterschied zwischen Kovarianz und Korrelation nach. Welche Aussagekraft besitzt die Kovarianz als unstandardisiertes Maß?

# if_answeroption_02

Ihr Kommilitone scheint die Kovarianz mit der Korrelation verwechselt zu haben. Die Kovarianz selbst ist ein unstandardisiertes Maß, weswegen die Einschätzung der Größe des Zusammenhangs rein über die Kovarianz nicht möglich ist. Lediglich die Richtung des Zusammenhangs (ob positiv oder negativ) lässt sich daraus ableiten. Durch Standardisierung der Kovarianz mithilfe der Standardabweichungen ergibt sich die Korrelation, welche das Ausmaß des Zusammenhangs darstellt.

# if_answeroption_03

Betrachten Sie noch einmal die Formeln von Varianz und Kovarianz. Die Varianz kann tatsächlich keinen negativen Wert annehmen, da der Term quadriert wird. Die Kovarianz hingegen kann durchaus negativ sein, da auch Terme mit gegensätzlichem Vorzeichen multipliziert werden können. Bei einem negativen Zusammenhang würde die Kovarianz also durchaus negativ sein.

# if_answeroption_04

Betrachten Sie die Formel der Kovarianz. Dabei sollte Ihnen auffallen, dass die Produktsumme unabhängig von der Reihenfolge der beiden Variablen gleich ausfällt (Kommutativgesetz). Demzufolge ist die Kovarianz gleich groß, egal in welcher Reihenfolge man die beiden Variablen betrachtet.


# if_answeroption_05



# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
