# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

128

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
hard

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Stellen Sie sich vor, Sie wollten, ganz banal, in einer Stichprobe aus Ihrem Studiengang untersuchen, ob Männer größer sind als Frauen. Ihre vorbereitende Recherche ergab zunächst, dass Frauen im Durchschnitt 165 cm groß sind und Männer 178 cm. Zu der Standardabweichung haben Sie allerdings keine verlässlichen Populationsdaten gefunden, deswegen haben Sie diese aus den Daten einer Studie geschätzt. Für Frauen beträgt die geschätzte Standardabweichung 6 cm und für Männer 7 cm. Gehen Sie deswegen von Heteroskedastizität aus. Die Normalverteilung ist bei Körpergrößen in der Population gegeben.
Natürlich geht es Ihnen hierbei nicht darum, ernsthaft die Hypothese zu testen, da diese allgemein als bewiesen gilt. Sie interessiert stattdessen, wie viele Proband\*innen (pro Gruppe) Sie denn bräuchten, damit der Unterschied mit einer Wahrscheinlichkeit von 95 Prozent signifikant ausfällt. Sie testen auf einem $\alpha$-Fehler-Niveau von 1%. Da Sie die Studie hypothetisch an Ihren Kommiliton\*innen durchführen wollen und viel mehr Frauen als Männer Psychologie studieren, erheben Sie, um es möglichst praktikabel zu halten, drei Mal so viele Frauen wie Männer. Mit diesen Informationen wagen Sie sich an eine simulationsbasierte Poweranalyse. Arbeiten Sie mit einer angemessenen Wiederholungszahl und berechnen Sie das benötige n pro Gruppe.
Hinweis: Für einheitliche Ergebnisse setzen Sie `set.seed(1234)`.


# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie benötigen 10 Frauen und 10 Männer.

# answeroption_02
Sie benötigen 18 Frauen und 6 Männer.

# answeroption_03
Sie benötigen 27 Frauen und 9 Männer.

# answeroption_04
Sie benötigen 24 Frauen und 8 Männer.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal genau auf den Aufgabentext. Sollen wirklich beide Gruppen gleich groß sein?

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie sind wahrscheinlich von der Homoskedastizität ausgegangen und haben einen t-Test mit Welch-Korrektur durchgeführt. Achten Sie dahingehend noch mal auf den Aufgabentext.
Alternativ könnte es auch sein, dass Sie das falsche $\alpha$-Niveau gewählt haben.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal darauf, ob die Hypothese gerichtet oder ungerichtet ist.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut! Die Aufgabe war wirklich nicht leicht, weil Sie sehr viele Aspekte beachten mussten, deswegen hier noch mal zum Abgleich der Code:
```
set.seed(1234)

pt_H1 <- replicate(n = 10000, expr = {X_Frauen <- rnorm(n = 24, mean = 165, sd = 6)
X_Männer <- rnorm(n = 8, mean = 178, sd = 7) 
ttestH1 <- t.test(X_Frauen, X_Männer, alternative = 'less', var.equal = FALSE)
ttestH1$p.value})

mean(pt_H1 < 0.01)   # Ergebnis: 0.9541
```
Durch Ausprobieren mit unterschiedlichen n konnten Sie so die kleinstmögliche Stichprobengröße ermitteln, für die die Power mindestens 0.95 beträgt.


# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
