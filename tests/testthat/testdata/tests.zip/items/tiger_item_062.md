# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

62

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Zusammenhangsmaße

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

Eine Studentin kommt ganz aufgeregt zu Ihnen. Sie hat in Ihrer Studie rausgefunden, dass ihr Regressionsgewicht $\beta_1$ eine Signifikanz aufweist. Ihnen ist die Studentin schon vorher unangenehm aufgefallen, weswegen Sie ihr doch so schönes Erfolgserlebnis zunichtemachen wollen. Also fragen Sie nach den Parametern sowie der Signifikanzberechnung, welche Ihre Kommilitonin erfasst und durchgeführt hat. Stolz berichtet diese, dass bei einer Stichprobengröße von 44 Leuten ein unstandardisiertes $\beta_1$ von 0.69 vorlag, wobei $s_x=0.3$ und $s_y=0.7$ waren. Für die Berechnung der Signifikanz habe Sie einfach $\beta_1$ genommen und in diese Formel für r eingesetzt. 

$t=\frac{r*\sqrt{n-2}}{\sqrt{1-r^2}}$
 
Als Ergebnis bekam Sie einen p-Wert von 2.202001e-07 (sie testet ungerichtet), was deutlich unter Ihrem 5% Signifikanzniveau lag. Sie fangen an zu grinsen, da Sie schon einen Fehler bei Ihrer Kommilitonin entdeckt haben. Was hat Sie falsch gemacht?


# stimulus_image



# answeroption_01
Sie hätte das standardisierte Regressionsgewicht benutzen müssen.

# answeroption_02
Man kann anhand dieser Formel nur das Regressionsgewicht einer multiplen Regression testen und nicht das einer einfachen.

# answeroption_03
Mit dieser Formel kann man die Regression gar nicht testen, da es die Prüfgröße der Korrelation ist.

# answeroption_04
Ihr Verfahren war richtig, jedoch ist ihr ein Berechnungsfehler unterlaufen. 

# answeroption_05

# answeroption_06

Frage überspringen.
<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->

# answer_correct

<!-- Numerisch (Integer) -->
1

# type_stimulus

text
<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

Die Formel ist für die Signifikanztestung einer Korrelation gegen 0 vorgesehen. Im Falle einer einfachen Regression (eine Regression mit nur einem Prädiktor) allerdings, könnten wir das Vorgehen der Kommilitonin anwenden, wenn sie das standardisierte Regressionsgewicht berechnet hätte. Dies funktioniert **bei der einfachen Regression** aber auch **nur**, weil bei dieser das **standardisierte Regressionsgewicht identisch mit der Korrelation der beiden Variablen ist**. Da Ihre Kommilitonin aber das **unstandardisierte** Regressionsgewicht genommen hat, kommt sie zum falschen Ergebnis.

# if_answeroption_02

Das Gegenteil ist der Fall. Diese Formel ist für die Signifikanztestung einer Korrelation gegen 0 vorgesehen, kann aber auch bei einer einfachen Regression mit nur einem Prädiktor angewendet werden, weil in diesem Fall das **standardisierte** Regressionsgewicht identisch mit der Korrelation der beiden Variablen ist. Überlegen Sie jetzt noch einmal, was Ihre Kommilitonin falsch gemacht hat. 

# if_answeroption_03

Es handelt sich zwar um die Formel für die Signifikanztestung der Korrelation gegen 0, jedoch kann man bei der einfachen Regression mit nur einem Prädiktor mit dieser Formel auch das Regressionsgewicht auf Signifikanz testen. Das funktioniert jedoch nur mit dem standardisierten Regressionsgewicht, weil dieses bei der einfachen Regression identisch mit der Korrelation der beiden Variablen ist. Anhand dieser Erklärung müssten Sie nun ableiten können, was Ihre Kommilitonin falsch gemacht hat. 

# if_answeroption_04

Wenn man das angegebene unstandardisierte Regressionsgewicht in die Formel einsetzt und aus dem t-Wert den dazugehörigen zweiseitigen p-Wert ermittelt, kommt man auf genau dieses Ergebnis. Prüfen Sie dies gerne nach. Obwohl es sich um die Formel für die Signifikanztestung der Korrelation gegen 0 handelt, kann man dieses bei der **einfachen** Regression ebenso verwenden. Überlegen Sie, in welchem Fall die Korrelation gleich dem Regressionsgewicht ist und bedenken Sie zusätzlich, dass in der Aufgabe auch die Standardabweichungen angegeben wurden. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
