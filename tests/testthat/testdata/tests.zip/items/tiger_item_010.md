# id_item
10

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Ein Dozent stellt einen Test mit 15 Fragen. Für jede Frage erhalten die Studierenden einen Punkt für eine richtige Antwort; 0 Punkte für keine Antwort; und verlieren einen Punkt für eine falsche Antwort. Die Gesamtpunktzahl des Tests kann zwischen -15 Punkten und +15 Punkten liegen. Der Dozent berechnet die Standardabweichung der Testergebnisse auf -2,30. Was können man daraus schließen?

# stimulus_image
NA

# answeroption_01
Die Standardabweichung wurde falsch berechnet.

# answeroption_02
Die meisten Schüler:innen haben negative Werte erhalten.

# answeroption_03
Die meisten Schüler:innen haben weniger als den Mittelwert erreicht.

# answeroption_04
Keine der oben genannten Möglichkeiten.

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Eine Standardabweichung kann nicht negativ sein.

# if_answeroption_02
Selbst wenn, eine Standardabweichung kann nicht negativ sein.

# if_answeroption_03
Selbst wenn, eine Standardabweichung kann nicht negativ sein.

# if_answeroption_04
Eine Standardabweichung kann nicht negativ sein.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

