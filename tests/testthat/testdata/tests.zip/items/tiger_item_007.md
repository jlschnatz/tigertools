# id_item
7

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
comprehension

# theo_diff
medium

# stimulus_text
Im Jahr 2011 wurde berichtet, dass der Mittelwert des Immobilienpreises in den Hamptons (New York) innerhalb eines Jahres um 20% gestiegen ist, während der Median des Immobilienpreises im selben Jahr um 2% gesunken ist. Welche der folgenden Erklärungen ist die beste für dieses Phänomen?

# stimulus_image
NA

# answeroption_01
Der Preis der meisten Häuser in den Hamptons sank, und in diesem Jahr wurden mehr Häuser in den Hamptons verkauft.

# answeroption_02
Den Berichterstattern ist bei der Darstellung der Ergebnisse ein Fehler unterlaufen; wenn der Mittelwert der Hauspreise steigt, muss auch der Median der Hauspreise steigen.

# answeroption_03
Die meisten Häuser in den Hamptons sind im Preis gesunken, und bei einer kleinen Anzahl von Häusern ist der Preis stark gestiegen.

# answeroption_04
NA

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
3

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Nach dieser Erklärung hätte auch der Mittelwert sinken müssen. Der Mittelwert stieg aber und somit muss es auch Hauspreise gegeben haben, die gestiegen sind. Darauf wird in dieser Erklärung nicht eingegangen.

# if_answeroption_02
Auch wenn Mittelwert und Median artverwandt sind, so gibt es keine absoluten Abhängigkeiten zwischen ihnen, wie in dieser Erklärung formuliert. Diese Erklärung beinhaltet somit *Fake News*.

# if_answeroption_03
Dieses Beispiel verdeutlicht, wie anfällig der Mittelwert für Ausreißer ist.

# if_answeroption_04
NA

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

