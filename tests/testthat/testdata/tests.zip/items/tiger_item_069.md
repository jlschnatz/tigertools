# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

69

# learning_area

Gruppenvergleiche

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Ein Freund von Ihnen gibt damit an, dass er egal zu welcher Uhrzeit und an welchem Ort intuitiv immer wüsste, wo Norden ist. Sie finden diese Aussage sehr gewagt und möchten diese empirisch prüfen. Sie sagen, dass sie das viel besser hinbekommen würden und wagen die gleiche Herausforderung, wobei eine Freundin Sie beide nun zufällig und unabhängig voneinander nach der Richtung von Norden fragt. Die vom Freund und von Ihnen jeweils angezeigte Richtung rechnen Sie dann in ein Gradmaß um, wobei 0 Norden darstellt. Dann wird die absolute Abweichung in Grad berechnet (siehe Grafik).

Beim Anschauen Ihrer Antworten fällt Ihnen auf, dass Sie beide bei einigen wenigen Messungen sehr weit von Ihren restlichen Antworten und der korrekten Himmelsrichtung abgewichen sind. Diese Messungen erscheinen als einige wenige Punkte mit vergleichsweise extrem hohen Werten. Welchen Test ziehen Sie für die Testung Ihrer Hypothese heran?

# stimulus_image

www/tiger_item069_stimulus.png

# answeroption_01

Wilcoxon-Rangsummen-Test für unabhängige Stichproben

# answeroption_02

t-Test für unabhängige Stichproben

# answeroption_03

t-Test für abhängige Stichproben

# answeroption_04

Wilcoxon-Vorzeichen-Rangtest für abhängige Stichproben

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Da Sie Ausreißer vermuten und dadurch wahrscheinlich auch die Normalverteilung verletzt ist, rechnen Sie lieber mit Rangsummen, da diese robuster sind gegenüber Ausreißern.

# if_answeroption_02

Schauen Sie vielleicht nochmal auf die Voraussetzungen des Tests und ob es mögliche Probleme mit dem Mittelwert und der Standardabweichung geben könnte in diesem Kontext. 

# if_answeroption_03

Schauen Sie vielleicht nochmal auf die Voraussetzungen des Tests und ob es mögliche Probleme mit dem Mittelwert und der Standardabweichung geben könnte in diesem Kontext. Außerdem sollte man auch überprüfen, ob die Stichprobe die Charakteristika für den Test erfüllt.

# if_answeroption_04

Schauen Sie vielleicht nochmal auf die Voraussetzungen des Tests und ob die Stichprobe die Charakteristika für den Test erfüllt.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
