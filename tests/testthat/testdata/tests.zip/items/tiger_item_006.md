# id_item
6

# learning_area
Deskriptivstatistik

# type_item
content

# bloom_taxonomy
comprehension

# theo_diff
medium

# stimulus_text
Laut einer bundesweiten Umfrage unter Hundehalter:innen belaufen sich die durchschnittlichen Kosten für die Anschaffung eines großen Hundes im ersten Jahr auf 1.700 €. Welche der folgenden Aussagen ist die beste Interpretation des Mittelwerts?

# stimulus_image
NA

# answeroption_01
Für alle Hundehalter:innen in dieser Stichprobe liegen die durchschnittlichen Kosten für den Besitz eines großen Hundes im ersten Jahr bei 1.700 €.

# answeroption_02
Für alle Hundehalter:innen in der Grundgesamtheit liegen die durchschnittlichen Kosten für einen großen Hund im ersten Jahr bei 1.700 €.

# answeroption_03
Von allen Hundehalter:innen in dieser Stichprobe lag etwa die Hälfte über 1.700 € und etwa die Hälfte unter 1.700 €.

# answeroption_04
Für die meisten Hundehalter:innen liegen die Kosten für die Anschaffung eines großen Hundes im ersten Jahr bei 1.700 €.

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
1

# type_stimulus
text

# type_answer
text

# if_answeroption_01


# if_answeroption_02
Aus der Beschreibung geht weder hervor, dass die Grundgesamtheit komplett befragt wurde, noch dass der Mittelwert der Grundgesamtheit geschätzt wurde.

# if_answeroption_03
Dies träfe zu, wenn 1.700 Euro der Median wäre, es ist aber der Mittelwert.

# if_answeroption_04
Dies träfe zu, wenn 1.700 der Modus wäre, es ist aber der Mittelwert.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

