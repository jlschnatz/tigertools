# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

127

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Poweranalyse

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Stellen Sie sich vor, Sie sind Experimentalforscher\*in und werten gerade eine Studie über feministische Einstellungen aus. Dabei untersuchen Sie, wie verschiedene Merkmale mit feministischen Überzeugungen korrelieren. Allerdings haben Sie leider nur sehr wenige Personen erhoben, weswegen viele Effekte, wie beispielsweise die Korrelation zwischen Alter und feministischer Überzeugung, nicht signifikant ausfielen. Allerdings sind Sie überzeugt davon, dass dieser Effekt hätte signifikant ausfallen sollen, weil dies auch durch vorherige Studien impliziert wird. Deswegen wollen Sie in einer Poweranalyse im Nachhinein herausfinden, wie hoch die Korrelation in der Population ausfallen müsste, damit Sie sie mit Ihrem Studiendesign realistisch hätten aufdecken können. Um welche Art der Poweranalyse handelt es sich hierbei?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Es handelt sich um eine Kriteriumsanalyse.

# answeroption_02
Es handelt sich um eine Sensitivitätsanalyse.

# answeroption_03
Es handelt sich um eine Post-Hoc Poweranalyse.

# answeroption_04
Es handelt sich um eine A-priori Poweranalyse.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
2

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Bei der Kriteriumsanalyse wird der benötigte $\alpha$-Fehler bestimmt, mit dem Ziel, eine bestimmte Power zu garantieren. Dieses Vorgehen ist außerdem in der psychologischen Forschung eher unüblich.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Gesucht ist hierbei eine Korrelation, also der Effekt, der mit der Studie potentiell aufdeckbar ist.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Auch wenn die Analyse, genau wie die Post-hoc Poweranalyse, im Nachhinein durchgeführt wird, handelt es sich um eine andere Analyseform. Bei der Post-hoc Poweranalyse wird die Power ermittelt. Überlegen Sie, welcher Parameter hier gesucht wird.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Bei der A-priori Poweranalyse wird die nötige Stichprobengröße vor Durchführung der Studie ermittelt.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
