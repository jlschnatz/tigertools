# id_item
41

# learning_area
Wahrscheinlichkeit

# type_item
coding

# bloom_taxonomy
application

# theo_diff
easy

# stimulus_text
Welche der folgenden Aussagen beschreibt am besten die Verteilung der Variable „schlafqualitaet“ in unserem Datensatz?

# stimulus_image
NA

# answeroption_01
Gleichverteilung über die Werte 1 bis 5

# answeroption_02
Normalverteilung

# answeroption_03
Linksschief

# answeroption_04
Bimodale Verteilung

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
2

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Auch wenn die Werte von 1 bis 5 gehen, sind sie nicht gleichverteilt. Gleichverteilt würde bedeuten, dass jeder Wert gleich häufig auftritt.

# if_answeroption_02
Die Variable ist zwar ordinal skaliert, aber die Verteilung der 5 Werte folgt am ehesten einer Normalverteilung.

# if_answeroption_03
Eine Schiefe ist in den Daten nicht erkennbar.

# if_answeroption_04
Eine bimodale Verteilung ist in den Daten nicht erkennbar, da es nur einen eindeutigen höchsten Wert gibt und die Werte herum stetig niedriger werden.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

