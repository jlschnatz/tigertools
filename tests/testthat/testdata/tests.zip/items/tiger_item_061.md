# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

61

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Poweranalyse

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

Nachdem die ethische Kommission durch eines Ihrer vorherigen Experimente hellhörig geworden ist, behält sie Sie nun ganz genau im Auge. In Ihrer nächsten Studie wollen Sie untersuchen, ob Politiker\*innen aggressiver gegenüber Katzen sind als Psycholog\*innen. Dafür platzieren Sie eine Katze in die Nähe der Personen und ordnen den Reaktionen nach streng definierten Regeln einen Aggressionswert zu. Die ethische Kommission sieht aus irgendeinem Grund in diesem Versuchsaufbau eine Gefährdung der Katzen und bittet Sie deshalb, im Voraus festzustellen, wie viele Versuchsdurchläufe Sie jeweils machen müssten. Auf vorherigen Studien basierend (fragen wir uns mal nicht, wer die gemacht hat) leiten Sie eine vermutete Effektstärke von d = 0.5 ab. Sie möchten eine Power von 90% bei einem 5% Signifikanzniveau erreichen. 
Da Politiker schwerer zu bekommen sind als Psycholog\*innen, können Sie nur 50 Politiker\*innen rekrutieren. Wie viele Psycholog\*innen brauchen Sie in diesem Falle, um mindestens die gewünschte Power zu erreichen?


# stimulus_image

# answeroption_01
Es werden mindestens 70 Psycholog*innen gebraucht, um die gewünschte Power zu erreichen. 

# answeroption_02
Es werden mindestens 86 Psycholog*innen gebraucht, um die gewünschte Power zu erreichen. 

# answeroption_03
Es werden mindestens 112 Psycholog*innen gebraucht, um die gewünschte Power zu erreichen. 

# answeroption_04
Es werden mindestens 274 Psycholog*innen gebraucht, um die gewünschte Power zu erreichen. 

# answeroption_05

# answeroption_06

Frage überspringen.
<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->

# answer_correct

<!-- Numerisch (Integer) -->
3

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

Achten Sie darauf, dass eine der beiden Stichprobengrößen schon gegeben ist. Sie müssen die gegebene Stichprobengröße in Ihre Poweranalyse einfließen lassen, um die gesuchte Stichprobengröße der Psycholog*innen ermitteln zu können. 

# if_answeroption_02

Achten Sie darauf, dass eine der beiden Stichprobengrößen schon gegeben ist. Sie müssen die gegebene Stichprobengröße in Ihre Poweranalyse einfließen lassen, um die gesuchte Stichprobengröße der Psycholog*innen ermitteln zu können. Außerdem müssen Sie noch beachten, dass es sich um eine gerichtete Hypothese handelt.

# if_answeroption_03

Sie haben für die richtigen Parameter die richtigen Werte in die Funktion wp.t aus dem Paket WebPower eingesetzt. Dabei mussten Sie in der Reihenfolge erst für n1 die Anzahl der Politiker einsetzen (50), n2=NULL setzen, da diese gesucht wurde, d = 0.5 setzen, alpha = 0.05 setzen und im type Argument spezifizieren, dass es ein Zweistichproben Test mit 2 unterschiedlich großen Stichproben ist, folglich: ‚,two.sample.2n‘‘. Zuguterletzt musste noch die Richtung spezifiziert werden. Da Sie angenommen haben, dass Politiker **aggressiver** gegenüber Katzen sind als Psycholog\*innen, haben Sie eine gerichtete Hypothese, was Sie mit alternative = ‘greater‘ angeben müssen. Der resultierende Wert muss dann immer noch aufgerundet werden weil wir **mindestens** die gewünschte Power erreichen wollen.

# if_answeroption_04

Betrachten Sie noch mal die Aufgabenstellung und achten Sie darauf, ob es sich hier um eine gerichtete oder ungerichtete Hypothese handelt.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
