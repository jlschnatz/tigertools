# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

79

# learning_area

Wahrscheinlichkeit

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

hard

# stimulus_text
Sie sind in der Selektion von Teilnehmenden für den Studiengang Psychologie involviert. Dabei sollen Sie Methoden entwickeln, wie Sie den Auswahlprozess effizienter gestalten können. Besonders das Rausschicken und Annehmen der angenommenen Bewerbungen möchten Sie verschnellern. Sie wissen, dass grob 75% aller rausgeschickten Annahmen im ersten Schwung nur akzeptiert werden. Damit schneller klar ist, wer alles immatrikuliert wird, wollen Sie ein Verfahren einführen, was beim Buchen von z.B. Kreuzfahrten schon weit verbreitet ist: Sie wollen erstmal mehr angenommene Bewerbungen rausschicken, als Plätze da sind, da ein Teil der akzeptierten Bewerber\*innen den Studienplatz nicht annehmen werden (sogenanntes ,,Overbooking‘‘). Nun stellt sich die Frage, wie viele angenommene Bewerbungen rausgeschickt werden sollen. Um nicht aus Versehen für massive Enttäuschung zu sorgen, sagen Sie, dass Sie gerade so viele Studienplatzangebote rausschicken wollen, sodass mit einer Wahrscheinlichkeit von 95% weniger oder genau so viele Bewerbungen akzeptiert werden, wie es Studienplätze gibt. Insgesamt sind 150 Studienplätze vorhanden. 

Wie viele Studienplatzangebote schicken Sie demnach im ersten Schwung raus? 

# stimulus_image

# answeroption_01

Es werden 187 Studienplatzangebote rausgeschickt. 

# answeroption_02

Es werden 156 Studienplatzangebote rausgeschickt. 

# answeroption_03

Es werden 214 Studienplatzangebote rausgeschickt. 

# answeroption_04

Es werden 535 Studienplatzangebote rausgeschickt.

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

1


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Korrekt. Der Trick besteht darin, jedes Studienplatzangebot als Zufallsexperiment mit 2 sich gegenseitig ausschließenden Ausgängen (angenommen oder nicht angenommen) anzusehen. Folglich haben wir hier eine Binomialverteilung. Die Anzahl an Studienplätzen lässt sich demnach rausfinden, indem man in den Befehl qbinom erstmal die 0.95 für die 95%, dann die Anzahl an Zufallsexperimenten (aka Anzahl an rausgeschickten Bewerbungen, also das, was wir suchen), einsetzt und die Wahrscheinlichkeit, dass sich jemand immatrikuliert, also 75%, eingibt. qbinom(0.95, Anzahl_rausgeschickte_Bewerbungen, 0.75). Nun erhöht man die Anzahl_rausgeschickter_Bewerbungen bis zur ersten Zahl, die über 150 ist. Natürlich muss man das alles nicht einzeln machen, sondern kann das auch schön mit R-Code automatisieren: 

```{r}
# Define sizes to go through
possible_sizes <- c(150:300)

# Estimate all number of peoples which are at max accepted with the different samples sizes
number_of_admitted_people <- qbinom(0.95,possible_sizes,0.75)
number_of_admitted_people

# Subset from the sample sizes only those that remain under 150 with a 95% Chance
all_admittable_sizes <- number_of_admitted_people<=150
sizes_under_or_equal_150 <- subset(possible_sizes,all_admittable_sizes)

# Show maximum value of the sample sizes which are under 150
max(sizes_under_or_equal_150)
```

# if_answeroption_02

Sie können diese Aufgabe durch Ausprobieren mit der Binomialverteilung lösen. Schauen Sie nochmal, ob Sie die Wahrscheinlichkeiten an den richtigen Stellen in der richtigen Reihenfolge eingegeben haben. 

# if_answeroption_03

Sie können diese Aufgabe durch Ausprobieren mit der Binomialverteilung lösen. Überprüfen Sie nochmal die von Ihnen angegebenen Wahrscheinlichkeiten auf Korrektheit. 

# if_answeroption_04

Sie können diese Aufgabe durch Ausprobieren mit der Binomialverteilung lösen. Überprüfen Sie nochmal die von Ihnen angegebenen Wahrscheinlichkeiten auf Korrektheit. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
