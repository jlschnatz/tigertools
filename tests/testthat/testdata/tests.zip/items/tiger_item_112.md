# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

112

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
hard

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie erforschen Depressionen und wie verschiedene andere Merkmale mit diesen in Beziehung stehen. Dazu erstellen Sie mit folgendem Datensatz ein Regressionsmodell: `load(url("https://pandar.netlify.app/daten/Depression.rda"))`. Laden Sie sich über den Link den Datensatz in R herunter und erstellen Sie ein Regressionsmodell mit Depressivität als Kriterium und Lebenszufriedenheit, Episodenanzahl und Neurotizismus (Hinweis: Neurotizismus liegt hier invertiert vor als emotionale Stabilität) als Prädiktoren. Stellen Sie auch das standardisierte Regressionsmodell auf. Anschließend berechnen Sie bitte für dieses Modell den Standardfehler des **standardisierten** Regressionsgewichts der Lebenszufriedenheit, um die Unsicherheit der Schätzung des Regressionsgewicht zu bestimmen.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Der Standardfehler beträgt 0.074.

# answeroption_02
Der Standardfehler beträgt 0.049.

# answeroption_03
Der Standardfehler beträgt 0.108.

# answeroption_04
Der Standardfehler beträgt 0.065.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überlegen Sie noch mal, was bei der Standardisierung mit den Standardabweichungen passiert.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Schauen Sie sich die Formel für den Standardfehler des Regressionsgewichts erneut an. In einem multiplen Modell mit mehreren Prädiktoren benötigen Sie zusätzlich die Redundanz des jeweiligen Prädiktors, also diejenige Varianz, welche die anderen Prädiktoren am jeweiligen Prädiktor aufklären. (Tipp: Stellen Sie dazu ein weiteres Regressionsmodell auf mit der Lebenszufriedenheit als Kriterium und den übrigen Prädiktoren als Prädiktoren.)

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Schauen Sie sich die Formel für den Standardfehler des Regressionsgewichts erneut an. In einem multiplen Modell mit mehreren Prädiktoren benötigen Sie zusätzlich die Redundanz des jeweiligen Prädiktors, also diejenige Varianz, welche die anderen Prädiktoren am jeweiligen Prädiktor aufklären. (Tipp: Stellen Sie dazu ein weiteres Regressionsmodell auf mit der Lebenszufriedenheit als Kriterium und den übrigen Prädiktoren als Prädiktoren.)

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben richtig erkannt, dass Sie zur Berechnung des Standardfehlers eines Regressionsgewichts in einem multiplen Modell in einer Nebenrechnung ein weiteres Regressionsmodell mit der Lebenszufriedenheit als Kriterium aufstellen müssen. Damit berechnen Sie diejenige Varianz, welche die anderen Prädiktoren an der Lebenszufriedenheit aufklären. Je größer diese Varianzaufklärung (Redundanz der Lebenszufriedenheit), desto größer fällt der Standardfehler aus, also desto unsicherer fällt die Schätzung des Regressionsgewichts aus.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
