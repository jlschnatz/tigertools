# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

86

# learning_area

Regression

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Sie untersuchen in einer Studie den Zusammenhang zwischen Körpergröße und Psychopathie. In einem einfachen linearen Regressionsmodell mit Psychopathie als abhängiger Variable und Körpergröße als einzigem Prädiktor, resultierte ein $R^2$ von 0.06.
Nun nehmen Sie in einem erweiterten Modell noch Geschlecht, Alter und Neurotizismus als zusätzliche Prädiktoren auf. Dadurch erhöht sich das $R^2$ um 0.05. Insgesamt konnten Sie 187 Personen erheben. 

Ist der Anstieg des $R^2$ signifikant auf einem Alpha-Fehler Niveau von 1%?


# stimulus_image

# answeroption_01

Der Zuwachs an Varianzaufklärung ist statistisch bedeutsam.   

# answeroption_02

Der Zuwachs an Varianzaufklärung ist nicht statistisch bedeutsam. 

# answeroption_03

Ohne die Inferenz der einzelnen Regressionsgewichte von Geschlecht, Alter und Neurotizismus ist keine Aussage über die Signifikanz des Varianzzuwachses möglich. 

# answeroption_04

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Um die Aufgabe zu lösen, müssen Sie einen F-Test der inkrementellen Varainzaufklärung durchführen. Überprüfen Sie außerdem, ob Sie das korrekte alpha-Fehler-Niveau gewählt haben.

# if_answeroption_02

Stimmt genau. Die Signifikanz des Varianzinkrements kann man mit der Formel: 

$F=\frac{n-k_u-1}{k_u-k_c}*\frac{R^2_u-R^2_c}{1-R^2_u}$

berechnen. Dieser F-Wert lässt sich dann mit der Funktion pf unter Angabe der Freiheitsgrade in einen p-Wert umwandeln.

# if_answeroption_03

Es ist sehr wohl eine Signifikanzaussage bzgl. des Varianzzuwachses möglich, auch ohne dass die einzelnen inferenzstatistischen Signifikanzen berechnet sind. Schauen Sie nochmal, ob es nicht eine Formel gibt, welches das Varianzinkrement auf Signifikanz testet. 

# if_answeroption_04


# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
