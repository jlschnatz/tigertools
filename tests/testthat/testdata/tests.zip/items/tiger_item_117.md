# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

117

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Gruppenvergleiche

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie sind begeisterte\*r Zuschauer\*in von "Die Höhle der Löwen" und beschäftigen sich daher in Ihrer Freizeit sehr gerne mit Startups. Sie haben dazu einen Datensatz gefunden, worin es um Einstellungsentscheidungen in Startups geht. Tatkräftig laden Sie sich  mit folgendem Befehl den Datensatz in R herunter: `load(url("https://pandar.netlify.app/daten/Assessment.rda"))`. Sie kennen in Ihrem Umfeld außerdem viele junge Menschen, die Schwierigkeiten haben, einen passenden Job zu finden, weil die Unternehmen Personen mit mehr Berufserfahrung bevorzugen. Deswegen interessiert Sie besonders, ob selbst junge Unternehmen wie Start Ups bevorzugt ältere Personen einstellen. Prüfen Sie die Homoskedastizität und testen Sie auf einem $\alpha$-Niveau von 1%, ob die Personen, die in dieser Stichprobe eingestellt wurden (Hired == 1) im Durchschnitt signifikant älter sind als jene Personen, die nicht eingestellt wurden (Hired == 0).

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Bewerber\*innen, die eingestellt werden, sind im Schnitt signifikant älter als jene Bewerber\*innen, die nicht eingestellt werden. (t = -9,20, p < .001, KI: [-Inf; -2.18])

# answeroption_02
Bewerber\*innen, die eingestellt werden, sind im Schnitt signifikant älter als jene Bewerber\*innen, die nicht eingestellt werden. (t = -9.14, p < .001, KI: [-3.74; -2.09])

# answeroption_03
Bewerber\*innen, die eingestellt werden, sind im Schnitt signifikant älter als jene Bewerber\*innen, die nicht eingestellt werden. (t = -9.14, p < .001, KI: [-Inf; -2.39])

# answeroption_04
Bewerber\*innen, die eingestellt werden, sind im Schnitt signifikant älter als jene Bewerber\*innen, die nicht eingestellt werden. (t = -9.14, p < .001, KI: [-Inf; -2.17])

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Prüfen Sie noch mal, ob hier Homoskedastizität vorliegt.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Überlegen Sie noch mal, ob es sich um eine gerichtete oder ungerichtete Hypothese handelt.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf das $\alpha$-Fehler-Niveau.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben sich für den richtigen Test entschieden, die Homoskedastizität richtigerweise angenommen, die Richtung der Testung berücksichtigt und das richtige $\alpha$-Fehler-Niveau gewählt!

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
