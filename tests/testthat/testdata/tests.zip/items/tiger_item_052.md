# id_item
52

# learning_area
Deskriptivstatistik

# type_item
coding

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Wie viele Personen haben angegeben, nicht alleine zu schlafen und eine laute Schlafumgebung zu haben?

# stimulus_image
NA

# answeroption_01
50

# answeroption_02
19

# answeroption_03
84

# answeroption_04
38

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
2

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Das sind alle Personen, die nicht alleine schlafen – unabhängig ihrer Schlafumgebung.

# if_answeroption_02


# if_answeroption_03
Das sind alle Personen, die in einer gemischten oder lauten Umgebung schlafen – unabhängig davon, ob sie alleine schlafen oder nicht.

# if_answeroption_04
Das sind alle Personen, die in einer lauten Umgebung schlafen – unabhängig davon, ob sie alleine schlafen oder nicht.

# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

