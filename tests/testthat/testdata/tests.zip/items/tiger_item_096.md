# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

96

# learning_area

Deskriptivstatistik

# type_item

content

# bloom_taxonomy

application

# theo_diff

easy

# stimulus_text

Zum Anlass des baldigen Wiedererscheinens von Star Wars 3 in den Kinos (wahrscheinlich wird dies wenn Sie diese Aufgabe lesen in der Vergangenheit sein) wollen Sie schauen, wie gut das Star-Wars Wissen der Menschen noch ist. Dafür geben Sie jedem Teilnehmenden den Beginn eines legendären Zitates aus dem Film, den Sie dann richtig vervollständigen müssen (Beispiel: ,,You were my brother, Anakin‘‘ – Richtige Antwort: ,,I loved you‘‘ (Gänsehaut…)).  
Sie zählen, wie viele Antworten die einzelnen Personen richtig hatten und erhalten folgende Häufigkeitstabelle: 


|Anzahl korrekter Antworten|Häufigkeit|
|:---:|:---:|
|0|10 (schwach)|
|1|44|
|2|69|
|3|77|
|4|89|
|5|170|
|6|487|
|7|107|


Welchen Prozentrang hat eine Person, welche gerade mal 4 Zitate richtig vervollständigen konnte?


# stimulus_image

# answeroption_01

Die Person hat einen Prozentrang von 18.99%. 

# answeroption_02

Die Person hat einen Prozentrang von 81.01%. 

# answeroption_03

Die Person hat einen Prozentrang von 27.45%. 

# answeroption_04

Die Person hat einen Prozentrang von 72.55%. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

3


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Der Prozentrang beschreibt den prozentualen Anteil von Merkmalsträgern, die einen **gleichen** oder kleineren Wert haben als ein bestimmter Merkmalsträger. Schauen Sie sich nochmal die Berechnung des Prozentranges anhand der Formel an.

# if_answeroption_02

Der Prozentrang beschreibt den prozentualen Anteil von Merkmalsträgern, die einen **gleichen oder kleineren** Wert haben als ein bestimmter Merkmalsträger. Schauen Sie sich nochmal die Berechnung des Prozentranges anhand der Formel an.

# if_answeroption_03

Der Prozentrang beschreibt, wie groß der prozentuale Anteil an Personen ist, die diesen oder einen niedrigeren Wert erreicht haben. Folglich summiert man alle Häufigkeiten, die kleiner/gleich 4 sind auf und teilt diese durch die Gesamtanzahl multipliziert mit 100 (für Prozent).

# if_answeroption_04

Der Prozentrang beschreibt den prozentualen Anteil von Merkmalsträgern, die einen gleichen oder **kleineren** Wert haben als ein bestimmter Merkmalsträger. Passen Sie Ihre Rechnung entsprechend dieser Definition unter Beachtung der Richtung an. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
