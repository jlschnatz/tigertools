# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

89

# learning_area

Regression

# type_item

content

# bloom_taxonomy

knowledge

# theo_diff

medium

# stimulus_text

In einer Studie untersuchen Sie den Einfluss von der Höhe der Rechnung in einem Restaurant auf das gegebene Trinkgeld. Dafür erhalten Sie Daten von 10000 Transaktionen sowie die gegebenen Mengen an Trinkgeld. Nachdem Sie eine Regression gerechnet haben, überprüfen Sie nun die Voraussetzungen. Voller Entsetzen sehen Sie die untenstehende Grafik. Eine Voraussetzung ist verletzt! Welche Konsequenzen hat diese Verletzung für Ihre Regression? 

# stimulus_image

www/tiger_item089_stimulus.png

# answeroption_01

Weder die Regressionsgewichte noch deren Standardfehler werden korrekt geschätzt. 

# answeroption_02

Nur die Regressionsgewichte, nicht aber deren Standardfehler werden korrekt geschätzt. 

# answeroption_03

Die Regressionsgewicht werde nicht korrekt geschätzt, ihre Standardfehler jedoch schon.

# answeroption_04

Keine. Sowohl Regressionsgewicht als auch Standardfehler werden weiterhin korrekt geschätzt. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

image

# type_answer

text

# if_answeroption_01

Überlegen Sie nochmal, welche Voraussetzung verletzt wird und wofür diese nötig ist, beziehungsweise welche Kenngröße(n) von der Verletzung nicht beeinflusst wird/werden. 

# if_answeroption_02

Dargestellt ist eine Verletzung der Homoskedastizität. Dies erkennt man daran, dass die Residuen mit höherer Vorhersage stärker streuen. Bei höheren Geldbeträgen auf der Rechnung ist die Höhe des Trinkgeldes demnach variabler als bei niedrigen Beträgen. Die Konsequenz daraus ist, dass zwar die Regressionsgewichte korrekt geschätzt werden, nicht aber die Standardfehler. 

# if_answeroption_03

Überlegen Sie nochmal, welche Voraussetzung verletzt wird und wofür diese nötig ist, beziehungsweise welche Kenngröße(n) von der Verletzung nicht beeinflusst wird/werden. 

# if_answeroption_04

Überlegen Sie nochmal, welche Voraussetzung verletzt wird und wofür diese nötig ist, beziehungsweise welche Kenngröße(n) von der Verletzung nicht beeinflusst wird/werden. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
