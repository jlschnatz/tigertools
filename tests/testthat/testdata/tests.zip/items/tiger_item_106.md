# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

106

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
knowledge

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie lernen mit Ihrer Kommilitonin für die Statistik Klausur und erstellen sich gegenseitig Quizfragen zu statistischen Begriffen. Bei folgender Frage sind Sie nun etwas ratlos:
Welche dieser Aussagen über den Determinationskoeffizienten $R^2$ ist **nicht** wahr?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Das $R^2$ berücksichtigt die Komplexität des Modells und verringert sich, wenn unnötig viele Prädiktoren in das Modell aufgenommen wurden.

# answeroption_02
Der Determinationskoeffizient $R^2$ gibt an, welcher Anteil an Varianz der abhängigen Variable durch die UV(s) im Modell erklärt wird.

# answeroption_03
Ein $R^2$ von 0 bedeutet, dass kein linearer Zusammenhang zwischen der abhängigen Variable und der unabhängigen Variable besteht.

# answeroption_04
Wenn man einem bestehenden Modell zusätzliche Prädiktoren hinzufügt, kann das $R^2$ nur steigen oder gleich bleiben, aber nicht geringer werden.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
1


# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben die falsche Antwort richtig entlarvt! Das $R^2$ ist zwar ein ziemlich hilfreiches Maß in der Regressionsanalyse, jedoch korrigiert es nicht für unnötig komplexe Modelle, wenn also zu viele oder für das Modell sinnlose Prädiktoren aufgenommen werden. Zu diesem Zweck gibt es noch zusätzlich das adjusted $R^2$, welches quasi die Aufnahme jeder weiteren Variable als Prädiktor "bestraft".

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Dies stellt die zentrale Funktion des $R^2$ dar und wenn Sie das nicht wussten, sollten Sie sich dringend noch mal mit dem Determinationskoeffizienten beschäftigen. Oder dachten Sie vielleicht, Sie sollen die **richtige** Aussage finden?


# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn der Determinationskoeffizient 0 beträgt, dann weisen die AV und die UV keine geteilte Varianz auf, stehen also auch in keinem linearen Zusammenhang zueinander. Das erkennt man auch daran, dass in der einfachen linearen Regression das $R^2$ der quadrierten Korrelation zwischen den beiden Variablen entspricht.

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Normalerweise steigt das $R^2$ durch das Hinzufügen zusätzlicher Variablen im Modell. Es kann aber theoretisch auch vorkommen, dass das $R^2$ gleich bleibt, weil die zusätzliche Variable keine zusätzliche Varianz aufdeckt, die nicht schon durch die anderen Prädiktoren erklärt wird. Es ist allerdings nicht möglich, dass der Determinationskoeffizient mit zusätzlich aufgenommenen Prädiktoren sinkt, da es keine negative Varianzaufklärung gibt. Trotzdem kann sich das Modell qualitativ verschlechtern, wenn dem Modell unnötige Prädiktoren hinzugefügt werden.


# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
