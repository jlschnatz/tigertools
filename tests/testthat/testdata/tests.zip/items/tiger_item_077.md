# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

77

# learning_area

Regression

# type_item

content

# bloom_taxonomy

application

# theo_diff

hard

# stimulus_text

Nachdem Sie letztens an einem Kurs über deutsche Literatur das Zitat eines zufällig und definitiv nicht auf diese Uni bezogenen Dichters gehört haben, geht es Ihnen nicht mehr aus dem Kopf. 

**,, Wenn durch die Phantasie nicht Dinge entständen, die für den Verstand ewig problematisch bleiben, so wäre überhaupt zu der Phantasie nicht viel.‘‘**

Genial. Sie möchten diese Inspiration nun verwenden, um sich etwas anzunähern, was bisher für Ihren Verstand problematisch war: Nämlich multiple Regression. Sie wollen sich dabei verständlicherweise in Ihrer Fantasie ein Bild machen, wie eine multiple Regression aussehen würde. Sie wissen, dass bei einer einfachen Regression sich das Ganze als Punkte und Linien visualisieren lässt. Jetzt möchten Sie das auf 2 Prädiktoren ausweiten. 
Sie nehmen sich konkret die Regressionsgleichung 

$\hat{y}=0.69 + 4.2*x_1 -1.1 * x_2$ 

vor. 

Welches Bild entspringt Ihrer Fantasie korrekterweise? (Die Linien stellen nochmal die Koordinaten an der richtigen Stelle dar, damit der Nullpunkt besser zu bestimmen ist.)


# stimulus_image

# answeroption_01

www/tiger_item077_answeropt_1.png

# answeroption_02

www/tiger_item077_answeropt_2.png

# answeroption_03

www/tiger_item077_answeropt_3.png

# answeroption_04

www/tiger_item077_answeropt_4.png

# answeroption_05

www/tiger_item077_answeropt_5.png

# answeroption_06

www/skip.png

# answer_correct

2


# type_stimulus

text

# type_answer

image

# if_answeroption_01

Zwar sind die Zusammenhänge in der richtigen Richtung (höhere x1 Werte heben die Regressionsebene, niedrigere senken Sie), jedoch muss die Position von dem y-Achsenabschnitt auch stimmen. Überprüfen Sie dies nochmal. 

# if_answeroption_02

Die Zusammenhänge sind in der richtigen Richtung (höhere x1 Werte heben die Regressionsebene, niedrigere senken Sie), und auch die Position vom y-Achsenabschnitt stimmt, wie sich mit der rechten Koordinatenlinie bestimmen lässt. 

# if_answeroption_03

Allerdings stimmt der y-Achsenabschnitt, wie man mit der Koordinatenlinie bestimmen kann. Überprüfen Sie nochmal, ob die Zusammenhänge in die gleiche Richtung verlaufen, wie es die Regressionsgleichung vorgibt.  

# if_answeroption_04

Allerdings stimmt der y-Achsenabschnitt, wie man mit der Koordinatenlinie bestimmen kann. Überprüfen Sie nochmal, ob die Zusammenhänge in die gleiche Richtung verlaufen, wie es die Regressionsgleichung vorgibt.  

# if_answeroption_05

Allerdings stimmt der y-Achsenabschnitt, wie man mit der Koordinatenlinie bestimmen kann. Überprüfen Sie nochmal, ob die Zusammenhänge in die gleiche Richtung verlaufen, wie es die Regressionsgleichung vorgibt.  

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
