# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

99

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
Regression

# type_item

<!---
String (eines von):
    - content
    - coding
 ---> 
content

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
---> 
comprehension

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
---> 
medium

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie betrachten in Ihrer Regressionsanalyse zwei verschiedene Regressoren zur Vorhersage von y. Dabei berechnen Sie für Ihre beiden Prädiktoren $x_{1}$ und $x_{2}$ zunächst getrennt voneinander eine lineare Regression (Modell 1 & 2) und führen diese anschließend in einem multiplen Regressionsmodell zusammen (Modell 3). 
Beim Betrachten Ihrer Ergebnisse wundern Sie sich darüber, dass Modell 3 offensichtlich deutlich mehr Varianz aufklärt als Modell 2, obwohl der Determinationskoeffizient von Modell 1 quasi bei 0 liegt und sich demnach $x_{1}$ in diesem Modell gar nicht als Prädiktor eignet. Sie überlegen, wie es dennoch sein kann, dass die Hinzunahme von $x_{1}$ das $R^2$ drastisch erhöht und halten Ihre Überlegungen zu der Zusammenhangsstruktur der Variablen zur Veranschaulichung zunächst skizzenhaft fest. Welche Grafik entspricht konzeptuell den Zusammenhängen zwischen den drei Variablen?

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->
www/tiger_item099_stimulus.png

# answeroption_01

www/tiger_item099_answeropt_1.png

# answeroption_02

www/tiger_item099_answeropt_2.png

# answeroption_03

www/tiger_item099_answeropt_3.png

# answeroption_04

www/tiger_item099_answeropt_4.png

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
www/skip.png

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
image

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
image

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn diese Zusammenhangsstruktur gelten würde, dann müsste die Variable $x_{1}$ bereits im linearen Modell zur Varianzaufklärung von y beitragen, da die beiden Variablen eindeutig überlappen. $x_{1}$ und y scheinen jedoch unkorreliert zu sein. Überlegen Sie, wie es dennoch sein kann, dass $x_1$ in Kombination mit $x_2$ so wesentlich zur Varianzaufklärung beiträgt.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Wenn diese Zusammenhangsstruktur gelten würde, dann würde $x_1$ bereits im linearen Modell zur Varianzaufklärung beitragen, da $x_1$ und y eindeutig überlappen. Die beiden Variablen scheinen jedoch unkorreliert zu sein. Überlegen Sie, wie es dennoch sein kann, dass $x_1$ in Kombination mit $x_2$ so wesentlich zur Varianzaufklärung beiträgt.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Es stimmt zwar, dass $x_1$ und y unkorreliert sein müssen, wenn $x_1$ im linearen Modell keine Varianzaufklärung leistet, jedoch bietet diese Struktur keine Erklärung dafür, dass $x_1$ im multiplen Modell wesentlich zur Varianzaufklärung beiträgt. Kann $x_1$ womöglich auf etwas anderes Einfluss haben als auf die abhängige Variable, wodurch das $R^2$ erhöht wird?

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sie haben sehr richtig erkannt, dass $x_1$ mit y zwar unkorreliert sein muss, aber dafür deutlich mit $x_2$ korreliert. Es handelt sich bei $x_1$ nämlich um eine Suppressorvariable des Zusammenhangs zwischen $x_2$ und y. Durch die Korrelation zwischen $x_1$ und $x_2$ werden Teile der Varianz von $x_2$ "unterdrückt", die nicht mit dem Kriterium korreliert sind, wodurch sich das $R^2$ erhöht.

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
