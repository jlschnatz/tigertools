# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

91

# learning_area

Gruppenvergleiche

# type_item

coding

# bloom_taxonomy

knowledge

# theo_diff

medium

# stimulus_text

Für Ihre Bachelorarbeit haben Sie einen Fragebogen erstellt, welcher Wissen über das deutsche Strafrecht erfassen soll. Um dessen Validität zu überprüfen, möchten Sie nun vergleichen, ob Personen mit irgendeiner juristischen Bildung (anyLawEducation = ,,Yes‘‘) besser abschneiden als Personen ohne irgendeine juristische Bildung (anyLawEducation = ,,No‘‘). Varianzgleichheit und Normalverteilung haben Sie gewissenhaft geprüft und waren gegeben. 

Wie sieht der gemäß Ihrer Hypothese und den Voraussetzungsprüfungen richtige Output aus? 


# stimulus_image

# answeroption_01

www/tiger_item091_answeropt_1.png

# answeroption_02

www/tiger_item091_answeropt_2.png

# answeroption_03

www/tiger_item091_answeropt_3.png

# answeroption_04

www/tiger_item091_answeropt_4.png

# answeroption_05

# answeroption_06

www/skip.png

# answer_correct

1


# type_stimulus

text

# type_answer

image

# if_answeroption_01

Sehr gut. Da die Varianzgleichheit gegeben ist, wird hier korrekterweise auch keine Welch-Korrektur durchgeführt. Anhand des Konfidenzintervalls sowie dem Text mit der ,,alternative hypothesis'' lässt sich dann zusätzlich ablesen, dass hier ein einseitig nach oben gerichteter t-Test durchgeführt wurde. Da in der Hypothese auch davon ausgegangen wurde, dass Personen mit juristischer Bildung **höhere** Wissenswerte als Personen ohne juristische Bildung haben, wurde dies hier korrekt berücksichtigt. 

# if_answeroption_02

Achten Sie im Aufgabentext nochmal darauf, welche Voraussetzungen gegeben sind und ob diese beim Testen korrekt berücksichtigt wurden. 

# if_answeroption_03

Überlegen Sie nochmal, ob in der Hypothese eine Richtung angegeben wird und woran Sie erkennen würden, dass diese korrekt berücksichtigt wurde bei der Testung. 

# if_answeroption_04

Achten Sie im Aufgabentext nochmal darauf, welche Voraussetzungen gegeben sind und ob diese beim Testen korrekt berücksichtigt wurden. Überlegen Sie zudem, ob in der Hypothese eine Richtung angegeben wird und woran Sie erkennen würden, dass diese korrekt berücksichtigt wurde bei der Testung. 

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
