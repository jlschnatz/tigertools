# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

126

# learning_area

<!---
String (eines von):
    - Deskriptivstatistik
    - Wahrscheinlichkeit
    - Grundlagen der Inferenzstatistik
    - Gruppenvergleiche
    - Poweranalyse
    - Zusammenhangsmaße
    - Regression
 --->
 Poweranalyse

# type_item

<!---
String (eines von):
    - content
    - coding
 --->
 coding

# bloom_taxonomy

<!---
String (eines von):
    - knowledge
    - comprehension
    - application
--->
application

# theo_diff

<!---
String (eines von):
    - easy
    - medium
    - hard
--->
easy

# stimulus_text

<!-- 
String. Enhält Stimulustext (kann ebenfalls Markdown-Tabellen enthalten)
--->
Sie wollen testen, ob Sport auch bei Personen, die eigentlich ungern Sport treiben, zu weniger Stress führt. Dabei wollen Sie das Stresslevel Ihrer Versuchspersonen zunächst vor der Intervention messen und lassen Ihre Proband\*innen anschließend ein 60-minütiges Sportprogramm durchführen. Anschließend messen Sie erneut das Stresslevel und testen, ob der Sport im Durchschnitt zu einer Verminderung des Stresslevels geführt hat. Nachdem Sie Ihren Versuchsaufbau soweit geplant haben, fragen Sie sich allerdings: Wie viele Sportmuffel muss ich überhaupt rekrutieren? Ihr $\alpha$-Fehler soll .05 betragen und Ihr $\beta$-Fehler .10. Sie gehen von einem Effekt von $\delta$ = 0.4 aus.

# stimulus_image

<!-- 
String. Falls zusätztlich zu `stimulus_text` ein Bild als Stimulus verwendet werden soll, kann
hier ein Pfad für das Bild eingefügt werden. (ansonsten auslassen)
--->

# answeroption_01
Sie müssen 108 Sportmuffel rekrutieren.

# answeroption_02
Sie müssen 3 Sportmuffel rekrutieren.

# answeroption_03
Sie müssen 68 Sportmuffel rekrutieren.

# answeroption_04
Sie müssen 55 Sportmuffel rekrutieren.

# answeroption_05

# answeroption_06

<!---
String (ohne Anführungszeichen):
    - "Frage überspringen."
    - "www/skip.png"
  
Wenn type_answer: `text`, dann "Frage überspringen"
Wenn type_answer: `image`, dann "www/skip.png"
--->
Frage überspringen.

# answer_correct

<!-- Numerisch (Integer) -->
4

# type_stimulus

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Stimulus ein Textformat genutzt wurde, und `image`, wenn als Stimulus ein Bild verwendet wurde.
--->
text

# type_answer

<!---
String (eines von):
    - text
    - image
Muss `text` sein, wenn als Antwortoptionen ein Textformat genutzt wurde, und `image`, wenn als Antwortoptionen Bilder verwendet wurden.
--->
text

# if_answeroption_01

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf die Art der Stichprobe.

# if_answeroption_02

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf die Power.

# if_answeroption_03

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Achten Sie noch mal auf die Richtung der Testung. 

# if_answeroption_04

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->
Sehr gut, Sie haben die richtige Poweranalyse durchgeführt und auch beachtet, dass es sich um eine abhängige Stichprobe handelt. (`type = 'paired'`)

# if_answeroption_05

<!---
Die `if_answeroption_XX` Felder müssen das Feedback für die ausgewählte Antwortoption XX enthalten.
--->

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
