# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

68

# learning_area

Gruppenvergleiche

# type_item

content

# bloom_taxonomy

knowledge

# theo_diff

easy

# stimulus_text

Es soll da draußen tatsächlich Menschen geben, die regelmäßig Sport treiben. Sie möchten sich der Erforschung dieser außergewöhnlichen Individuen widmen. Sie beobachten, dass viele Jogger\*innen Musik beim Joggen hören. Sie kombinieren dieses Wissen mit Ihrem Wissen zur klassischen Konditionierung und erstellen daraus folgende Forschungshypothese: Jogger\*innen haben selbst im Ruhezustand einen höheren Puls, wenn sie Lieder hören, die sie sonst ausschließlich beim Joggen hören im Vergleich zum Puls bei Liedern, die sie sonst nicht beim Joggen hören. Um dieser Hypothese auf den Grund zu gehen, rekrutieren Sie 200 Jogger\*innen und messen ihren Puls ein Mal beim Anhören von Liedern, die beim Joggen gehört werden und ein Mal beim Anhören von Liedern, die sonst nicht beim Joggen gehört werden. Der Ruhepuls der Proband\*innen bei neutralen Liedern liegt im Mittel bei 64. Bei Liedern fürs Joggen liegt er im Mittel bei 69. Die Differenzwerte haben eine geschätzte Standardabweichung von 14. 

Berechnen Sie ein geeignetes Maß der Effektstärke und interpretieren Sie dieses.  


# stimulus_image

# answeroption_01

Die Effektstärke ist mit 0.357 als eher klein einzuschätzen.

# answeroption_02

Die Effektstärke ist mit 0.357 als mittel einzuschätzen. 

# answeroption_03

Die Effektstärke ist mit 5.05 als sehr groß einzuschätzen. 

# answeroption_04

Die Effektstärke ist mit < 0.001 als vernachlässigbar einzuschätzen. 

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Die Effektstärke ist korrekt bestimmt, aber die Interpretation ist nach den Faustregeln von Cohen nicht korrekt. 

# if_answeroption_02

Sowohl Berechnung als auch Interpretation nach den Vorschlägen von Cohen sind korrekt. 

# if_answeroption_03

Sie haben statt der Effektstärke die Prüfgröße berechnet. Schauen Sie nochmal bei der Berechnung von Cohen’s d nach der Formel.
# if_answeroption_04

Sie haben statt der Effektstärke den p-Wert berechnet. Schauen Sie nochmal bei der Berechnung von Cohen’s d nach der Formel.

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
