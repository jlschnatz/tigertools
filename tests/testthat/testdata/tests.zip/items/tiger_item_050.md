# id_item
50

# learning_area
Grundlagen der Inferenzstatistik

# type_item
coding

# bloom_taxonomy
knowledge

# theo_diff
easy

# stimulus_text
Welches der folgenden Intervalle ist das 99%-Konfidenzintervall für die durchschnittliche Schlafdauer?

# stimulus_image
NA

# answeroption_01
[6.44, 6.91]

# answeroption_02
[6.40, 6.96]

# answeroption_03
[6.30, 7.05]

# answeroption_04
[5.53, 8.53]

# answeroption_05
NA

# answeroption_06
Frage überspringen.

# answer_correct
3

# type_stimulus
text

# type_answer
text

# if_answeroption_01
Dies ist das 90%-Konfidenzintervall.

# if_answeroption_02
Dies ist das 95%-Konfidenzintervall.

# if_answeroption_03


# if_answeroption_04


# if_answeroption_05
NA

# if_answeroption_06
Alles klar! Du hast die Aufgabe übersprungen.

