# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

92

# learning_area

Gruppenvergleiche

# type_item

coding

# bloom_taxonomy

comprehension

# theo_diff

easy

# stimulus_text

Sie beschäftigen sich zur Klausurvorbereitung mit dem Datensatz ,,Guyer‘‘ aus dem Paket ,,carData‘‘. Dafür lesen Sie den Datensatz mit folgender Syntax ein: 

```
library(car)
library(carData)
gu<-carData::Guyer
#For more information see ?carData::Guyer
```

Der Datensatz enthält Daten über ein Experiment, wo das Prisoner‘s-Dilemma gespielt wurde. Registriert wurden die Anzahl kooperativer Entscheidungen, ob die Entscheidung öffentlich oder anonym gemacht wurde und das Geschlecht. Sie möchten nun untersuchen, ob es einen statistisch bedeutsamen Unterschied zwischen einer öffentlichen Entscheidung und einer anonymen Entscheidung gab in Bezug auf die Anzahl der Kooperationen. Wie lauten die Effektgröße und Signifikanz für diesen Vergleich? 

# stimulus_image

# answeroption_01

Der Effekt ist nicht signifikant von 0 verschieden mit d = -1.19 [95% KI: -0.17, -2.21].

# answeroption_02

Der Effekt ist signifikant von 0 verschieden mit d = -1.19 [95% KI: -0.17, -2.21].

# answeroption_03

Der Effekt ist nicht signifikant von 0 verschieden mit d = -1.20 [95% KI: 0.12, -2.52].

# answeroption_04

Der Effekt ist signifikant von 0 verschieden mit d = -1.20 [95% KI: 0.12, -2.52].

# answeroption_05

# answeroption_06

Frage überspringen.

# answer_correct

2


# type_stimulus

text

# type_answer

text

# if_answeroption_01

Überlegen Sie, welche Effektgröße unter der H0 zu erwarten wäre und wo diese Effektgröße in Bezug zum Konfidenzintervall (innerhalb oder außerhalb) liegen müsste. Überdenken Sie darauf basierend, was das für die Signifikanz bedeutet. 

# if_answeroption_02

Da die 0 nicht im Konfidenzintervall enthalten ist, ist der Effekt statistisch bedeutsam. Der Code für das Konfidenzintervall des Effektes lautet: 

```
library(effsize)
cohen.d(cooperation~condition,gu)
```

# if_answeroption_03

Überprüfen Sie nochmal, welche Art der Stichprobe (abhängig vs. unabhängig) vorliegt. Mit welcher Funktion können Sie ganz unkompliziert die Effektgröße samt Konfidenzintervall berechnen? (Tipp: Sie benötigen dafür das Paket 'effsize'.)

# if_answeroption_04

Überprüfen Sie nochmal, welche Art der Stichprobe (abhängig vs. unabhängig) vorliegt. Mit welcher Funktion können Sie ganz unkompliziert die Effektgröße samt Konfidenzintervall berechnen? (Tipp: Sie benötigen dafür das Paket 'effsize'.) Und wie können Sie anhand des Konfidenzintervalls eine Signifikanzentscheidung treffen?

# if_answeroption_05


# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
