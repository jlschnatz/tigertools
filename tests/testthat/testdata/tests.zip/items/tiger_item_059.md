# id_item

<!-- Numerisch: z.B. 100 (muss eineindeutig sein) -->

59

# learning_area

Zusammenhangsmaße

# type_item

content

# bloom_taxonomy

comprehension

# theo_diff

medium

# stimulus_text

Eine Freundin von Ihnen will zusammen mit einer weiteren Kommilitonin sich mit dem Zusammenhang von Anzahl an Social-Media-Posts und Selbstwertgefühl beschäftigen. Hierfür wollen Sie die Korrelation zwischen den beiden Variablen berechnen. Bei der konkreten Berechnung sind die beiden sich aber noch uneinig. Ihre Freundin meint, man muss die Formel für die empirische Korrelation ($r_{xy}=\frac{s_{xy}}{s_x*s_y}$) verwenden, während die Kommilitonin meint, man müsse stattdessen die Formel für die geschätzte Korrelation ($\hat{\rho}_{xy}=\frac{\hat{\sigma}_{xy}}{\hat{\sigma}_x*\hat{\sigma}_y}$) nehmen. Da sich die beiden nicht einig werden, sollen Sie als unabhängige Person den Streit schlichten. 
Welche Korrelationsformel müssen die beiden nehmen?

# stimulus_image 

# answeroption_01
Keine der beiden Formeln ist geeignet.

# answeroption_02
Nur die Formel für die empirische Korrelation ist geeignet. 

# answeroption_03
Nur die Formel für die geschätzte Korrelation ist geeignet.

# answeroption_04
Beide Formeln sind geeignet. 

# answeroption_05

# answeroption_06
Frage überspringen.

# answer_correct
4

# type_stimulus
text

# type_answer
text

# if_answeroption_01

Die dargestellten Formeln sind valide Formeln für eine Korrelationsberechnung.

# if_answeroption_02

Überlegen Sie nochmal, worin sich empirische Werte und Schätzwerte unterscheiden und wie sich der Bruch darauf auswirkt.

# if_answeroption_03

Überlegen Sie nochmal, worin sich empirische Werte und Schätzwerte unterscheiden und wie sich der Bruch darauf auswirkt.

# if_answeroption_04

Schaut man sich die beiden Formeln kann, so kürzt sich in beiden Formeln der Anteil von n-1 bzw. n raus und es kommen äquivalente Formeln raus.

$\hat{\rho}_{xy}=\frac{\hat{\sigma}_{xy}}{\hat{\sigma}_x*\hat{\sigma}_y}$

$\hat{\rho}_{xy}=\frac{\frac{1}{n-1}*\sum_{m=1}^{n}(x_m-\bar{x})*(y_m-\bar{y})}{\sqrt{\frac{1}{n-1}*\sum_{m=1}^{n}(x_m-\bar{x})^2*\frac{1}{n-1}*\sum_{m=1}^{n}(y_m-\bar{y})^2}}$

Hier kürzen sich die $\frac{1}{n-1}$ raus und es bleibt übrig: 

$\hat{\rho}_{xy}=\frac{\sum_{m=1}^{n}(x_m-\bar{x})*(y_m-\bar{y})}{\sqrt{\sum_{m=1}^{n}(x_m-\bar{x})^2*\sum_{m=1}^{n}(y_m-\bar{y})^2}}$


<br>
Führen wir dies nun Analog für die empirische Korrelation durch erhalten wir: 

$r_{xy}=\frac{s_{xy}}{s_x*s_y}$

$r_{xy}=\frac{\frac{1}{n}*\sum_{m=1}^{n}(x_m-\bar{x})*(y_m-\bar{y})}{\sqrt{\frac{1}{n}*\sum_{m=1}^{n}(x_m-\bar{x})^2*\frac{1}{n}*\sum_{m=1}^{n}(y_m-\bar{y})^2}}$

Hier kürzen sich die $\frac{1}{n}$ raus und es bleibt übrig: 

$r_{xy}=\frac{\sum_{m=1}^{n}(x_m-\bar{x})*(y_m-\bar{y})}{\sqrt{\sum_{m=1}^{n}(x_m-\bar{x})^2*\sum_{m=1}^{n}(y_m-\bar{y})^2}}$

Folglich ist es egal, für welche der beiden Varianten die zwei sich entscheiden, solange sie dann konsequent bei dieser Variante bleiben und nicht beide Varianten aus Versehen vermischen.
Korrelationen sind demnach erwartungstreue Schätzer, müssen also nicht nochmal angepasst werden, um die Population zu schätzen. 

# if_answeroption_05

# if_answeroption_06

<!--
Bitte so lassen.
-->

Alles klar! Du hast die Aufgabe übersprungen.
